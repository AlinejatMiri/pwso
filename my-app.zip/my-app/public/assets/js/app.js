var e = Object.create,
  t = Object.defineProperty,
  n = Object.getOwnPropertyDescriptor,
  r = Object.getOwnPropertyNames,
  i = Object.getPrototypeOf,
  a = Object.prototype.hasOwnProperty,
  o = (e, t) => () => (
    t ||
      (e(
        (t = {
          exports: {},
        }).exports,
        t,
      ),
      (e = null)),
    t.exports
  ),
  s = (e, i, o, s) => {
    if ((i && typeof i == `object`) || typeof i == `function`)
      for (var c = r(i), l = 0, u = c.length, d; l < u; l++)
        ((d = c[l]),
          !a.call(e, d) &&
            d !== o &&
            t(e, d, {
              get: ((e) => i[e]).bind(null, d),
              enumerable: !(s = n(i, d)) || s.enumerable,
            }));
    return e;
  },
  c = (n, r, o) => (
    (o = n == null ? {} : e(i(n))),
    s(
      r || !n || !n.__esModule || !a.call(n, `default`)
        ? t(o, `default`, {
            value: n,
            enumerable: !0,
          })
        : o,
      n,
    )
  );
(function () {
  let e = document.createElement(`link`).relList;
  if (e && e.supports && e.supports(`modulepreload`)) return;
  for (let e of document.querySelectorAll(`link[rel="modulepreload"]`)) n(e);
  new MutationObserver((e) => {
    for (let t of e)
      if (t.type === `childList`)
        for (let e of t.addedNodes)
          e.tagName === `LINK` && e.rel === `modulepreload` && n(e);
  }).observe(document, {
    childList: !0,
    subtree: !0,
  });
  function t(e) {
    let t = {};
    return (
      e.integrity && (t.integrity = e.integrity),
      e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy),
      (t.credentials =
        e.crossOrigin === `use-credentials`
          ? `include`
          : e.crossOrigin === `anonymous`
            ? `omit`
            : `same-origin`),
      t
    );
  }
  function n(e) {
    if (e.ep) return;
    e.ep = !0;
    let n = t(e);
    fetch(e.href, n);
  }
})();
var l = o((e) => {
    var t = Symbol.for(`react.transitional.element`),
      n = Symbol.for(`react.portal`),
      r = Symbol.for(`react.fragment`),
      i = Symbol.for(`react.strict_mode`),
      a = Symbol.for(`react.profiler`),
      o = Symbol.for(`react.consumer`),
      s = Symbol.for(`react.context`),
      c = Symbol.for(`react.forward_ref`),
      l = Symbol.for(`react.suspense`),
      u = Symbol.for(`react.memo`),
      d = Symbol.for(`react.lazy`),
      f = Symbol.for(`react.activity`),
      p = Symbol.for(`react.view_transition`),
      m = Symbol.iterator;
    function h(e) {
      return typeof e != `object` || !e
        ? null
        : ((e = (m && e[m]) || e[`@@iterator`]),
          typeof e == `function` ? e : null);
    }
    var g = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function () {},
        enqueueReplaceState: function () {},
        enqueueSetState: function () {},
      },
      _ = Object.assign,
      v = {};
    function y(e, t, n) {
      ((this.props = e),
        (this.context = t),
        (this.refs = v),
        (this.updater = n || g));
    }
    ((y.prototype.isReactComponent = {}),
      (y.prototype.setState = function (e, t) {
        if (typeof e != `object` && typeof e != `function` && e != null)
          throw Error(
            `takes an object of state variables to update or a function which returns an object of state variables.`,
          );
        this.updater.enqueueSetState(this, e, t, `setState`);
      }),
      (y.prototype.forceUpdate = function (e) {
        this.updater.enqueueForceUpdate(this, e, `forceUpdate`);
      }));
    function b() {}
    b.prototype = y.prototype;
    function ee(e, t, n) {
      ((this.props = e),
        (this.context = t),
        (this.refs = v),
        (this.updater = n || g));
    }
    var x = (ee.prototype = new b());
    ((x.constructor = ee), _(x, y.prototype), (x.isPureReactComponent = !0));
    var te = Array.isArray;
    function ne() {}
    var S = {
        H: null,
        A: null,
        T: null,
        S: null,
      },
      re = Object.prototype.hasOwnProperty;
    function C(e, n, r) {
      var i = r.ref;
      return {
        $$typeof: t,
        type: e,
        key: n,
        ref: i === void 0 ? null : i,
        props: r,
      };
    }
    function ie(e, t) {
      return C(e.type, t, e.props);
    }
    function w(e) {
      return typeof e == `object` && !!e && e.$$typeof === t;
    }
    function T(e) {
      var t = {
        "=": `=0`,
        ":": `=2`,
      };
      return (
        `$` +
        e.replace(/[=:]/g, function (e) {
          return t[e];
        })
      );
    }
    var ae = /\/+/g;
    function oe(e, t) {
      return typeof e == `object` && e && e.key != null
        ? T(`` + e.key)
        : t.toString(36);
    }
    function se(e) {
      switch (e.status) {
        case `fulfilled`:
          return e.value;
        case `rejected`:
          throw e.reason;
        default:
          switch (
            (typeof e.status == `string`
              ? e.then(ne, ne)
              : ((e.status = `pending`),
                e.then(
                  function (t) {
                    e.status === `pending` &&
                      ((e.status = `fulfilled`), (e.value = t));
                  },
                  function (t) {
                    e.status === `pending` &&
                      ((e.status = `rejected`), (e.reason = t));
                  },
                )),
            e.status)
          ) {
            case `fulfilled`:
              return e.value;
            case `rejected`:
              throw e.reason;
          }
      }
      throw e;
    }
    function ce(e, r, i, a, o) {
      var s = typeof e;
      (s === `undefined` || s === `boolean`) && (e = null);
      var c = !1;
      if (e === null) c = !0;
      else
        switch (s) {
          case `bigint`:
          case `string`:
          case `number`:
            c = !0;
            break;
          case `object`:
            switch (e.$$typeof) {
              case t:
              case n:
                c = !0;
                break;
              case d:
                return ((c = e._init), ce(c(e._payload), r, i, a, o));
            }
        }
      if (c)
        return (
          (o = o(e)),
          (c = a === `` ? `.` + oe(e, 0) : a),
          te(o)
            ? ((i = ``),
              c != null && (i = c.replace(ae, `$&/`) + `/`),
              ce(o, r, i, ``, function (e) {
                return e;
              }))
            : o != null &&
              (w(o) &&
                (o = ie(
                  o,
                  i +
                    (o.key == null || (e && e.key === o.key)
                      ? ``
                      : (`` + o.key).replace(ae, `$&/`) + `/`) +
                    c,
                )),
              r.push(o)),
          1
        );
      c = 0;
      var l = a === `` ? `.` : a + `:`;
      if (te(e))
        for (var u = 0; u < e.length; u++)
          ((a = e[u]), (s = l + oe(a, u)), (c += ce(a, r, i, s, o)));
      else if (((u = h(e)), typeof u == `function`))
        for (e = u.call(e), u = 0; !(a = e.next()).done;)
          ((a = a.value), (s = l + oe(a, u++)), (c += ce(a, r, i, s, o)));
      else if (s === `object`) {
        if (typeof e.then == `function`) return ce(se(e), r, i, a, o);
        throw (
          (r = String(e)),
          Error(
            `Objects are not valid as a React child (found: ` +
              (r === `[object Object]`
                ? `object with keys {` + Object.keys(e).join(`, `) + `}`
                : r) +
              `). If you meant to render a collection of children, use an array instead.`,
          )
        );
      }
      return c;
    }
    function E(e, t, n) {
      if (e == null) return e;
      var r = [],
        i = 0;
      return (
        ce(e, r, ``, ``, function (e) {
          return t.call(n, e, i++);
        }),
        r
      );
    }
    function le(e) {
      if (e._status === -1) {
        var t = e._result,
          n = t();
        (n.then(
          function (t) {
            (e._status === 0 || e._status === -1) &&
              ((e._status = 1),
              (e._result = t),
              n.status === void 0 && ((n.status = `fulfilled`), (n.value = t)));
          },
          function (t) {
            (e._status === 0 || e._status === -1) &&
              ((e._status = 2),
              (e._result = t),
              n.status === void 0 && ((n.status = `rejected`), (n.reason = t)));
          },
        ),
          e._status === -1 && ((e._status = 0), (e._result = n)));
      }
      if (e._status === 1) return e._result.default;
      throw e._result;
    }
    var ue =
      typeof reportError == `function`
        ? reportError
        : function (e) {
            if (
              typeof window == `object` &&
              typeof window.ErrorEvent == `function`
            ) {
              var t = new window.ErrorEvent(`error`, {
                bubbles: !0,
                cancelable: !0,
                message:
                  typeof e == `object` && e && typeof e.message == `string`
                    ? String(e.message)
                    : String(e),
                error: e,
              });
              if (!window.dispatchEvent(t)) return;
            } else if (
              typeof process == `object` &&
              typeof process.emit == `function`
            ) {
              process.emit(`uncaughtException`, e);
              return;
            }
            console.error(e);
          };
    function de(e) {
      var t = S.T,
        n = {};
      ((n.types = t === null ? null : t.types), (S.T = n));
      try {
        var r = e(),
          i = S.S;
        (i !== null && i(n, r),
          typeof r == `object` &&
            r &&
            typeof r.then == `function` &&
            r.then(ne, ue));
      } catch (e) {
        ue(e);
      } finally {
        (t !== null && n.types !== null && (t.types = n.types), (S.T = t));
      }
    }
    function fe(e) {
      var t = S.T;
      if (t !== null) {
        var n = t.types;
        n === null ? (t.types = [e]) : n.indexOf(e) === -1 && n.push(e);
      } else de(fe.bind(null, e));
    }
    var pe = {
      map: E,
      forEach: function (e, t, n) {
        E(
          e,
          function () {
            t.apply(this, arguments);
          },
          n,
        );
      },
      count: function (e) {
        var t = 0;
        return (
          E(e, function () {
            t++;
          }),
          t
        );
      },
      toArray: function (e) {
        return (
          E(e, function (e) {
            return e;
          }) || []
        );
      },
      only: function (e) {
        if (!w(e))
          throw Error(
            `React.Children.only expected to receive a single React element child.`,
          );
        return e;
      },
    };
    ((e.Activity = f),
      (e.Children = pe),
      (e.Component = y),
      (e.Fragment = r),
      (e.Profiler = a),
      (e.PureComponent = ee),
      (e.StrictMode = i),
      (e.Suspense = l),
      (e.ViewTransition = p),
      (e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = S),
      (e.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function (e) {
          return S.H.useMemoCache(e);
        },
      }),
      (e.addTransitionType = fe),
      (e.cache = function (e) {
        return function () {
          return e.apply(null, arguments);
        };
      }),
      (e.cacheSignal = function () {
        return null;
      }),
      (e.cloneElement = function (e, t, n) {
        if (e == null)
          throw Error(
            `The argument must be a React element, but you passed ` + e + `.`,
          );
        var r = _({}, e.props),
          i = e.key;
        if (t != null)
          for (a in (t.key !== void 0 && (i = `` + t.key), t))
            !re.call(t, a) ||
              a === `key` ||
              a === `__self` ||
              a === `__source` ||
              (a === `ref` && t.ref === void 0) ||
              (r[a] = t[a]);
        var a = arguments.length - 2;
        if (a === 1) r.children = n;
        else if (1 < a) {
          for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
          r.children = o;
        }
        return C(e.type, i, r);
      }),
      (e.createContext = function (e) {
        return (
          (e = {
            $$typeof: s,
            _currentValue: e,
            _currentValue2: e,
            _threadCount: 0,
            Provider: null,
            Consumer: null,
          }),
          (e.Provider = e),
          (e.Consumer = {
            $$typeof: o,
            _context: e,
          }),
          e
        );
      }),
      (e.createElement = function (e, t, n) {
        var r,
          i = {},
          a = null;
        if (t != null)
          for (r in (t.key !== void 0 && (a = `` + t.key), t))
            re.call(t, r) &&
              r !== `key` &&
              r !== `__self` &&
              r !== `__source` &&
              (i[r] = t[r]);
        var o = arguments.length - 2;
        if (o === 1) i.children = n;
        else if (1 < o) {
          for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
          i.children = s;
        }
        if (e && e.defaultProps)
          for (r in ((o = e.defaultProps), o)) i[r] === void 0 && (i[r] = o[r]);
        return C(e, a, i);
      }),
      (e.createRef = function () {
        return {
          current: null,
        };
      }),
      (e.forwardRef = function (e) {
        return {
          $$typeof: c,
          render: e,
        };
      }),
      (e.isValidElement = w),
      (e.lazy = function (e) {
        return {
          $$typeof: d,
          _payload: {
            _status: -1,
            _result: e,
          },
          _init: le,
        };
      }),
      (e.memo = function (e, t) {
        return {
          $$typeof: u,
          type: e,
          compare: t === void 0 ? null : t,
        };
      }),
      (e.startTransition = de),
      (e.unstable_useCacheRefresh = function () {
        return S.H.useCacheRefresh();
      }),
      (e.use = function (e) {
        return S.H.use(e);
      }),
      (e.useActionState = function (e, t, n) {
        return S.H.useActionState(e, t, n);
      }),
      (e.useCallback = function (e, t) {
        return S.H.useCallback(e, t);
      }),
      (e.useContext = function (e) {
        return S.H.useContext(e);
      }),
      (e.useDebugValue = function () {}),
      (e.useDeferredValue = function (e, t) {
        return S.H.useDeferredValue(e, t);
      }),
      (e.useEffect = function (e, t) {
        return S.H.useEffect(e, t);
      }),
      (e.useEffectEvent = function (e) {
        return S.H.useEffectEvent(e);
      }),
      (e.useId = function () {
        return S.H.useId();
      }),
      (e.useImperativeHandle = function (e, t, n) {
        return S.H.useImperativeHandle(e, t, n);
      }),
      (e.useInsertionEffect = function (e, t) {
        return S.H.useInsertionEffect(e, t);
      }),
      (e.useLayoutEffect = function (e, t) {
        return S.H.useLayoutEffect(e, t);
      }),
      (e.useMemo = function (e, t) {
        return S.H.useMemo(e, t);
      }),
      (e.useOptimistic = function (e, t) {
        return S.H.useOptimistic(e, t);
      }),
      (e.useReducer = function (e, t, n) {
        return S.H.useReducer(e, t, n);
      }),
      (e.useRef = function (e) {
        return S.H.useRef(e);
      }),
      (e.useState = function (e) {
        return S.H.useState(e);
      }),
      (e.useSyncExternalStore = function (e, t, n) {
        return S.H.useSyncExternalStore(e, t, n);
      }),
      (e.useTransition = function () {
        return S.H.useTransition();
      }),
      (e.version = `19.3.0`));
  }),
  u = o((e, t) => {
    t.exports = l();
  }),
  d = o((e) => {
    function t(e, t) {
      var n = e.length;
      e.push(t);
      a: for (; 0 < n;) {
        var r = (n - 1) >>> 1,
          a = e[r];
        if (0 < i(a, t)) ((e[r] = t), (e[n] = a), (n = r));
        else break a;
      }
    }
    function n(e) {
      return e.length === 0 ? null : e[0];
    }
    function r(e) {
      if (e.length === 0) return null;
      var t = e[0],
        n = e.pop();
      if (n !== t) {
        e[0] = n;
        a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
          var s = 2 * (r + 1) - 1,
            c = e[s],
            l = s + 1,
            u = e[l];
          if (0 > i(c, n))
            l < a && 0 > i(u, c)
              ? ((e[r] = u), (e[l] = n), (r = l))
              : ((e[r] = c), (e[s] = n), (r = s));
          else if (l < a && 0 > i(u, n)) ((e[r] = u), (e[l] = n), (r = l));
          else break a;
        }
      }
      return t;
    }
    function i(e, t) {
      var n = e.sortIndex - t.sortIndex;
      return n === 0 ? e.id - t.id : n;
    }
    if (
      ((e.unstable_now = void 0),
      typeof performance == `object` && typeof performance.now == `function`)
    ) {
      var a = performance;
      e.unstable_now = function () {
        return a.now();
      };
    } else {
      var o = Date,
        s = o.now();
      e.unstable_now = function () {
        return o.now() - s;
      };
    }
    var c = [],
      l = [],
      u = 1,
      d = null,
      f = 3,
      p = !1,
      m = !1,
      h = !1,
      g = !1,
      _ = typeof setTimeout == `function` ? setTimeout : null,
      v = typeof clearTimeout == `function` ? clearTimeout : null,
      y = typeof setImmediate < `u` ? setImmediate : null;
    function b(e) {
      for (var i = n(l); i !== null;) {
        if (i.callback === null) r(l);
        else if (i.startTime <= e)
          (r(l), (i.sortIndex = i.expirationTime), t(c, i));
        else break;
        i = n(l);
      }
    }
    function ee(e) {
      if (((h = !1), b(e), !m)) {
        if (n(c) !== null) ((m = !0), x || ((x = !0), ie()));
        else {
          var t = n(l);
          t !== null && ae(ee, t.startTime - e);
        }
      }
    }
    var x = !1,
      te = -1,
      ne = 5,
      S = -1;
    function re() {
      return g ? !0 : !(e.unstable_now() - S < ne);
    }
    function C() {
      if (((g = !1), x)) {
        var t = e.unstable_now();
        S = t;
        var i = !0;
        try {
          a: {
            ((m = !1), h && ((h = !1), v(te), (te = -1)), (p = !0));
            var a = f;
            try {
              b: {
                for (
                  b(t), d = n(c);
                  d !== null && !(d.expirationTime > t && re());
                ) {
                  var o = d.callback;
                  if (typeof o == `function`) {
                    ((d.callback = null), (f = d.priorityLevel));
                    var s = o(d.expirationTime <= t);
                    if (((t = e.unstable_now()), typeof s == `function`)) {
                      ((d.callback = s), b(t), (i = !0));
                      break b;
                    }
                    (d === n(c) && r(c), b(t));
                  } else r(c);
                  d = n(c);
                }
                if (d !== null) i = !0;
                else {
                  var u = n(l);
                  (u !== null && ae(ee, u.startTime - t), (i = !1));
                }
              }
              break a;
            } finally {
              ((d = null), (f = a), (p = !1));
            }
            i = void 0;
          }
        } finally {
          i ? ie() : (x = !1);
        }
      }
    }
    var ie;
    if (typeof y == `function`)
      ie = function () {
        y(C);
      };
    else if (typeof MessageChannel < `u`) {
      var w = new MessageChannel(),
        T = w.port2;
      ((w.port1.onmessage = C),
        (ie = function () {
          T.postMessage(null);
        }));
    } else
      ie = function () {
        _(C, 0);
      };
    function ae(t, n) {
      te = _(function () {
        t(e.unstable_now());
      }, n);
    }
    ((e.unstable_IdlePriority = 5),
      (e.unstable_ImmediatePriority = 1),
      (e.unstable_LowPriority = 4),
      (e.unstable_NormalPriority = 3),
      (e.unstable_Profiling = null),
      (e.unstable_UserBlockingPriority = 2),
      (e.unstable_cancelCallback = function (e) {
        e.callback = null;
      }),
      (e.unstable_forceFrameRate = function (e) {
        0 > e || 125 < e
          ? console.error(
              `forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`,
            )
          : (ne = 0 < e ? Math.floor(1e3 / e) : 5);
      }),
      (e.unstable_getCurrentPriorityLevel = function () {
        return f;
      }),
      (e.unstable_next = function (e) {
        switch (f) {
          case 1:
          case 2:
          case 3:
            var t = 3;
            break;
          default:
            t = f;
        }
        var n = f;
        f = t;
        try {
          return e();
        } finally {
          f = n;
        }
      }),
      (e.unstable_requestPaint = function () {
        g = !0;
      }),
      (e.unstable_runWithPriority = function (e, t) {
        switch (e) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            e = 3;
        }
        var n = f;
        f = e;
        try {
          return t();
        } finally {
          f = n;
        }
      }),
      (e.unstable_scheduleCallback = function (r, i, a) {
        var o = e.unstable_now();
        switch (
          (typeof a == `object` && a
            ? ((a = a.delay), (a = typeof a == `number` && 0 < a ? o + a : o))
            : (a = o),
          r)
        ) {
          case 1:
            var s = -1;
            break;
          case 2:
            s = 250;
            break;
          case 5:
            s = 1073741823;
            break;
          case 4:
            s = 1e4;
            break;
          default:
            s = 5e3;
        }
        return (
          (s = a + s),
          (r = {
            id: u++,
            callback: i,
            priorityLevel: r,
            startTime: a,
            expirationTime: s,
            sortIndex: -1,
          }),
          a > o
            ? ((r.sortIndex = a),
              t(l, r),
              n(c) === null &&
                r === n(l) &&
                (h ? (v(te), (te = -1)) : (h = !0), ae(ee, a - o)))
            : ((r.sortIndex = s),
              t(c, r),
              m || p || ((m = !0), x || ((x = !0), ie()))),
          r
        );
      }),
      (e.unstable_shouldYield = re),
      (e.unstable_wrapCallback = function (e) {
        var t = f;
        return function () {
          var n = f;
          f = t;
          try {
            return e.apply(this, arguments);
          } finally {
            f = n;
          }
        };
      }));
  }),
  f = o((e, t) => {
    t.exports = d();
  }),
  p = o((e) => {
    var t = u();
    function n(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++)
          t += `&args[]=` + encodeURIComponent(arguments[n]);
      }
      return (
        `Minified React error #` +
        e +
        `; visit ` +
        t +
        ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
      );
    }
    function r() {}
    var i = {
        d: {
          f: r,
          r: function () {
            throw Error(n(522));
          },
          D: r,
          C: r,
          L: r,
          m: r,
          X: r,
          S: r,
          M: r,
        },
        p: 0,
        findDOMNode: null,
      },
      a = Symbol.for(`react.portal`),
      o = Symbol.for(`react.recoverable`),
      s = Symbol.for(`react.optimistic_key`);
    function c(e, t, n) {
      var r =
        3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return {
        $$typeof: a,
        key: r == null ? null : r === s ? s : `` + r,
        children: e,
        containerInfo: t,
        implementation: n,
      };
    }
    var l = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function d(e, t) {
      if (e === `font`) return ``;
      if (typeof t == `string`) return t === `use-credentials` ? t : ``;
    }
    ((e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i),
      (e.browser = function (e) {
        return {
          $$typeof: o,
          _reason: e,
        };
      }),
      (e.createPortal = function (e, t) {
        var r =
          2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!t || (t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11))
          throw Error(n(299));
        return c(e, t, null, r);
      }),
      (e.flushSync = function (e) {
        var t = l.T,
          n = i.p;
        try {
          if (((l.T = null), (i.p = 2), e)) return e();
        } finally {
          ((l.T = t), (i.p = n), i.d.f());
        }
      }),
      (e.preconnect = function (e, t) {
        typeof e == `string` &&
          (t
            ? ((t = t.crossOrigin),
              (t =
                typeof t == `string`
                  ? t === `use-credentials`
                    ? t
                    : ``
                  : void 0))
            : (t = null),
          i.d.C(e, t));
      }),
      (e.prefetchDNS = function (e) {
        typeof e == `string` && i.d.D(e);
      }),
      (e.preinit = function (e, t) {
        if (typeof e == `string` && t && typeof t.as == `string`) {
          var n = t.as,
            r = d(n, t.crossOrigin),
            a = typeof t.integrity == `string` ? t.integrity : void 0,
            o = typeof t.fetchPriority == `string` ? t.fetchPriority : void 0;
          n === `style`
            ? i.d.S(
                e,
                typeof t.precedence == `string` ? t.precedence : void 0,
                {
                  crossOrigin: r,
                  integrity: a,
                  fetchPriority: o,
                },
              )
            : n === `script` &&
              i.d.X(e, {
                crossOrigin: r,
                integrity: a,
                fetchPriority: o,
                nonce: typeof t.nonce == `string` ? t.nonce : void 0,
              });
        }
      }),
      (e.preinitModule = function (e, t) {
        if (typeof e == `string`) {
          if (typeof t == `object` && t) {
            if (t.as == null || t.as === `script`) {
              var n = d(t.as, t.crossOrigin);
              i.d.M(e, {
                crossOrigin: n,
                integrity:
                  typeof t.integrity == `string` ? t.integrity : void 0,
                nonce: typeof t.nonce == `string` ? t.nonce : void 0,
                fetchPriority:
                  typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
              });
            }
          } else t ?? i.d.M(e);
        }
      }),
      (e.preload = function (e, t) {
        if (
          typeof e == `string` &&
          typeof t == `object` &&
          t &&
          typeof t.as == `string`
        ) {
          var n = t.as,
            r = d(n, t.crossOrigin);
          i.d.L(e, n, {
            crossOrigin: r,
            integrity: typeof t.integrity == `string` ? t.integrity : void 0,
            nonce: typeof t.nonce == `string` ? t.nonce : void 0,
            type: typeof t.type == `string` ? t.type : void 0,
            fetchPriority:
              typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
            referrerPolicy:
              typeof t.referrerPolicy == `string` ? t.referrerPolicy : void 0,
            imageSrcSet:
              typeof t.imageSrcSet == `string` ? t.imageSrcSet : void 0,
            imageSizes: typeof t.imageSizes == `string` ? t.imageSizes : void 0,
            media: typeof t.media == `string` ? t.media : void 0,
          });
        }
      }),
      (e.preloadModule = function (e, t) {
        if (typeof e == `string`) {
          if (t) {
            var n = d(t.as, t.crossOrigin);
            i.d.m(e, {
              as: typeof t.as == `string` && t.as !== `script` ? t.as : void 0,
              crossOrigin: n,
              integrity: typeof t.integrity == `string` ? t.integrity : void 0,
              nonce: typeof t.nonce == `string` ? t.nonce : void 0,
              fetchPriority:
                typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
            });
          } else i.d.m(e);
        }
      }),
      (e.requestFormReset = function (e) {
        i.d.r(e);
      }),
      (e.unstable_batchedUpdates = function (e, t) {
        return e(t);
      }),
      (e.useFormState = function (e, t, n) {
        return l.H.useFormState(e, t, n);
      }),
      (e.useFormStatus = function () {
        return l.H.useHostTransitionStatus();
      }),
      (e.version = `19.3.0`));
  }),
  m = o((e, t) => {
    function n() {
      if (
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u` &&
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == `function`
      )
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
        } catch (e) {
          console.error(e);
        }
    }
    (n(), (t.exports = p()));
  }),
  h = o((e) => {
    var t = f(),
      n = u(),
      r = m();
    function i(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++)
          t += `&args[]=` + encodeURIComponent(arguments[n]);
      }
      return (
        `Minified React error #` +
        e +
        `; visit ` +
        t +
        ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
      );
    }
    function a(e) {
      return !(
        !e ||
        (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
      );
    }
    function o(e) {
      for (var t = e, n = t; n && !n.alternate;)
        ((t = n), t.flags & 4098 && (e = t.return), (n = t.return));
      for (; t.return;) t = t.return;
      return t.tag === 3 ? e : null;
    }
    function s(e) {
      if (e.tag === 13) {
        var t = e.memoizedState;
        if (
          (t === null &&
            ((e = e.alternate), e !== null && (t = e.memoizedState)),
          t !== null)
        )
          return t.dehydrated;
      }
      return null;
    }
    function c(e) {
      if (e.tag === 31) {
        var t = e.memoizedState;
        if (
          (t === null &&
            ((e = e.alternate), e !== null && (t = e.memoizedState)),
          t !== null)
        )
          return t.dehydrated;
      }
      return null;
    }
    function l(e) {
      if (o(e) !== e) throw Error(i(188));
    }
    function d(e) {
      var t = e.alternate;
      if (!t) {
        if (((t = o(e)), t === null)) throw Error(i(188));
        return t === e ? e : null;
      }
      for (var n = e, r = t; ;) {
        var a = n.return;
        if (a === null) break;
        var s = a.alternate;
        if (s === null) {
          if (((r = a.return), r !== null)) {
            n = r;
            continue;
          }
          break;
        }
        if (a.child === s.child) {
          for (s = a.child; s;) {
            if (s === n) return (l(a), e);
            if (s === r) return (l(a), t);
            s = s.sibling;
          }
          throw Error(i(188));
        }
        if (n.return !== r.return) ((n = a), (r = s));
        else {
          for (var c = !1, u = a.child; u;) {
            if (u === n) {
              ((c = !0), (n = a), (r = s));
              break;
            }
            if (u === r) {
              ((c = !0), (r = a), (n = s));
              break;
            }
            u = u.sibling;
          }
          if (!c) {
            for (u = s.child; u;) {
              if (u === n) {
                ((c = !0), (n = s), (r = a));
                break;
              }
              if (u === r) {
                ((c = !0), (r = s), (n = a));
                break;
              }
              u = u.sibling;
            }
            if (!c) throw Error(i(189));
          }
        }
        if (n.alternate !== r) throw Error(i(190));
      }
      if (n.tag !== 3) throw Error(i(188));
      return n.stateNode.current === n ? e : t;
    }
    function p(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e;
      for (e = e.child; e !== null;) {
        if (((t = p(e)), t !== null)) return t;
        e = e.sibling;
      }
      return null;
    }
    function h(e, t, n, r, i, a) {
      for (; e !== null;) {
        if (
          ((e.tag === 5 || e.tag === 27 || e.tag === 6) && n(e, r, i, a)) ||
          ((e.tag !== 22 || e.memoizedState === null) &&
            (t || (e.tag !== 5 && e.tag !== 27)) &&
            h(e.child, t, n, r, i, a))
        )
          return !0;
        e = e.sibling;
      }
      return !1;
    }
    function g(e) {
      for (e = e.return; e !== null;) {
        if (e.tag === 3 || e.tag === 5 || e.tag === 27) return e;
        e = e.return;
      }
      return null;
    }
    function _(e) {
      var t = !1;
      for (
        e = e.return;
        e !== null &&
        (e.tag === 4 && (t = !0), e.tag !== 3 && e.tag !== 5 && e.tag !== 27);
      )
        e = e.return;
      return t;
    }
    function v(e) {
      var t = [null, null],
        n = g(e);
      return (
        n === null ||
          y(t, e, n.child, {
            foundSelf: !1,
          }),
        t
      );
    }
    function y(e, t, n, r) {
      for (; n !== null;) {
        if (n === t) r.foundSelf = !0;
        else if (n.tag === 5 || n.tag === 27 || n.tag === 6) {
          if (r.foundSelf) return ((e[1] = n), !0);
          e[0] = n;
        } else if (
          (n.tag !== 22 || n.memoizedState === null) &&
          y(e, t, n.child, r)
        )
          return !0;
        n = n.sibling;
      }
      return !1;
    }
    function b(e) {
      switch (e.tag) {
        case 5:
        case 27:
        case 6:
          return e.stateNode;
        case 3:
          return e.stateNode.containerInfo;
        default:
          throw Error(i(559));
      }
    }
    var ee = null,
      x = null;
    function te(e, t, n) {
      return e === n || (e === t && ((ee = e), !0));
    }
    function ne(e, t, n) {
      return e === n ? ((x = e), !1) : e === t && (x !== null && (ee = e), !0);
    }
    function S(e) {
      if (e === null) return null;
      do e = e === null ? null : e.return;
      while (e && e.tag !== 5 && e.tag !== 27 && e.tag !== 3);
      return e || null;
    }
    function re(e, t, n) {
      for (var r = 0, i = e; i; i = n(i)) r++;
      i = 0;
      for (var a = t; a; a = n(a)) i++;
      for (; 0 < r - i;) ((e = n(e)), r--);
      for (; 0 < i - r;) ((t = n(t)), i--);
      for (; r--;) {
        if (e === t || (t !== null && e === t.alternate)) return e;
        ((e = n(e)), (t = n(t)));
      }
      return null;
    }
    var C = Object.assign,
      ie = Symbol.for(`react.element`),
      w = Symbol.for(`react.transitional.element`),
      T = Symbol.for(`react.portal`),
      ae = Symbol.for(`react.fragment`),
      oe = Symbol.for(`react.strict_mode`),
      se = Symbol.for(`react.profiler`),
      ce = Symbol.for(`react.consumer`),
      E = Symbol.for(`react.context`),
      le = Symbol.for(`react.forward_ref`),
      ue = Symbol.for(`react.suspense`),
      de = Symbol.for(`react.suspense_list`),
      fe = Symbol.for(`react.memo`),
      pe = Symbol.for(`react.lazy`),
      me = Symbol.for(`react.activity`),
      he = Symbol.for(`react.legacy_hidden`),
      ge = Symbol.for(`react.memo_cache_sentinel`),
      _e = Symbol.for(`react.view_transition`),
      ve = Symbol.for(`react.recoverable`),
      ye = Symbol.iterator;
    function be(e) {
      return typeof e != `object` || !e
        ? null
        : ((e = (ye && e[ye]) || e[`@@iterator`]),
          typeof e == `function` ? e : null);
    }
    var xe = Symbol.for(`react.client.reference`);
    function Se(e) {
      if (e == null) return null;
      if (typeof e == `function`)
        return e.$$typeof === xe ? null : e.displayName || e.name || null;
      if (typeof e == `string`) return e;
      switch (e) {
        case ae:
          return `Fragment`;
        case se:
          return `Profiler`;
        case oe:
          return `StrictMode`;
        case ue:
          return `Suspense`;
        case de:
          return `SuspenseList`;
        case me:
          return `Activity`;
        case _e:
          return `ViewTransition`;
      }
      if (typeof e == `object`)
        switch (e.$$typeof) {
          case T:
            return `Portal`;
          case E:
            return e.displayName || `Context`;
          case ce:
            return (e._context.displayName || `Context`) + `.Consumer`;
          case le:
            var t = e.render;
            return (
              (e = e.displayName),
              (e ||=
                ((e = t.displayName || t.name || ``),
                e === `` ? `ForwardRef` : `ForwardRef(` + e + `)`)),
              e
            );
          case fe:
            return (
              (t = e.displayName || null),
              t === null ? Se(e.type) || `Memo` : t
            );
          case pe:
            ((t = e._payload), (e = e._init));
            try {
              return Se(e(t));
            } catch {}
        }
      return null;
    }
    var Ce = Array.isArray,
      D = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      O = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      we = {
        pending: !1,
        data: null,
        method: null,
        action: null,
      },
      Te = [],
      Ee = -1;
    function De(e) {
      return {
        current: e,
      };
    }
    function Oe(e) {
      0 > Ee || ((e.current = Te[Ee]), (Te[Ee] = null), Ee--);
    }
    function k(e, t) {
      (Ee++, (Te[Ee] = e.current), (e.current = t));
    }
    var ke = De(null),
      Ae = De(null),
      je = De(null),
      Me = De(null);
    function Ne(e, t) {
      switch ((k(je, t), k(Ae, e), k(ke, null), t.nodeType)) {
        case 9:
        case 11:
          e = (e = t.documentElement) && (e = e.namespaceURI) ? up(e) : 0;
          break;
        default:
          if (((e = t.tagName), (t = t.namespaceURI)))
            ((t = up(t)), (e = dp(t, e)));
          else
            switch (e) {
              case `svg`:
                e = 1;
                break;
              case `math`:
                e = 2;
                break;
              default:
                e = 0;
            }
      }
      (Oe(ke), k(ke, e));
    }
    function Pe() {
      (Oe(ke), Oe(Ae), Oe(je));
    }
    function Fe(e) {
      var t = e.memoizedState;
      (t !== null && ((sh._currentValue = t.memoizedState), k(Me, e)),
        (t = ke.current));
      var n = dp(t, e.type);
      t !== n && (k(Ae, e), k(ke, n));
    }
    function Ie(e) {
      (Ae.current === e && (Oe(ke), Oe(Ae)),
        Me.current === e && (Oe(Me), (sh._currentValue = we)));
    }
    var Le, Re;
    function ze(e) {
      if (Le === void 0)
        try {
          throw Error();
        } catch (e) {
          var t = e.stack.trim().match(/\n( *(at )?)/);
          ((Le = (t && t[1]) || ``),
            (Re =
              -1 <
              e.stack.indexOf(`
          at`)
                ? ` (<anonymous>)`
                : -1 < e.stack.indexOf(`@`)
                  ? `@unknown:0:0`
                  : ``));
        }
      return (
        `
    ` +
        Le +
        e +
        Re
      );
    }
    var Be = !1;
    function Ve(e, t) {
      if (!e || Be) return ``;
      Be = !0;
      var n = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var r = {
          DetermineComponentFrameRoot: function () {
            try {
              if (t) {
                var n = function () {
                  throw Error();
                };
                if (
                  (Object.defineProperty(n.prototype, "props", {
                    set: function () {
                      throw Error();
                    },
                  }),
                  typeof Reflect == `object` && Reflect.construct)
                ) {
                  try {
                    Reflect.construct(n, []);
                  } catch (e) {
                    var r = e;
                  }
                  Reflect.construct(e, [], n);
                } else {
                  try {
                    n.call();
                  } catch (e) {
                    r = e;
                  }
                  n = !1;
                  try {
                    var i = Object.getOwnPropertyDescriptor(
                      e.prototype,
                      `props`,
                    );
                    (Object.defineProperty(e.prototype, "props", {
                      configurable: !0,
                      set: function () {
                        throw Error();
                      },
                    }),
                      (n = !0),
                      new e());
                  } finally {
                    n &&
                      (i === void 0
                        ? delete e.prototype.props
                        : Object.defineProperty(e.prototype, "props", i));
                  }
                }
              } else {
                try {
                  throw Error();
                } catch (e) {
                  r = e;
                }
                (n = e()) &&
                  typeof n.catch == `function` &&
                  n.catch(function () {});
              }
            } catch (e) {
              if (e && r && typeof e.stack == `string`)
                return [e.stack, r.stack];
            }
            return [null, null];
          },
        };
        r.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
        var i = Object.getOwnPropertyDescriptor(
          r.DetermineComponentFrameRoot,
          `name`,
        );
        i &&
          i.configurable &&
          Object.defineProperty(r.DetermineComponentFrameRoot, "name", {
            value: `DetermineComponentFrameRoot`,
          });
        var a = r.DetermineComponentFrameRoot(),
          o = a[0],
          s = a[1];
        if (o && s) {
          var c = o.split(`
        `),
            l = s.split(`
        `);
          for (
            i = r = 0;
            r < c.length && !c[r].includes(`DetermineComponentFrameRoot`);
          )
            r++;
          for (; i < l.length && !l[i].includes(`DetermineComponentFrameRoot`);)
            i++;
          if (r === c.length || i === l.length)
            for (
              r = c.length - 1, i = l.length - 1;
              1 <= r && 0 <= i && c[r] !== l[i];
            )
              i--;
          for (; 1 <= r && 0 <= i; r--, i--)
            if (c[r] !== l[i]) {
              if (r !== 1 || i !== 1)
                do
                  if ((r--, i--, 0 > i || c[r] !== l[i])) {
                    var u =
                      `
            ` + c[r].replace(` at new `, ` at `);
                    return (
                      e.displayName &&
                        u.includes(`<anonymous>`) &&
                        (u = u.replace(`<anonymous>`, e.displayName)),
                      u
                    );
                  }
                while (1 <= r && 0 <= i);
              break;
            }
        }
      } finally {
        ((Be = !1), (Error.prepareStackTrace = n));
      }
      return (n = e ? e.displayName || e.name : ``) ? ze(n) : ``;
    }
    function He(e, t) {
      switch (e.tag) {
        case 26:
        case 27:
        case 5:
          return ze(e.type);
        case 16:
          return ze(`Lazy`);
        case 13:
          return e.child !== t && t !== null
            ? ze(`Suspense Fallback`)
            : ze(`Suspense`);
        case 19:
          return ze(`SuspenseList`);
        case 0:
        case 15:
          return Ve(e.type, !1);
        case 11:
          return Ve(e.type.render, !1);
        case 1:
          return Ve(e.type, !0);
        case 31:
          return ze(`Activity`);
        case 30:
          return ze(`ViewTransition`);
        default:
          return ``;
      }
    }
    function Ue(e) {
      try {
        var t = ``,
          n = null;
        do ((t += He(e, n)), (n = e), (e = e.return));
        while (e);
        return t;
      } catch (e) {
        return (
          `
      Error generating stack: ` +
          e.message +
          `
      ` +
          e.stack
        );
      }
    }
    var We = Object.prototype.hasOwnProperty,
      Ge = t.unstable_scheduleCallback,
      Ke = t.unstable_cancelCallback,
      qe = t.unstable_shouldYield,
      Je = t.unstable_requestPaint,
      Ye = t.unstable_now,
      Xe = t.unstable_getCurrentPriorityLevel,
      Ze = t.unstable_ImmediatePriority,
      Qe = t.unstable_UserBlockingPriority,
      $e = t.unstable_NormalPriority,
      et = t.unstable_LowPriority,
      tt = t.unstable_IdlePriority,
      nt = t.log,
      rt = t.unstable_setDisableYieldValue,
      it = null,
      at = null;
    function ot(e) {
      if (
        (typeof nt == `function` && rt(e),
        at && typeof at.setStrictMode == `function`)
      )
        try {
          at.setStrictMode(it, e);
        } catch {}
    }
    var st = Math.clz32 ? Math.clz32 : ut,
      ct = Math.log,
      lt = Math.LN2;
    function ut(e) {
      return ((e >>>= 0), e === 0 ? 32 : (31 - ((ct(e) / lt) | 0)) | 0);
    }
    var dt = 256,
      ft = 262144,
      pt = 4194304;
    function mt(e) {
      var t = e & 42;
      if (t !== 0) return t;
      switch (e & -e) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return e & -e;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return e & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return e;
      }
    }
    function ht(e, t, n) {
      var r = e.pendingLanes;
      if (r === 0) return 0;
      var i = 0,
        a = e.suspendedLanes,
        o = e.pingedLanes;
      e = e.warmLanes;
      var s = r & 134217727;
      return (
        s === 0
          ? ((s = r & ~a),
            s === 0
              ? o === 0
                ? n || ((n = r & ~e), n !== 0 && (i = mt(n)))
                : (i = mt(o))
              : (i = mt(s)))
          : ((r = s & ~a),
            r === 0
              ? ((o &= s),
                o === 0
                  ? n || ((n = s & ~e), n !== 0 && (i = mt(n)))
                  : (i = mt(o)))
              : (i = mt(r))),
        i === 0
          ? 0
          : t !== 0 &&
              t !== i &&
              (t & a) === 0 &&
              ((a = i & -i), (n = t & -t), a >= n || (a === 32 && n & 4194048))
            ? t
            : i
      );
    }
    function gt(e, t) {
      return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
    }
    function _t(e, t) {
      t & 8 && (t |= t & 32);
      var n = e.entangledLanes;
      if (n !== 0)
        for (e = e.entanglements, n &= t; 0 < n;) {
          var r = 31 - st(n),
            i = 1 << r;
          ((t |= e[r]), (n &= ~i));
        }
      return t;
    }
    function vt(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return t + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function yt() {
      var e = pt;
      return ((pt <<= 1), !(pt & 62914560) && (pt = 4194304), e);
    }
    function bt(e) {
      for (var t = [], n = 0; 31 > n; n++) t.push(e);
      return t;
    }
    function xt(e, t) {
      ((e.pendingLanes |= t),
        t !== 268435456 &&
          ((e.suspendedLanes = 0), (e.pingedLanes = 0), (e.warmLanes = 0)));
    }
    function St(e, t, n, r, i, a) {
      var o = e.pendingLanes;
      ((e.pendingLanes = n),
        (e.suspendedLanes = 0),
        (e.pingedLanes = 0),
        (e.warmLanes = 0),
        (e.expiredLanes &= n),
        (e.entangledLanes &= n),
        (e.errorRecoveryDisabledLanes &= n),
        (e.shellSuspendCounter = 0));
      var s = e.entanglements,
        c = e.expirationTimes,
        l = e.hiddenUpdates;
      for (n = o & ~n; 0 < n;) {
        var u = 31 - st(n),
          d = 1 << u;
        ((s[u] = 0), (c[u] = -1));
        var f = l[u];
        if (f !== null)
          for (l[u] = null, u = 0; u < f.length; u++) {
            var p = f[u];
            p !== null && (p.lane &= -536870913);
          }
        n &= ~d;
      }
      (r !== 0 && Ct(e, r, 0),
        a !== 0 &&
          i === 0 &&
          e.tag !== 0 &&
          (e.suspendedLanes |= a & ~(o & ~t)));
    }
    function Ct(e, t, n) {
      ((e.pendingLanes |= t), (e.suspendedLanes &= ~t));
      var r = 31 - st(t);
      ((e.entangledLanes |= t),
        (e.entanglements[r] = e.entanglements[r] | 1073741824 | (n & 261930)));
    }
    function wt(e, t) {
      var n = (e.entangledLanes |= t);
      for (e = e.entanglements; n;) {
        var r = 31 - st(n),
          i = 1 << r;
        ((i & t) | (e[r] & t) && (e[r] |= t), (n &= ~i));
      }
    }
    function Tt(e, t) {
      var n = t & -t;
      return (
        (n = n & 42 ? 1 : Et(n)),
        (n & (e.suspendedLanes | t)) === 0 ? n : 0
      );
    }
    function Et(e) {
      switch (e) {
        case 2:
          e = 1;
          break;
        case 8:
          e = 4;
          break;
        case 32:
          e = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          e = 128;
          break;
        case 268435456:
          e = 134217728;
          break;
        default:
          e = 0;
      }
      return e;
    }
    function Dt(e) {
      return (
        (e &= -e),
        2 < e ? (8 < e ? (e & 134217727 ? 32 : 268435456) : 8) : 2
      );
    }
    function Ot() {
      var e = O.p;
      return e === 0 ? ((e = window.event), e === void 0 ? 32 : Ch(e.type)) : e;
    }
    function kt(e, t) {
      var n = O.p;
      try {
        return ((O.p = e), t());
      } finally {
        O.p = n;
      }
    }
    var At = Math.random().toString(36).slice(2),
      jt = `__reactFiber$` + At,
      Mt = `__reactProps$` + At,
      Nt = `__reactContainer$` + At,
      Pt = `__reactEvents$` + At,
      Ft = `__reactListeners$` + At,
      It = `__reactHandles$` + At,
      Lt = `__reactResources$` + At,
      Rt = `__reactMarker$` + At,
      zt = `__reactLoad$` + At;
    function Bt(e) {
      (delete e[jt], delete e[Mt], delete e[Ft], delete e[It]);
    }
    function Vt(e) {
      var t;
      if ((t = e[jt])) return t;
      for (var n = e.parentNode; n;) {
        if ((t = n[Nt] || n[jt])) {
          if (
            ((n = t.alternate),
            t.child !== null || (n !== null && n.child !== null))
          )
            for (e = fm(e); e !== null;) {
              if ((n = e[jt])) return n;
              e = fm(e);
            }
          return t;
        }
        ((e = n), (n = e.parentNode));
      }
      return null;
    }
    function Ht(e) {
      if ((e = e[jt] || e[Nt])) {
        var t = e.tag;
        if (
          t === 5 ||
          t === 6 ||
          t === 13 ||
          t === 31 ||
          t === 26 ||
          t === 27 ||
          t === 3
        )
          return e;
      }
      return null;
    }
    function Ut(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
      throw Error(i(33));
    }
    function Wt(e) {
      var t = e[Lt];
      return (
        (t ||= e[Lt] =
          {
            hoistableStyles: new Map(),
            hoistableScripts: new Map(),
          }),
        t
      );
    }
    function Gt(e) {
      e[Rt] = !0;
    }
    function Kt(e) {
      e[zt] = void 0;
    }
    var qt = new Set(),
      Jt = {};
    function Yt(e, t) {
      (Xt(e, t), Xt(e + `Capture`, t));
    }
    function Xt(e, t) {
      for (Jt[e] = t, e = 0; e < t.length; e++) qt.add(t[e]);
    }
    var Zt = RegExp(
        `^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`,
      ),
      Qt = {},
      $t = {};
    function en(e) {
      return We.call($t, e)
        ? !0
        : We.call(Qt, e)
          ? !1
          : Zt.test(e)
            ? ($t[e] = !0)
            : ((Qt[e] = !0), !1);
    }
    var A = !1;
    function tn() {
      var e = A;
      return ((A = !1), e);
    }
    function nn(e, t, n) {
      if (en(t)) {
        if (n === null) e.removeAttribute(t);
        else {
          switch (typeof n) {
            case `undefined`:
            case `function`:
            case `symbol`:
              e.removeAttribute(t);
              return;
            case `boolean`:
              var r = t.toLowerCase().slice(0, 5);
              if (r !== `data-` && r !== `aria-`) {
                e.removeAttribute(t);
                return;
              }
          }
          e.setAttribute(t, n);
        }
      }
    }
    function rn(e, t, n) {
      if (n === null) e.removeAttribute(t);
      else {
        switch (typeof n) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(t);
            return;
        }
        e.setAttribute(t, n);
      }
    }
    function an(e, t, n, r) {
      if (r === null) e.removeAttribute(n);
      else {
        switch (typeof r) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(n);
            return;
        }
        e.setAttributeNS(t, n, r);
      }
    }
    function on(e) {
      switch (typeof e) {
        case `bigint`:
        case `boolean`:
        case `number`:
        case `string`:
        case `undefined`:
          return e;
        case `object`:
          return e;
        default:
          return ``;
      }
    }
    function sn(e) {
      var t = e.type;
      return (
        (e = e.nodeName) &&
        e.toLowerCase() === `input` &&
        (t === `checkbox` || t === `radio`)
      );
    }
    function cn(e, t, n) {
      var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
      if (
        !e.hasOwnProperty(t) &&
        r !== void 0 &&
        typeof r.get == `function` &&
        typeof r.set == `function`
      ) {
        var i = r.get,
          a = r.set;
        return (
          Object.defineProperty(e, t, {
            configurable: !0,
            get: function () {
              return i.call(this);
            },
            set: function (e) {
              ((n = `` + e), a.call(this, e));
            },
          }),
          Object.defineProperty(e, t, {
            enumerable: r.enumerable,
          }),
          {
            getValue: function () {
              return n;
            },
            setValue: function (e) {
              n = `` + e;
            },
            stopTracking: function () {
              ((e._valueTracker = null), delete e[t]);
            },
          }
        );
      }
    }
    function ln(e) {
      if (!e._valueTracker) {
        var t = sn(e) ? `checked` : `value`;
        e._valueTracker = cn(e, t, `` + e[t]);
      }
    }
    function un(e) {
      if (!e) return !1;
      var t = e._valueTracker;
      if (!t) return !0;
      var n = t.getValue(),
        r = ``;
      return (
        e && (r = sn(e) ? (e.checked ? `true` : `false`) : e.value),
        (e = r),
        e !== n && (t.setValue(e), !0)
      );
    }
    var dn = /[\n"\\]/g;
    function fn(e) {
      return e.replace(dn, function (e) {
        return `\\` + e.charCodeAt(0).toString(16) + ` `;
      });
    }
    function pn(e, t, n, r, i, a, o, s) {
      ((e.name = ``),
        o != null &&
        typeof o != `function` &&
        typeof o != `symbol` &&
        typeof o != `boolean`
          ? (e.type = o)
          : e.removeAttribute(`type`),
        t == null
          ? (o !== `submit` && o !== `reset`) || e.removeAttribute(`value`)
          : o === `number`
            ? ((t === 0 && e.value === ``) || e.value != t) &&
              (e.value = `` + on(t))
            : e.value !== `` + on(t) && (e.value = `` + on(t)),
        t == null
          ? n == null
            ? r != null && e.removeAttribute(`value`)
            : hn(e, on(n))
          : o === `number` && e.value == t
            ? hn(e, on(e.value))
            : hn(e, on(t)),
        i == null && a != null && (e.defaultChecked = !!a),
        i != null &&
          (e.checked = i && typeof i != `function` && typeof i != `symbol`),
        s != null &&
        typeof s != `function` &&
        typeof s != `symbol` &&
        typeof s != `boolean`
          ? (e.name = `` + on(s))
          : e.removeAttribute(`name`));
    }
    function mn(e, t, n, r, i, a, o, s) {
      if (
        (a != null &&
          typeof a != `function` &&
          typeof a != `symbol` &&
          typeof a != `boolean` &&
          (e.type = a),
        t != null || n != null)
      ) {
        if (!((a !== `submit` && a !== `reset`) || t != null)) {
          ln(e);
          return;
        }
        ((n = n == null ? `` : `` + on(n)),
          (t = t == null ? n : `` + on(t)),
          s || t === e.value || (e.value = t),
          (e.defaultValue = t));
      }
      ((r ??= i),
        (r = typeof r != `function` && typeof r != `symbol` && !!r),
        (e.checked = s ? e.checked : !!r),
        (e.defaultChecked = !!r),
        o != null &&
          typeof o != `function` &&
          typeof o != `symbol` &&
          typeof o != `boolean` &&
          (e.name = o),
        ln(e));
    }
    function hn(e, t) {
      e.defaultValue !== `` + t && (e.defaultValue = `` + t);
    }
    function gn(e, t, n, r) {
      if (((e = e.options), t)) {
        t = {};
        for (var i = 0; i < n.length; i++) t[`$` + n[i]] = !0;
        for (n = 0; n < e.length; n++)
          ((i = t.hasOwnProperty(`$` + e[n].value)),
            e[n].selected !== i && (e[n].selected = i),
            i && r && (e[n].defaultSelected = !0));
      } else {
        for (n = `` + on(n), t = null, i = 0; i < e.length; i++) {
          if (e[i].value === n) {
            ((e[i].selected = !0), r && (e[i].defaultSelected = !0));
            return;
          }
          t !== null || e[i].disabled || (t = e[i]);
        }
        t !== null && (t.selected = !0);
      }
    }
    function _n(e, t, n) {
      if (
        t != null &&
        ((t = `` + on(t)), t !== e.value && (e.value = t), n == null)
      ) {
        e.defaultValue !== t && (e.defaultValue = t);
        return;
      }
      e.defaultValue = n == null ? `` : `` + on(n);
    }
    function vn(e, t, n, r) {
      if (t == null) {
        if (r != null) {
          if (n != null) throw Error(i(92));
          if (Ce(r)) {
            if (1 < r.length) throw Error(i(93));
            r = r[0];
          }
          n = r;
        }
        ((n ??= ``), (t = n));
      }
      ((n = on(t)),
        (e.defaultValue = n),
        (r = e.textContent),
        r === n && r !== `` && r !== null && (e.value = r),
        ln(e));
    }
    function yn(e, t) {
      if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
          n.nodeValue = t;
          return;
        }
      }
      e.textContent = t;
    }
    var bn = new Set(
      `animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(
        ` `,
      ),
    );
    function xn(e, t, n) {
      var r = t.indexOf(`--`) === 0;
      n == null || typeof n == `boolean` || n === ``
        ? r
          ? e.setProperty(t, ``)
          : t === `float`
            ? (e.cssFloat = ``)
            : (e[t] = ``)
        : r
          ? e.setProperty(t, n)
          : typeof n != `number` || n === 0 || bn.has(t)
            ? t === `float`
              ? (e.cssFloat = n)
              : (e[t] = (`` + n).trim())
            : (e[t] = n + `px`);
    }
    function Sn(e, t, n) {
      if (t != null && typeof t != `object`) throw Error(i(62));
      if (((e = e.style), n != null)) {
        for (var r in n)
          !n.hasOwnProperty(r) ||
            (t != null && t.hasOwnProperty(r)) ||
            (r.indexOf(`--`) === 0
              ? e.setProperty(r, ``)
              : r === `float`
                ? (e.cssFloat = ``)
                : (e[r] = ``),
            (A = !0));
        for (var a in t)
          ((r = t[a]),
            t.hasOwnProperty(a) && n[a] !== r && (xn(e, a, r), (A = !0)));
      } else for (var o in t) t.hasOwnProperty(o) && xn(e, o, t[o]);
    }
    function Cn(e) {
      if (e.indexOf(`-`) === -1) return !1;
      switch (e) {
        case `annotation-xml`:
        case `color-profile`:
        case `font-face`:
        case `font-face-src`:
        case `font-face-uri`:
        case `font-face-format`:
        case `font-face-name`:
        case `missing-glyph`:
          return !1;
        default:
          return !0;
      }
    }
    var wn = new Map([
        [`acceptCharset`, `accept-charset`],
        [`htmlFor`, `for`],
        [`httpEquiv`, `http-equiv`],
        [`crossOrigin`, `crossorigin`],
        [`accentHeight`, `accent-height`],
        [`alignmentBaseline`, `alignment-baseline`],
        [`arabicForm`, `arabic-form`],
        [`baselineShift`, `baseline-shift`],
        [`capHeight`, `cap-height`],
        [`clipPath`, `clip-path`],
        [`clipRule`, `clip-rule`],
        [`colorInterpolation`, `color-interpolation`],
        [`colorInterpolationFilters`, `color-interpolation-filters`],
        [`colorProfile`, `color-profile`],
        [`colorRendering`, `color-rendering`],
        [`dominantBaseline`, `dominant-baseline`],
        [`enableBackground`, `enable-background`],
        [`fillOpacity`, `fill-opacity`],
        [`fillRule`, `fill-rule`],
        [`floodColor`, `flood-color`],
        [`floodOpacity`, `flood-opacity`],
        [`fontFamily`, `font-family`],
        [`fontSize`, `font-size`],
        [`fontSizeAdjust`, `font-size-adjust`],
        [`fontStretch`, `font-stretch`],
        [`fontStyle`, `font-style`],
        [`fontVariant`, `font-variant`],
        [`fontWeight`, `font-weight`],
        [`glyphName`, `glyph-name`],
        [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`],
        [`glyphOrientationVertical`, `glyph-orientation-vertical`],
        [`horizAdvX`, `horiz-adv-x`],
        [`horizOriginX`, `horiz-origin-x`],
        [`imageRendering`, `image-rendering`],
        [`letterSpacing`, `letter-spacing`],
        [`lightingColor`, `lighting-color`],
        [`markerEnd`, `marker-end`],
        [`markerMid`, `marker-mid`],
        [`markerStart`, `marker-start`],
        [`maskType`, `mask-type`],
        [`overlinePosition`, `overline-position`],
        [`overlineThickness`, `overline-thickness`],
        [`paintOrder`, `paint-order`],
        [`panose-1`, `panose-1`],
        [`pointerEvents`, `pointer-events`],
        [`renderingIntent`, `rendering-intent`],
        [`shapeRendering`, `shape-rendering`],
        [`stopColor`, `stop-color`],
        [`stopOpacity`, `stop-opacity`],
        [`strikethroughPosition`, `strikethrough-position`],
        [`strikethroughThickness`, `strikethrough-thickness`],
        [`strokeDasharray`, `stroke-dasharray`],
        [`strokeDashoffset`, `stroke-dashoffset`],
        [`strokeLinecap`, `stroke-linecap`],
        [`strokeLinejoin`, `stroke-linejoin`],
        [`strokeMiterlimit`, `stroke-miterlimit`],
        [`strokeOpacity`, `stroke-opacity`],
        [`strokeWidth`, `stroke-width`],
        [`textAnchor`, `text-anchor`],
        [`textDecoration`, `text-decoration`],
        [`textRendering`, `text-rendering`],
        [`transformOrigin`, `transform-origin`],
        [`underlinePosition`, `underline-position`],
        [`underlineThickness`, `underline-thickness`],
        [`unicodeBidi`, `unicode-bidi`],
        [`unicodeRange`, `unicode-range`],
        [`unitsPerEm`, `units-per-em`],
        [`vAlphabetic`, `v-alphabetic`],
        [`vHanging`, `v-hanging`],
        [`vIdeographic`, `v-ideographic`],
        [`vMathematical`, `v-mathematical`],
        [`vectorEffect`, `vector-effect`],
        [`vertAdvY`, `vert-adv-y`],
        [`vertOriginX`, `vert-origin-x`],
        [`vertOriginY`, `vert-origin-y`],
        [`wordSpacing`, `word-spacing`],
        [`writingMode`, `writing-mode`],
        [`xmlnsXlink`, `xmlns:xlink`],
        [`xHeight`, `x-height`],
      ]),
      Tn =
        /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function En(e) {
      return Tn.test(`` + e)
        ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`
        : e;
    }
    function Dn() {}
    var On = null;
    function kn(e) {
      return (
        (e = e.target || e.srcElement || window),
        e.correspondingUseElement && (e = e.correspondingUseElement),
        e.nodeType === 3 ? e.parentNode : e
      );
    }
    var An = null,
      jn = null;
    function Mn(e) {
      var t = Ht(e);
      if (t && (e = t.stateNode)) {
        var n = e[Mt] || null;
        a: switch (((e = t.stateNode), t.type)) {
          case `input`:
            if (
              (pn(
                e,
                n.value,
                n.defaultValue,
                n.defaultValue,
                n.checked,
                n.defaultChecked,
                n.type,
                n.name,
              ),
              (t = n.name),
              n.type === `radio` && t != null)
            ) {
              for (n = e; n.parentNode;) n = n.parentNode;
              for (
                n = n.querySelectorAll(
                  `input[name="` + fn(`` + t) + `"][type="radio"]`,
                ),
                  t = 0;
                t < n.length;
                t++
              ) {
                var r = n[t];
                if (r !== e && r.form === e.form) {
                  var a = r[Mt] || null;
                  if (!a) throw Error(i(90));
                  pn(
                    r,
                    a.value,
                    a.defaultValue,
                    a.defaultValue,
                    a.checked,
                    a.defaultChecked,
                    a.type,
                    a.name,
                  );
                }
              }
              for (t = 0; t < n.length; t++)
                ((r = n[t]), r.form === e.form && un(r));
            }
            break a;
          case `textarea`:
            _n(e, n.value, n.defaultValue);
            break a;
          case `select`:
            ((t = n.value), t != null && gn(e, !!n.multiple, t, !1));
        }
      }
    }
    var Nn = !1;
    function Pn(e, t, n) {
      if (Nn) return e(t, n);
      Nn = !0;
      try {
        return e(t);
      } finally {
        if (
          ((Nn = !1),
          (An !== null || jn !== null) &&
            (zd(), An && ((t = An), (e = jn), (jn = An = null), Mn(t), e)))
        )
          for (t = 0; t < e.length; t++) Mn(e[t]);
      }
    }
    function Fn(e, t) {
      var n = e.stateNode;
      if (n === null) return null;
      var r = n[Mt] || null;
      if (r === null) return null;
      n = r[t];
      a: switch (t) {
        case `onClick`:
        case `onClickCapture`:
        case `onDoubleClick`:
        case `onDoubleClickCapture`:
        case `onMouseDown`:
        case `onMouseDownCapture`:
        case `onMouseMove`:
        case `onMouseMoveCapture`:
        case `onMouseUp`:
        case `onMouseUpCapture`:
        case `onMouseEnter`:
          ((r = !r.disabled) ||
            ((e = e.type),
            (r =
              e !== `button` &&
              e !== `input` &&
              e !== `select` &&
              e !== `textarea`)),
            (e = !r));
          break a;
        default:
          e = !1;
      }
      if (e) return null;
      if (n && typeof n != `function`) throw Error(i(231, t, typeof n));
      return n;
    }
    var In =
        typeof window < `u` &&
        window.document !== void 0 &&
        window.document.createElement !== void 0,
      j = !1;
    if (In)
      try {
        var Ln = {};
        (Object.defineProperty(Ln, "passive", {
          get: function () {
            j = !0;
          },
        }),
          window.addEventListener(`test`, Ln, Ln),
          window.removeEventListener(`test`, Ln, Ln));
      } catch {
        j = !1;
      }
    var Rn = null,
      zn = null,
      Bn = null;
    function Vn() {
      if (Bn) return Bn;
      var e,
        t = zn,
        n = t.length,
        r,
        i = `value` in Rn ? Rn.value : Rn.textContent,
        a = i.length;
      for (e = 0; e < n && t[e] === i[e]; e++);
      var o = n - e;
      for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
      return (Bn = i.slice(e, 1 < r ? 1 - r : void 0));
    }
    function Hn(e) {
      var t = e.keyCode;
      return (
        `charCode` in e
          ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
          : (e = t),
        e === 10 && (e = 13),
        32 <= e || e === 13 ? e : 0
      );
    }
    function Un() {
      return !0;
    }
    function Wn() {
      return !1;
    }
    function Gn(e) {
      function t(t, n, r, i, a) {
        for (var o in ((this._reactName = t),
        (this._targetInst = r),
        (this.type = n),
        (this.nativeEvent = i),
        (this.target = a),
        (this.currentTarget = null),
        e))
          e.hasOwnProperty(o) && ((t = e[o]), (this[o] = t ? t(i) : i[o]));
        return (
          (this.isDefaultPrevented = (
            i.defaultPrevented == null
              ? !1 === i.returnValue
              : i.defaultPrevented
          )
            ? Un
            : Wn),
          (this.isPropagationStopped = Wn),
          this
        );
      }
      return (
        C(t.prototype, {
          preventDefault: function () {
            this.defaultPrevented = !0;
            var e = this.nativeEvent;
            e &&
              (e.preventDefault
                ? e.preventDefault()
                : typeof e.returnValue != `unknown` && (e.returnValue = !1),
              (this.isDefaultPrevented = Un));
          },
          stopPropagation: function () {
            var e = this.nativeEvent;
            e &&
              (e.stopPropagation
                ? e.stopPropagation()
                : typeof e.cancelBubble != `unknown` && (e.cancelBubble = !0),
              (this.isPropagationStopped = Un));
          },
          persist: function () {},
          isPersistent: Un,
        }),
        t
      );
    }
    var Kn = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function (e) {
          return e.timeStamp || Date.now();
        },
        defaultPrevented: 0,
        isTrusted: 0,
      },
      qn = Gn(Kn),
      Jn = C({}, Kn, {
        view: 0,
        detail: 0,
      }),
      Yn = Gn(Jn),
      M,
      Xn,
      N,
      P = C({}, Jn, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: sr,
        button: 0,
        buttons: 0,
        relatedTarget: function (e) {
          return e.relatedTarget === void 0
            ? e.fromElement === e.srcElement
              ? e.toElement
              : e.fromElement
            : e.relatedTarget;
        },
        movementX: function (e) {
          return `movementX` in e
            ? e.movementX
            : (e !== N &&
                (N && e.type === `mousemove`
                  ? ((M = e.screenX - N.screenX), (Xn = e.screenY - N.screenY))
                  : (Xn = M = 0),
                (N = e)),
              M);
        },
        movementY: function (e) {
          return `movementY` in e ? e.movementY : Xn;
        },
      }),
      Zn = Gn(P),
      Qn = Gn(
        C({}, P, {
          dataTransfer: 0,
        }),
      ),
      $n = Gn(
        C({}, Jn, {
          relatedTarget: 0,
        }),
      ),
      er = Gn(
        C({}, Kn, {
          animationName: 0,
          elapsedTime: 0,
          pseudoElement: 0,
        }),
      ),
      tr = Gn(
        C({}, Kn, {
          clipboardData: function (e) {
            return `clipboardData` in e
              ? e.clipboardData
              : window.clipboardData;
          },
        }),
      ),
      nr = Gn(
        C({}, Kn, {
          data: 0,
        }),
      ),
      rr = {
        Esc: `Escape`,
        Spacebar: ` `,
        Left: `ArrowLeft`,
        Up: `ArrowUp`,
        Right: `ArrowRight`,
        Down: `ArrowDown`,
        Del: `Delete`,
        Win: `OS`,
        Menu: `ContextMenu`,
        Apps: `ContextMenu`,
        Scroll: `ScrollLock`,
        MozPrintableKey: `Unidentified`,
      },
      ir = {
        8: `Backspace`,
        9: `Tab`,
        12: `Clear`,
        13: `Enter`,
        16: `Shift`,
        17: `Control`,
        18: `Alt`,
        19: `Pause`,
        20: `CapsLock`,
        27: `Escape`,
        32: ` `,
        33: `PageUp`,
        34: `PageDown`,
        35: `End`,
        36: `Home`,
        37: `ArrowLeft`,
        38: `ArrowUp`,
        39: `ArrowRight`,
        40: `ArrowDown`,
        45: `Insert`,
        46: `Delete`,
        112: `F1`,
        113: `F2`,
        114: `F3`,
        115: `F4`,
        116: `F5`,
        117: `F6`,
        118: `F7`,
        119: `F8`,
        120: `F9`,
        121: `F10`,
        122: `F11`,
        123: `F12`,
        144: `NumLock`,
        145: `ScrollLock`,
        224: `Meta`,
      },
      ar = {
        Alt: `altKey`,
        Control: `ctrlKey`,
        Meta: `metaKey`,
        Shift: `shiftKey`,
      };
    function or(e) {
      var t = this.nativeEvent;
      return t.getModifierState
        ? t.getModifierState(e)
        : (e = ar[e])
          ? !!t[e]
          : !1;
    }
    function sr() {
      return or;
    }
    var cr = Gn(
        C({}, Jn, {
          key: function (e) {
            if (e.key) {
              var t = rr[e.key] || e.key;
              if (t !== `Unidentified`) return t;
            }
            return e.type === `keypress`
              ? ((e = Hn(e)), e === 13 ? `Enter` : String.fromCharCode(e))
              : e.type === `keydown` || e.type === `keyup`
                ? ir[e.keyCode] || `Unidentified`
                : ``;
          },
          code: 0,
          location: 0,
          ctrlKey: 0,
          shiftKey: 0,
          altKey: 0,
          metaKey: 0,
          repeat: 0,
          locale: 0,
          getModifierState: sr,
          charCode: function (e) {
            return e.type === `keypress` ? Hn(e) : 0;
          },
          keyCode: function (e) {
            return e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0;
          },
          which: function (e) {
            return e.type === `keypress`
              ? Hn(e)
              : e.type === `keydown` || e.type === `keyup`
                ? e.keyCode
                : 0;
          },
        }),
      ),
      lr = Gn(
        C({}, P, {
          pointerId: 0,
          width: 0,
          height: 0,
          pressure: 0,
          tangentialPressure: 0,
          tiltX: 0,
          tiltY: 0,
          twist: 0,
          pointerType: 0,
          isPrimary: 0,
        }),
      ),
      ur = Gn(
        C({}, Kn, {
          submitter: 0,
        }),
      ),
      dr = Gn(
        C({}, Jn, {
          touches: 0,
          targetTouches: 0,
          changedTouches: 0,
          altKey: 0,
          metaKey: 0,
          ctrlKey: 0,
          shiftKey: 0,
          getModifierState: sr,
        }),
      ),
      fr = Gn(
        C({}, Kn, {
          propertyName: 0,
          elapsedTime: 0,
          pseudoElement: 0,
        }),
      ),
      pr = Gn(
        C({}, P, {
          deltaX: function (e) {
            return `deltaX` in e
              ? e.deltaX
              : `wheelDeltaX` in e
                ? -e.wheelDeltaX
                : 0;
          },
          deltaY: function (e) {
            return `deltaY` in e
              ? e.deltaY
              : `wheelDeltaY` in e
                ? -e.wheelDeltaY
                : `wheelDelta` in e
                  ? -e.wheelDelta
                  : 0;
          },
          deltaZ: 0,
          deltaMode: 0,
        }),
      ),
      mr = Gn(
        C({}, Kn, {
          newState: 0,
          oldState: 0,
          source: 0,
        }),
      ),
      hr = [9, 13, 27, 32],
      gr = In && `CompositionEvent` in window,
      _r = null;
    In && `documentMode` in document && (_r = document.documentMode);
    var vr = In && `TextEvent` in window && !_r,
      yr = In && (!gr || (_r && 8 < _r && 11 >= _r)),
      br = ` `,
      xr = !1;
    function Sr(e, t) {
      switch (e) {
        case `keyup`:
          return hr.indexOf(t.keyCode) !== -1;
        case `keydown`:
          return t.keyCode !== 229;
        case `keypress`:
        case `mousedown`:
        case `focusout`:
          return !0;
        default:
          return !1;
      }
    }
    function Cr(e) {
      return (
        (e = e.detail),
        typeof e == `object` && `data` in e ? e.data : null
      );
    }
    var wr = !1;
    function Tr(e, t) {
      switch (e) {
        case `compositionend`:
          return Cr(t);
        case `keypress`:
          return t.which === 32 ? ((xr = !0), br) : null;
        case `textInput`:
          return ((e = t.data), e === br && xr ? null : e);
        default:
          return null;
      }
    }
    function Er(e, t) {
      if (wr)
        return e === `compositionend` || (!gr && Sr(e, t))
          ? ((e = Vn()), (Bn = zn = Rn = null), (wr = !1), e)
          : null;
      switch (e) {
        case `paste`:
          return null;
        case `keypress`:
          if (
            !(t.ctrlKey || t.altKey || t.metaKey) ||
            (t.ctrlKey && t.altKey)
          ) {
            if (t.char && 1 < t.char.length) return t.char;
            if (t.which) return String.fromCharCode(t.which);
          }
          return null;
        case `compositionend`:
          return yr && t.locale !== `ko` ? null : t.data;
        default:
          return null;
      }
    }
    var Dr = {
      color: !0,
      date: !0,
      datetime: !0,
      "datetime-local": !0,
      email: !0,
      month: !0,
      number: !0,
      password: !0,
      range: !0,
      search: !0,
      tel: !0,
      text: !0,
      time: !0,
      url: !0,
      week: !0,
    };
    function Or(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === `input` ? !!Dr[e.type] : t === `textarea`;
    }
    function kr(e, t, n, r) {
      (An ? (jn ? jn.push(r) : (jn = [r])) : (An = r),
        (t = Jf(t, `onChange`)),
        0 < t.length &&
          ((n = new qn(`onChange`, `change`, null, n, r)),
          e.push({
            event: n,
            listeners: t,
          })));
    }
    var Ar = null,
      jr = null;
    function Mr(e) {
      Vf(e, 0);
    }
    function Nr(e) {
      if (un(Ut(e))) return e;
    }
    function Pr(e, t) {
      if (e === `change`) return t;
    }
    var Fr = !1;
    if (In) {
      var Ir;
      if (In) {
        var Lr = `oninput` in document;
        if (!Lr) {
          var Rr = document.createElement(`div`);
          (Rr.setAttribute(`oninput`, `return;`),
            (Lr = typeof Rr.oninput == `function`));
        }
        Ir = Lr;
      } else Ir = !1;
      Fr = Ir && (!document.documentMode || 9 < document.documentMode);
    }
    function zr() {
      Ar && (Ar.detachEvent(`onpropertychange`, Br), (jr = Ar = null));
    }
    function Br(e) {
      if (e.propertyName === `value` && Nr(jr)) {
        var t = [];
        (kr(t, jr, e, kn(e)), Pn(Mr, t));
      }
    }
    function Vr(e, t, n) {
      e === `focusin`
        ? (zr(), (Ar = t), (jr = n), Ar.attachEvent(`onpropertychange`, Br))
        : e === `focusout` && zr();
    }
    function Hr(e) {
      if (e === `selectionchange` || e === `keyup` || e === `keydown`)
        return Nr(jr);
    }
    function Ur(e, t) {
      if (e === `click`) return Nr(t);
    }
    function Wr(e, t) {
      if (e === `input` || e === `change`) return Nr(t);
    }
    function Gr(e, t) {
      return (e === t && (e !== 0 || 1 / e == 1 / t)) || (e !== e && t !== t);
    }
    var Kr = typeof Object.is == `function` ? Object.is : Gr;
    function qr(e, t) {
      if (Kr(e, t)) return !0;
      if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
      var n = Object.keys(e),
        r = Object.keys(t);
      if (n.length !== r.length) return !1;
      for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!We.call(t, i) || !Kr(e[i], t[i])) return !1;
      }
      return !0;
    }
    function Jr(e) {
      if (((e ||= typeof document < `u` ? document : void 0), e === void 0))
        return null;
      try {
        return e.activeElement || e.body;
      } catch {
        return e.body;
      }
    }
    function Yr(e) {
      for (; e && e.firstChild;) e = e.firstChild;
      return e;
    }
    function Xr(e, t) {
      var n = Yr(e);
      e = 0;
      for (var r; n;) {
        if (n.nodeType === 3) {
          if (((r = e + n.textContent.length), e <= t && r >= t))
            return {
              node: n,
              offset: t - e,
            };
          e = r;
        }
        a: {
          for (; n;) {
            if (n.nextSibling) {
              n = n.nextSibling;
              break a;
            }
            n = n.parentNode;
          }
          n = void 0;
        }
        n = Yr(n);
      }
    }
    function Zr(e, t) {
      return e && t
        ? e === t
          ? !0
          : e && e.nodeType === 3
            ? !1
            : t && t.nodeType === 3
              ? Zr(e, t.parentNode)
              : `contains` in e
                ? e.contains(t)
                : e.compareDocumentPosition
                  ? !!(e.compareDocumentPosition(t) & 16)
                  : !1
        : !1;
    }
    function Qr(e) {
      e =
        e != null &&
        e.ownerDocument != null &&
        e.ownerDocument.defaultView != null
          ? e.ownerDocument.defaultView
          : window;
      for (var t = Jr(e.document); t instanceof e.HTMLIFrameElement;) {
        try {
          var n = typeof t.contentWindow.location.href == `string`;
        } catch {
          n = !1;
        }
        if (n) e = t.contentWindow;
        else break;
        t = Jr(e.document);
      }
      return t;
    }
    function $r(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return (
        t &&
        ((t === `input` &&
          (e.type === `text` ||
            e.type === `search` ||
            e.type === `tel` ||
            e.type === `url` ||
            e.type === `password`)) ||
          t === `textarea` ||
          e.contentEditable === `true`)
      );
    }
    var ei = In && `documentMode` in document && 11 >= document.documentMode,
      ti = null,
      ni = null,
      ri = null,
      ii = !1;
    function ai(e, t, n) {
      var r =
        n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
      ii ||
        ti == null ||
        ti !== Jr(r) ||
        ((r = ti),
        `selectionStart` in r && $r(r)
          ? (r = {
              start: r.selectionStart,
              end: r.selectionEnd,
            })
          : ((r = (
              (r.ownerDocument && r.ownerDocument.defaultView) ||
              window
            ).getSelection()),
            (r = {
              anchorNode: r.anchorNode,
              anchorOffset: r.anchorOffset,
              focusNode: r.focusNode,
              focusOffset: r.focusOffset,
            })),
        (ri && qr(ri, r)) ||
          ((ri = r),
          (r = Jf(ni, `onSelect`)),
          0 < r.length &&
            ((t = new qn(`onSelect`, `select`, null, t, n)),
            e.push({
              event: t,
              listeners: r,
            }),
            (t.target = ti))));
    }
    function oi(e, t) {
      var n = {};
      return (
        (n[e.toLowerCase()] = t.toLowerCase()),
        (n[`Webkit` + e] = `webkit` + t),
        (n[`Moz` + e] = `moz` + t),
        n
      );
    }
    var si = {
        animationend: oi(`Animation`, `AnimationEnd`),
        animationiteration: oi(`Animation`, `AnimationIteration`),
        animationstart: oi(`Animation`, `AnimationStart`),
        transitionrun: oi(`Transition`, `TransitionRun`),
        transitionstart: oi(`Transition`, `TransitionStart`),
        transitioncancel: oi(`Transition`, `TransitionCancel`),
        transitionend: oi(`Transition`, `TransitionEnd`),
      },
      ci = {},
      li = {};
    In &&
      ((li = document.createElement(`div`).style),
      `AnimationEvent` in window ||
        (delete si.animationend.animation,
        delete si.animationiteration.animation,
        delete si.animationstart.animation),
      `TransitionEvent` in window || delete si.transitionend.transition);
    function ui(e) {
      if (ci[e]) return ci[e];
      if (!si[e]) return e;
      var t = si[e],
        n;
      for (n in t) if (t.hasOwnProperty(n) && n in li) return (ci[e] = t[n]);
      return e;
    }
    var di = ui(`animationend`),
      fi = ui(`animationiteration`),
      pi = ui(`animationstart`),
      mi = ui(`transitionrun`),
      hi = ui(`transitionstart`),
      gi = ui(`transitioncancel`),
      _i = ui(`transitionend`),
      vi = new Map(),
      yi =
        `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(
          ` `,
        );
    yi.push(`scrollEnd`);
    function bi(e, t) {
      (vi.set(e, t), Yt(t, [e]));
    }
    var xi = 0;
    function Si(e, t) {
      if (e.name != null && e.name !== `auto`) return e.name;
      if (t.autoName !== null) return t.autoName;
      e = bd.identifierPrefix;
      var n = xi++;
      return ((e = `_` + e + `t_` + n.toString(32) + `_`), (t.autoName = e));
    }
    function Ci(e) {
      if (e == null || typeof e == `string`) return e;
      var t = null,
        n = Od;
      if (n !== null)
        for (var r = 0; r < n.length; r++) {
          var i = e[n[r]];
          if (i != null) {
            if (i === `none`) return `none`;
            t = t == null ? i : t + (` ` + i);
          }
        }
      return t ?? e.default;
    }
    function wi(e, t) {
      return (
        (e = Ci(e)),
        (t = Ci(t)),
        t == null ? (e === `auto` ? null : e) : t === `auto` ? null : t
      );
    }
    var Ti =
        typeof reportError == `function`
          ? reportError
          : function (e) {
              if (
                typeof window == `object` &&
                typeof window.ErrorEvent == `function`
              ) {
                var t = new window.ErrorEvent(`error`, {
                  bubbles: !0,
                  cancelable: !0,
                  message:
                    typeof e == `object` && e && typeof e.message == `string`
                      ? String(e.message)
                      : String(e),
                  error: e,
                });
                if (!window.dispatchEvent(t)) return;
              } else if (
                typeof process == `object` &&
                typeof process.emit == `function`
              ) {
                process.emit(`uncaughtException`, e);
                return;
              }
              console.error(e);
            },
      Ei = [],
      Di = 0,
      Oi = 0;
    function ki() {
      for (var e = Di, t = (Oi = Di = 0); t < e;) {
        var n = Ei[t];
        Ei[t++] = null;
        var r = Ei[t];
        Ei[t++] = null;
        var i = Ei[t];
        Ei[t++] = null;
        var a = Ei[t];
        if (((Ei[t++] = null), r !== null && i !== null)) {
          var o = r.pending;
          (o === null ? (i.next = i) : ((i.next = o.next), (o.next = i)),
            (r.pending = i));
        }
        a !== 0 && Ni(n, i, a);
      }
    }
    function Ai(e, t, n, r) {
      ((Ei[Di++] = e),
        (Ei[Di++] = t),
        (Ei[Di++] = n),
        (Ei[Di++] = r),
        (Oi |= r),
        (e.lanes |= r),
        (e = e.alternate),
        e !== null && (e.lanes |= r));
    }
    function ji(e, t, n, r) {
      return (Ai(e, t, n, r), Pi(e));
    }
    function Mi(e, t) {
      return (Ai(e, null, null, t), Pi(e));
    }
    function Ni(e, t, n) {
      e.lanes |= n;
      var r = e.alternate;
      r !== null && (r.lanes |= n);
      for (var i = !1, a = e.return; a !== null;)
        ((a.childLanes |= n),
          (r = a.alternate),
          r !== null && (r.childLanes |= n),
          a.tag === 22 &&
            ((e = a.stateNode), e === null || e._visibility & 1 || (i = !0)),
          (e = a),
          (a = a.return));
      return e.tag === 3
        ? ((a = e.stateNode),
          i &&
            t !== null &&
            ((i = 31 - st(n)),
            (e = a.hiddenUpdates),
            (r = e[i]),
            r === null ? (e[i] = [t]) : r.push(t),
            (t.lane = n | 536870912)),
          a)
        : null;
    }
    function Pi(e) {
      if (50 < kd) throw ((kd = 0), (Ad = null), Error(i(185)));
      for (var t = e.return; t !== null;) ((e = t), (t = e.return));
      return e.tag === 3 ? e.stateNode : null;
    }
    var Fi = {};
    function Ii(e, t, n, r) {
      ((this.tag = e),
        (this.key = n),
        (this.sibling =
          this.child =
          this.return =
          this.stateNode =
          this.type =
          this.elementType =
            null),
        (this.index = 0),
        (this.refCleanup = this.ref = null),
        (this.pendingProps = t),
        (this.dependencies =
          this.memoizedState =
          this.updateQueue =
          this.memoizedProps =
            null),
        (this.mode = r),
        (this.subtreeFlags = this.flags = 0),
        (this.deletions = null),
        (this.childLanes = this.lanes = 0),
        (this.alternate = null));
    }
    function Li(e, t, n, r) {
      return new Ii(e, t, n, r);
    }
    function Ri(e) {
      return ((e = e.prototype), !(!e || !e.isReactComponent));
    }
    function zi(e, t) {
      var n = e.alternate;
      return (
        n === null
          ? ((n = Li(e.tag, t, e.key, e.mode)),
            (n.elementType = e.elementType),
            (n.type = e.type),
            (n.stateNode = e.stateNode),
            (n.alternate = e),
            (e.alternate = n))
          : ((n.pendingProps = t),
            (n.type = e.type),
            (n.flags = 0),
            (n.subtreeFlags = 0),
            (n.deletions = null)),
        (n.flags = e.flags & 1206910976),
        (n.childLanes = e.childLanes),
        (n.lanes = e.lanes),
        (n.child = e.child),
        (n.memoizedProps = e.memoizedProps),
        (n.memoizedState = e.memoizedState),
        (n.updateQueue = e.updateQueue),
        (t = e.dependencies),
        (n.dependencies =
          t === null
            ? null
            : {
                lanes: t.lanes,
                firstContext: t.firstContext,
              }),
        (n.sibling = e.sibling),
        (n.index = e.index),
        (n.ref = e.ref),
        (n.refCleanup = e.refCleanup),
        n
      );
    }
    function Bi(e, t) {
      e.flags &= 1206910978;
      var n = e.alternate;
      return (
        n === null
          ? ((e.childLanes = 0),
            (e.lanes = t),
            (e.child = null),
            (e.subtreeFlags = 0),
            (e.memoizedProps = null),
            (e.memoizedState = null),
            (e.updateQueue = null),
            (e.dependencies = null),
            (e.stateNode = null))
          : ((e.childLanes = n.childLanes),
            (e.lanes = n.lanes),
            (e.child = n.child),
            (e.subtreeFlags = 0),
            (e.deletions = null),
            (e.memoizedProps = n.memoizedProps),
            (e.memoizedState = n.memoizedState),
            (e.updateQueue = n.updateQueue),
            (e.type = n.type),
            (t = n.dependencies),
            (e.dependencies =
              t === null
                ? null
                : {
                    lanes: t.lanes,
                    firstContext: t.firstContext,
                  })),
        e
      );
    }
    function Vi(e, t, n, r, a, o) {
      var s = 0;
      if (((r = e), typeof r == `function`)) Ri(r) && (s = 1);
      else if (typeof r == `string`)
        s = qm(e, n, ke.current)
          ? 26
          : e === `html` || e === `head` || e === `body`
            ? 27
            : 5;
      else
        a: switch (r) {
          case me:
            return (
              (e = Li(31, n, t, a)),
              (e.elementType = me),
              (e.lanes = o),
              e
            );
          case ae:
            return Hi(n.children, a, o, t);
          case oe:
            ((s = 8), (a |= 24));
            break;
          case se:
            return (
              (e = Li(12, n, t, a | 2)),
              (e.elementType = se),
              (e.lanes = o),
              e
            );
          case ue:
            return (
              (e = Li(13, n, t, a)),
              (e.elementType = ue),
              (e.lanes = o),
              e
            );
          case de:
            return (
              (e = Li(19, n, t, a)),
              (e.elementType = de),
              (e.lanes = o),
              e
            );
          case he:
          case _e:
            return (
              (e = a | 32),
              (e = Li(30, n, t, e)),
              (e.elementType = _e),
              (e.lanes = o),
              (e.stateNode = {
                autoName: null,
                paired: null,
                clones: null,
                ref: null,
              }),
              e
            );
          default:
            if (typeof r == `object` && r)
              switch (r.$$typeof) {
                case E:
                  s = 10;
                  break a;
                case ce:
                  s = 9;
                  break a;
                case le:
                  s = 11;
                  break a;
                case fe:
                  s = 14;
                  break a;
                case pe:
                  ((s = 16), (r = null));
                  break a;
              }
            ((s = 29),
              (n = Error(i(130, e === null ? `null` : typeof e, ``))),
              (r = null));
        }
      return (
        (t = Li(s, n, t, a)),
        (t.elementType = e),
        (t.type = r),
        (t.lanes = o),
        t
      );
    }
    function Hi(e, t, n, r) {
      return ((e = Li(7, e, r, t)), (e.lanes = n), e);
    }
    function Ui(e, t, n) {
      return ((e = Li(6, e, null, t)), (e.lanes = n), e);
    }
    function Wi(e) {
      var t = Li(18, null, null, 0);
      return ((t.stateNode = e), t);
    }
    function Gi(e, t, n) {
      return (
        (t = Li(4, e.children === null ? [] : e.children, e.key, t)),
        (t.lanes = n),
        (t.stateNode = {
          containerInfo: e.containerInfo,
          pendingChildren: null,
          implementation: e.implementation,
        }),
        t
      );
    }
    var Ki = new WeakMap();
    function qi(e, t) {
      if (typeof e == `object` && e) {
        var n = Ki.get(e);
        return n === void 0
          ? ((t = {
              value: e,
              source: t,
              stack: Ue(t),
            }),
            Ki.set(e, t),
            t)
          : n;
      }
      return {
        value: e,
        source: t,
        stack: Ue(t),
      };
    }
    var Ji = [],
      Yi = 0,
      Xi = null,
      Zi = 0,
      Qi = [],
      $i = 0,
      ea = null,
      ta = 1,
      na = ``;
    function ra(e, t) {
      ((Ji[Yi++] = Zi), (Ji[Yi++] = Xi), (Xi = e), (Zi = t));
    }
    function ia(e, t, n) {
      ((Qi[$i++] = ta), (Qi[$i++] = na), (Qi[$i++] = ea), (ea = e));
      var r = ta;
      e = na;
      var i = 32 - st(r) - 1;
      ((r &= ~(1 << i)), (n += 1));
      var a = 32 - st(t) + i;
      if (30 < a) {
        var o = i - (i % 5);
        ((a = (r & ((1 << o) - 1)).toString(32)),
          (r >>= o),
          (i -= o),
          (ta = (1 << (32 - st(t) + i)) | (n << i) | r),
          (na = a + e));
      } else ((ta = (1 << a) | (n << i) | r), (na = e));
    }
    function aa(e) {
      e.return !== null && (ra(e, 1), ia(e, 1, 0));
    }
    function oa(e) {
      for (; e === Xi;)
        ((Xi = Ji[--Yi]), (Ji[Yi] = null), (Zi = Ji[--Yi]), (Ji[Yi] = null));
      for (; e === ea;)
        ((ea = Qi[--$i]),
          (Qi[$i] = null),
          (na = Qi[--$i]),
          (Qi[$i] = null),
          (ta = Qi[--$i]),
          (Qi[$i] = null));
    }
    function sa(e, t) {
      ((Qi[$i++] = ta),
        (Qi[$i++] = na),
        (Qi[$i++] = ea),
        (ta = t.id),
        (na = t.overflow),
        (ea = e));
    }
    var ca = null,
      F = null,
      I = !1,
      la = null,
      ua = !1,
      da = Error(i(519));
    function fa(e) {
      throw (
        va(
          qi(
            Error(
              i(
                418,
                1 < arguments.length && arguments[1] !== void 0 && arguments[1]
                  ? `text`
                  : `HTML`,
                ``,
              ),
            ),
            e,
          ),
        ),
        da
      );
    }
    function pa(e) {
      var t = e.stateNode,
        n = e.type,
        r = e.memoizedProps;
      switch (((t[jt] = e), (t[Mt] = r), n)) {
        case `dialog`:
          (Q(`cancel`, t), Q(`close`, t));
          break;
        case `iframe`:
        case `object`:
        case `embed`:
          Q(`load`, t);
          break;
        case `video`:
        case `audio`:
          for (n = 0; n < zf.length; n++) Q(zf[n], t);
          break;
        case `source`:
          Q(`error`, t);
          break;
        case `img`:
        case `image`:
        case `link`:
          (Q(`error`, t), Q(`load`, t));
          break;
        case `details`:
          Q(`toggle`, t);
          break;
        case `input`:
          (Q(`invalid`, t),
            mn(
              t,
              r.value,
              r.defaultValue,
              r.checked,
              r.defaultChecked,
              r.type,
              r.name,
              !0,
            ));
          break;
        case `select`:
          Q(`invalid`, t);
          break;
        case `textarea`:
          (Q(`invalid`, t), vn(t, r.value, r.defaultValue, r.children));
      }
      ((n = r.children),
        (typeof n != `string` &&
          typeof n != `number` &&
          typeof n != `bigint`) ||
        t.textContent === `` + n ||
        !0 === r.suppressHydrationWarning ||
        ep(t.textContent, n)
          ? (r.popover != null && (Q(`beforetoggle`, t), Q(`toggle`, t)),
            r.onScroll != null && Q(`scroll`, t),
            r.onScrollEnd != null && Q(`scrollend`, t),
            r.onClick != null && (t.onclick = Dn),
            (t = !0))
          : (t = !1),
        t || fa(e, !0));
    }
    function ma(e) {
      for (ca = e.return; ca;)
        switch (ca.tag) {
          case 5:
          case 31:
          case 13:
            ua = !1;
            return;
          case 27:
          case 3:
            ua = !0;
            return;
          default:
            ca = ca.return;
        }
    }
    function ha(e) {
      if (e !== ca) return !1;
      if (!I) return (ma(e), (I = !0), !1);
      var t = e.tag,
        n;
      if (
        ((n = t !== 3 && t !== 27) &&
          ((n = t === 5) &&
            ((n = e.type),
            (n =
              n === `form` || n === `button` || pp(e.type, e.memoizedProps))),
          (n = !n)),
        n && F && fa(e),
        ma(e),
        t === 13)
      ) {
        if (((e = e.memoizedState), (e = e === null ? null : e.dehydrated), !e))
          throw Error(i(317));
        F = dm(e);
      } else if (t === 31) {
        if (((e = e.memoizedState), (e = e === null ? null : e.dehydrated), !e))
          throw Error(i(317));
        F = dm(e);
      } else
        t === 27
          ? ((t = F), Sp(e.type) ? ((e = um), (um = null), (F = e)) : (F = t))
          : (F = ca ? lm(e.stateNode.nextSibling) : null);
      return !0;
    }
    function ga() {
      ((F = ca = null), (I = !1));
    }
    function _a() {
      var e = la;
      return (
        e !== null &&
          (pd === null ? (pd = e) : pd.push.apply(pd, e), (la = null)),
        e
      );
    }
    function va(e) {
      la === null ? (la = [e]) : la.push(e);
    }
    var ya = De(null),
      ba = null,
      xa = null;
    function Sa(e, t, n) {
      (k(ya, t._currentValue), (t._currentValue = n));
    }
    function Ca(e) {
      ((e._currentValue = ya.current), Oe(ya));
    }
    function wa(e, t, n) {
      for (; e !== null;) {
        var r = e.alternate;
        if (
          ((e.childLanes & t) === t
            ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t)
            : ((e.childLanes |= t), r !== null && (r.childLanes |= t)),
          e === n)
        )
          break;
        e = e.return;
      }
    }
    function Ta(e, t, n, r) {
      var a = e.child;
      for (a !== null && (a.return = e); a !== null;) {
        var o = a.dependencies;
        if (o !== null) {
          var s = a.child;
          o = o.firstContext;
          a: for (; o !== null;) {
            var c = o;
            o = a;
            for (var l = 0; l < t.length; l++)
              if (c.context === t[l]) {
                ((o.lanes |= n),
                  (c = o.alternate),
                  c !== null && (c.lanes |= n),
                  wa(o.return, n, e),
                  r || (s = null));
                break a;
              }
            o = c.next;
          }
        } else if (a.tag === 18) {
          if (((s = a.return), s === null)) throw Error(i(341));
          ((s.lanes |= n),
            (o = s.alternate),
            o !== null && (o.lanes |= n),
            wa(s, n, e),
            (s = null));
        } else
          a.tag === 13 &&
          a.memoizedState !== null &&
          a.memoizedState.dehydrated === null
            ? ((a.lanes |= n),
              (s = a.alternate),
              s !== null && (s.lanes |= n),
              wa(a.return, n, e),
              (s = a.child),
              (s = s === null ? null : s.sibling))
            : (s = a.child);
        if (s !== null) s.return = a;
        else
          for (s = a; s !== null;) {
            if (s === e) {
              s = null;
              break;
            }
            if (((a = s.sibling), a !== null)) {
              ((a.return = s.return), (s = a));
              break;
            }
            s = s.return;
          }
        a = s;
      }
    }
    function Ea(e, t, n, r) {
      e = null;
      for (var a = t, o = !1; a !== null;) {
        if (!o) {
          if (a.flags & 524288) o = !0;
          else if (a.flags & 262144) break;
        }
        if (a.tag === 10) {
          var s = a.alternate;
          if (s === null) throw Error(i(387));
          if (((s = s.memoizedProps), s !== null)) {
            var c = a.type;
            Kr(a.pendingProps.value, s.value) ||
              (e === null ? (e = [c]) : e.push(c));
          }
        } else if (a === Me.current) {
          if (((s = a.alternate), s === null)) throw Error(i(387));
          s.memoizedState.memoizedState !== a.memoizedState.memoizedState &&
            (e === null ? (e = [sh]) : e.push(sh));
        }
        a = a.return;
      }
      return (e !== null && Ta(t, e, n, r), (t.flags |= 262144), e !== null);
    }
    function Da(e) {
      for (e = e.firstContext; e !== null;) {
        if (!Kr(e.context._currentValue, e.memoizedValue)) return !0;
        e = e.next;
      }
      return !1;
    }
    function Oa(e) {
      ((ba = e),
        (xa = null),
        (e = e.dependencies),
        e !== null && (e.firstContext = null));
    }
    function ka(e) {
      return ja(ba, e);
    }
    function Aa(e, t) {
      return (ba === null && Oa(e), ja(e, t));
    }
    function ja(e, t) {
      var n = t._currentValue;
      if (
        ((t = {
          context: t,
          memoizedValue: n,
          next: null,
        }),
        xa === null)
      ) {
        if (e === null) throw Error(i(308));
        ((xa = t),
          (e.dependencies = {
            lanes: 0,
            firstContext: t,
          }),
          (e.flags |= 524288));
      } else xa = xa.next = t;
      return n;
    }
    var Ma =
        typeof AbortController < `u`
          ? AbortController
          : function () {
              var e = [],
                t = (this.signal = {
                  aborted: !1,
                  addEventListener: function (t, n) {
                    e.push(n);
                  },
                });
              this.abort = function () {
                ((t.aborted = !0),
                  e.forEach(function (e) {
                    return e();
                  }));
              };
            },
      Na = t.unstable_scheduleCallback,
      Pa = t.unstable_NormalPriority,
      Fa = {
        $$typeof: E,
        Consumer: null,
        Provider: null,
        _currentValue: null,
        _currentValue2: null,
        _threadCount: 0,
      };
    function Ia() {
      return {
        controller: new Ma(),
        data: new Map(),
        refCount: 0,
      };
    }
    function La(e) {
      (e.refCount--,
        e.refCount === 0 &&
          Na(Pa, function () {
            e.controller.abort();
          }));
    }
    function Ra(e, t) {
      if (e.pendingLanes & 4194048) {
        var n = e.transitionTypes;
        for (
          n === null && (n = e.transitionTypes = []), e = 0;
          e < t.length;
          e++
        ) {
          var r = t[e];
          n.indexOf(r) === -1 && n.push(r);
        }
      }
    }
    var za = null;
    function Ba(e) {
      var t = e.transitionTypes;
      return ((e.transitionTypes = null), t);
    }
    var Va = null,
      Ha = 0,
      Ua = 0,
      Wa = null;
    function Ga(e, t) {
      if (Va === null) {
        var n = (Va = []);
        ((Ha = 0),
          (Ua = Pf()),
          (Wa = {
            status: `pending`,
            value: void 0,
            then: function (e) {
              n.push(e);
            },
          }));
      }
      return (Ha++, t.then(Ka, Ka), t);
    }
    function Ka() {
      if (--Ha === 0 && ((za = null), Va !== null)) {
        Wa !== null && (Wa.status = `fulfilled`);
        var e = Va;
        ((Va = null), (Ua = 0), (Wa = null));
        for (var t = 0; t < e.length; t++) (0, e[t])();
      }
    }
    function qa(e, t) {
      var n = [],
        r = {
          status: `pending`,
          value: null,
          reason: null,
          then: function (e) {
            n.push(e);
          },
        };
      return (
        e.then(
          function () {
            ((r.status = `fulfilled`), (r.value = t));
            for (var e = 0; e < n.length; e++) (0, n[e])(t);
          },
          function (e) {
            for (r.status = `rejected`, r.reason = e, e = 0; e < n.length; e++)
              (0, n[e])(void 0);
          },
        ),
        r
      );
    }
    var Ja = D.S;
    D.S = function (e, t) {
      if (
        ((gd = Ye()),
        typeof t == `object` && t && typeof t.then == `function` && Ga(e, t),
        za !== null)
      )
        for (var n = bf; n !== null;) (Ra(n, za), (n = n.next));
      if (((n = e.types), n !== null)) {
        for (var r = bf; r !== null;) (Ra(r, n), (r = r.next));
        if (Ua !== 0) {
          ((r = za), r === null && (r = za = []));
          for (var i = 0; i < n.length; i++) {
            var a = n[i];
            r.indexOf(a) === -1 && r.push(a);
          }
        }
      }
      Ja !== null && Ja(e, t);
    };
    var Ya = De(null);
    function Xa() {
      var e = Ya.current;
      return e === null ? G.pooledCache : e;
    }
    function Za(e, t) {
      t === null ? k(Ya, Ya.current) : k(Ya, t.pool);
    }
    function Qa() {
      var e = Xa();
      return e === null
        ? null
        : {
            parent: Fa._currentValue,
            pool: e,
          };
    }
    var $a = Error(i(460)),
      eo = Error(i(474)),
      to = Error(i(542)),
      no = {
        then: function () {},
      };
    function ro(e) {
      return ((e = e.status), e === `fulfilled` || e === `rejected`);
    }
    function io(e, t, n) {
      switch (
        ((n = e[n]),
        n === void 0 ? e.push(t) : n !== t && (t.then(Dn, Dn), (t = n)),
        t.status)
      ) {
        case `fulfilled`:
          return t.value;
        case `rejected`:
          throw (
            (e = t.reason),
            co(e),
            e === void 0 && !(`reason` in t) ? Error(i(600)) : e
          );
        default:
          if (typeof t.status == `string`) t.then(Dn, Dn);
          else {
            if (((e = G), e !== null && 100 < e.shellSuspendCounter))
              throw Error(i(482));
            ((e = t),
              (e.status = `pending`),
              e.then(
                function (e) {
                  if (t.status === `pending`) {
                    var n = t;
                    ((n.status = `fulfilled`), (n.value = e));
                  }
                },
                function (e) {
                  if (t.status === `pending`) {
                    var n = t;
                    ((n.status = `rejected`), (n.reason = e));
                  }
                },
              ));
          }
          switch (t.status) {
            case `fulfilled`:
              return t.value;
            case `rejected`:
              throw ((e = t.reason), co(e), e);
          }
          throw ((oo = t), $a);
      }
    }
    function ao(e) {
      try {
        var t = e._init;
        return t(e._payload);
      } catch (e) {
        throw typeof e == `object` && e && typeof e.then == `function`
          ? ((oo = e), $a)
          : e;
      }
    }
    var oo = null;
    function so() {
      if (oo === null) throw Error(i(459));
      var e = oo;
      return ((oo = null), e);
    }
    function co(e) {
      if (e === $a || e === to) throw Error(i(483));
    }
    var lo = null,
      uo = 0;
    function fo(e) {
      var t = uo;
      return ((uo += 1), lo === null && (lo = []), io(lo, e, t));
    }
    function po(e, t) {
      ((t = t.props.ref), (e.ref = t === void 0 ? null : t));
    }
    function mo(e, t) {
      throw t.$$typeof === ie
        ? Error(i(525))
        : ((e = Object.prototype.toString.call(t)),
          Error(
            i(
              31,
              e === `[object Object]`
                ? `object with keys {` + Object.keys(t).join(`, `) + `}`
                : e,
            ),
          ));
    }
    function ho(e) {
      function t(t, n) {
        if (e) {
          var r = t.deletions;
          r === null ? ((t.deletions = [n]), (t.flags |= 16)) : r.push(n);
        }
      }
      function n(n, r) {
        if (!e) return null;
        for (; r !== null;) (t(n, r), (r = r.sibling));
        return null;
      }
      function r(e) {
        for (var t = new Map(); e !== null;)
          (e.key === null ? t.set(e.index, e) : t.set(e.key, e),
            (e = e.sibling));
        return t;
      }
      function a(e, t) {
        return ((e = zi(e, t)), (e.index = 0), (e.sibling = null), e);
      }
      function o(t, n, r) {
        return (
          (t.index = r),
          e
            ? ((r = t.alternate),
              r === null
                ? ((t.flags |= 134217730), n)
                : ((r = r.index), r < n ? ((t.flags |= 2), n) : r))
            : ((t.flags |= 1048576), n)
        );
      }
      function s(t) {
        return (e && t.alternate === null && (t.flags |= 134217730), t);
      }
      function c(e, t, n, r) {
        return t === null || t.tag !== 6
          ? ((t = Ui(n, e.mode, r)), (t.return = e), t)
          : ((t = a(t, n)), (t.return = e), t);
      }
      function l(e, t, n, r) {
        var i = n.type;
        return i === ae
          ? ((e = d(e, t, n.props.children, r, n.key)), po(e, n), e)
          : t !== null &&
              (t.elementType === i ||
                (typeof i == `object` &&
                  i &&
                  i.$$typeof === pe &&
                  ao(i) === t.type))
            ? ((t = a(t, n.props)), po(t, n), (t.return = e), t)
            : ((t = Vi(n.type, n.key, n.props, null, e.mode, r)),
              po(t, n),
              (t.return = e),
              t);
      }
      function u(e, t, n, r) {
        return t === null ||
          t.tag !== 4 ||
          t.stateNode.containerInfo !== n.containerInfo ||
          t.stateNode.implementation !== n.implementation
          ? ((t = Gi(n, e.mode, r)), (t.return = e), t)
          : ((t = a(t, n.children || [])), (t.return = e), t);
      }
      function d(e, t, n, r, i) {
        return t === null || t.tag !== 7
          ? ((t = Hi(n, e.mode, r, i)), (t.return = e), t)
          : ((t = a(t, n)), (t.return = e), t);
      }
      function f(e, t, n) {
        if (
          (typeof t == `string` && t !== ``) ||
          typeof t == `number` ||
          typeof t == `bigint`
        )
          return ((t = Ui(`` + t, e.mode, n)), (t.return = e), t);
        if (typeof t == `object` && t) {
          switch (t.$$typeof) {
            case w:
              return (
                (n = Vi(t.type, t.key, t.props, null, e.mode, n)),
                po(n, t),
                (n.return = e),
                n
              );
            case T:
              return ((t = Gi(t, e.mode, n)), (t.return = e), t);
            case pe:
              return ((t = ao(t)), f(e, t, n));
          }
          if (Ce(t) || be(t))
            return ((t = Hi(t, e.mode, n, null)), (t.return = e), t);
          if (typeof t.then == `function`) return f(e, fo(t), n);
          if (t.$$typeof === E) return f(e, Aa(e, t), n);
          mo(e, t);
        }
        return null;
      }
      function p(e, t, n, r) {
        var i = t === null ? null : t.key;
        if (
          (typeof n == `string` && n !== ``) ||
          typeof n == `number` ||
          typeof n == `bigint`
        )
          return i === null ? c(e, t, `` + n, r) : null;
        if (typeof n == `object` && n) {
          switch (n.$$typeof) {
            case w:
              return n.key === i ? l(e, t, n, r) : null;
            case T:
              return n.key === i ? u(e, t, n, r) : null;
            case pe:
              return ((n = ao(n)), p(e, t, n, r));
          }
          if (Ce(n) || be(n)) return i === null ? d(e, t, n, r, null) : null;
          if (typeof n.then == `function`) return p(e, t, fo(n), r);
          if (n.$$typeof === E) return p(e, t, Aa(e, n), r);
          mo(e, n);
        }
        return null;
      }
      function m(e, t, n, r, i) {
        if (
          (typeof r == `string` && r !== ``) ||
          typeof r == `number` ||
          typeof r == `bigint`
        )
          return ((e = e.get(n) || null), c(t, e, `` + r, i));
        if (typeof r == `object` && r) {
          switch (r.$$typeof) {
            case w:
              return (
                (e = e.get(r.key === null ? n : r.key) || null),
                l(t, e, r, i)
              );
            case T:
              return (
                (e = e.get(r.key === null ? n : r.key) || null),
                u(t, e, r, i)
              );
            case pe:
              return ((r = ao(r)), m(e, t, n, r, i));
          }
          if (Ce(r) || be(r))
            return ((e = e.get(n) || null), d(t, e, r, i, null));
          if (typeof r.then == `function`) return m(e, t, n, fo(r), i);
          if (r.$$typeof === E) return m(e, t, n, Aa(t, r), i);
          mo(t, r);
        }
        return null;
      }
      function h(i, a, s, c) {
        for (
          var l = null, u = null, d = a, h = (a = 0), g = null;
          d !== null && h < s.length;
          h++
        ) {
          d.index > h ? ((g = d), (d = null)) : (g = d.sibling);
          var _ = p(i, d, s[h], c);
          if (_ === null) {
            d === null && (d = g);
            break;
          }
          (e && d && _.alternate === null && t(i, d),
            (a = o(_, a, h)),
            u === null ? (l = _) : (u.sibling = _),
            (u = _),
            (d = g));
        }
        if (h === s.length) return (n(i, d), I && ra(i, h), l);
        if (d === null) {
          for (; h < s.length; h++)
            ((d = f(i, s[h], c)),
              d !== null &&
                ((a = o(d, a, h)),
                u === null ? (l = d) : (u.sibling = d),
                (u = d)));
          return (I && ra(i, h), l);
        }
        for (d = r(d); h < s.length; h++)
          ((g = m(d, i, h, s[h], c)),
            g !== null &&
              (e &&
                ((_ = g.alternate),
                _ !== null && d.delete(_.key === null ? h : _.key)),
              (a = o(g, a, h)),
              u === null ? (l = g) : (u.sibling = g),
              (u = g)));
        return (
          e &&
            d.forEach(function (e) {
              return t(i, e);
            }),
          I && ra(i, h),
          l
        );
      }
      function g(a, s, c, l) {
        if (c == null) throw Error(i(151));
        for (
          var u = null, d = null, h = s, g = (s = 0), _ = null, v = c.next();
          h !== null && !v.done;
          g++, v = c.next()
        ) {
          h.index > g ? ((_ = h), (h = null)) : (_ = h.sibling);
          var y = p(a, h, v.value, l);
          if (y === null) {
            h === null && (h = _);
            break;
          }
          (e && h && y.alternate === null && t(a, h),
            (s = o(y, s, g)),
            d === null ? (u = y) : (d.sibling = y),
            (d = y),
            (h = _));
        }
        if (v.done) return (n(a, h), I && ra(a, g), u);
        if (h === null) {
          for (; !v.done; g++, v = c.next())
            ((v = f(a, v.value, l)),
              v !== null &&
                ((s = o(v, s, g)),
                d === null ? (u = v) : (d.sibling = v),
                (d = v)));
          return (I && ra(a, g), u);
        }
        for (h = r(h); !v.done; g++, v = c.next())
          ((v = m(h, a, g, v.value, l)),
            v !== null &&
              (e &&
                ((_ = v.alternate),
                _ !== null && h.delete(_.key === null ? g : _.key)),
              (s = o(v, s, g)),
              d === null ? (u = v) : (d.sibling = v),
              (d = v)));
        return (
          e &&
            h.forEach(function (e) {
              return t(a, e);
            }),
          I && ra(a, g),
          u
        );
      }
      function _(e, r, o, c) {
        if (
          (typeof o == `object` &&
            o &&
            o.type === ae &&
            o.key === null &&
            o.props.ref === void 0 &&
            (o = o.props.children),
          typeof o == `object` && o)
        ) {
          switch (o.$$typeof) {
            case w:
              a: {
                for (var l = o.key; r !== null;) {
                  if (r.key === l) {
                    if (((l = o.type), l === ae)) {
                      if (r.tag === 7) {
                        (n(e, r.sibling),
                          (c = a(r, o.props.children)),
                          po(c, o),
                          (c.return = e),
                          (e = c));
                        break a;
                      }
                    } else if (
                      r.elementType === l ||
                      (typeof l == `object` &&
                        l &&
                        l.$$typeof === pe &&
                        ao(l) === r.type)
                    ) {
                      (n(e, r.sibling),
                        (c = a(r, o.props)),
                        po(c, o),
                        (c.return = e),
                        (e = c));
                      break a;
                    }
                    n(e, r);
                    break;
                  }
                  (t(e, r), (r = r.sibling));
                }
                o.type === ae
                  ? ((c = Hi(o.props.children, e.mode, c, o.key)),
                    po(c, o),
                    (c.return = e),
                    (e = c))
                  : ((c = Vi(o.type, o.key, o.props, null, e.mode, c)),
                    po(c, o),
                    (c.return = e),
                    (e = c));
              }
              return s(e);
            case T:
              a: {
                for (l = o.key; r !== null;) {
                  if (r.key === l) {
                    if (
                      r.tag === 4 &&
                      r.stateNode.containerInfo === o.containerInfo &&
                      r.stateNode.implementation === o.implementation
                    ) {
                      (n(e, r.sibling),
                        (c = a(r, o.children || [])),
                        (c.return = e),
                        (e = c));
                      break a;
                    }
                    n(e, r);
                    break;
                  }
                  (t(e, r), (r = r.sibling));
                }
                ((c = Gi(o, e.mode, c)), (c.return = e), (e = c));
              }
              return s(e);
            case pe:
              return ((o = ao(o)), _(e, r, o, c));
          }
          if (Ce(o)) return h(e, r, o, c);
          if (be(o)) {
            if (((l = be(o)), typeof l != `function`)) throw Error(i(150));
            return ((o = l.call(o)), g(e, r, o, c));
          }
          if (typeof o.then == `function`) return _(e, r, fo(o), c);
          if (o.$$typeof === E) return _(e, r, Aa(e, o), c);
          mo(e, o);
        }
        return (typeof o == `string` && o !== ``) ||
          typeof o == `number` ||
          typeof o == `bigint`
          ? ((o = `` + o),
            r !== null && r.tag === 6
              ? (n(e, r.sibling), (c = a(r, o)), (c.return = e), (e = c))
              : (n(e, r), (c = Ui(o, e.mode, c)), (c.return = e), (e = c)),
            s(e))
          : n(e, r);
      }
      return function (e, t, n, r) {
        try {
          uo = 0;
          var i = _(e, t, n, r);
          return ((lo = null), i);
        } catch (t) {
          if (t === $a || t === to) throw t;
          var a = Li(29, t, null, e.mode);
          return ((a.lanes = r), (a.return = e), a);
        }
      };
    }
    var go = ho(!0),
      _o = ho(!1),
      vo = !1;
    function yo(e) {
      e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          lanes: 0,
          hiddenCallbacks: null,
        },
        callbacks: null,
      };
    }
    function bo(e, t) {
      ((e = e.updateQueue),
        t.updateQueue === e &&
          (t.updateQueue = {
            baseState: e.baseState,
            firstBaseUpdate: e.firstBaseUpdate,
            lastBaseUpdate: e.lastBaseUpdate,
            shared: e.shared,
            callbacks: null,
          }));
    }
    function xo(e) {
      return {
        lane: e,
        tag: 0,
        payload: null,
        callback: null,
        next: null,
      };
    }
    function So(e, t, n) {
      var r = e.updateQueue;
      if (r === null) return null;
      if (((r = r.shared), W & 2)) {
        var i = r.pending;
        return (
          i === null ? (t.next = t) : ((t.next = i.next), (i.next = t)),
          (r.pending = t),
          (t = Pi(e)),
          Ni(e, null, n),
          t
        );
      }
      return (Ai(e, r, t, n), Pi(e));
    }
    function Co(e, t, n) {
      if (((t = t.updateQueue), t !== null && ((t = t.shared), n & 4194048))) {
        var r = t.lanes;
        ((r &= e.pendingLanes), (n |= r), (t.lanes = n), wt(e, n));
      }
    }
    function wo(e, t) {
      var n = e.updateQueue,
        r = e.alternate;
      if (r !== null && ((r = r.updateQueue), n === r)) {
        var i = null,
          a = null;
        if (((n = n.firstBaseUpdate), n !== null)) {
          do {
            var o = {
              lane: n.lane,
              tag: n.tag,
              payload: n.payload,
              callback: null,
              next: null,
            };
            (a === null ? (i = a = o) : (a = a.next = o), (n = n.next));
          } while (n !== null);
          a === null ? (i = a = t) : (a = a.next = t);
        } else i = a = t;
        ((n = {
          baseState: r.baseState,
          firstBaseUpdate: i,
          lastBaseUpdate: a,
          shared: r.shared,
          callbacks: r.callbacks,
        }),
          (e.updateQueue = n));
        return;
      }
      ((e = n.lastBaseUpdate),
        e === null ? (n.firstBaseUpdate = t) : (e.next = t),
        (n.lastBaseUpdate = t));
    }
    var To = !1;
    function Eo() {
      if (To) {
        var e = Wa;
        if (e !== null) throw e;
      }
    }
    function Do(e, t, n, r) {
      To = !1;
      var i = e.updateQueue;
      vo = !1;
      var a = i.firstBaseUpdate,
        o = i.lastBaseUpdate,
        s = i.shared.pending;
      if (s !== null) {
        i.shared.pending = null;
        var c = s,
          l = c.next;
        ((c.next = null), o === null ? (a = l) : (o.next = l), (o = c));
        var u = e.alternate;
        u !== null &&
          ((u = u.updateQueue),
          (s = u.lastBaseUpdate),
          s !== o &&
            (s === null ? (u.firstBaseUpdate = l) : (s.next = l),
            (u.lastBaseUpdate = c)));
      }
      if (a !== null) {
        var d = i.baseState;
        ((o = 0), (u = l = c = null), (s = a));
        do {
          var f = s.lane & -536870913,
            p = f !== s.lane;
          if (p ? (q & f) === f : (r & f) === f) {
            (f !== 0 && f === Ua && (To = !0),
              u !== null &&
                (u = u.next =
                  {
                    lane: 0,
                    tag: s.tag,
                    payload: s.payload,
                    callback: null,
                    next: null,
                  }));
            a: {
              var m = e,
                h = s;
              f = t;
              var g = n;
              switch (h.tag) {
                case 1:
                  if (((m = h.payload), typeof m == `function`)) {
                    d = m.call(g, d, f);
                    break a;
                  }
                  d = m;
                  break a;
                case 3:
                  m.flags = (m.flags & -65537) | 128;
                case 0:
                  if (
                    ((m = h.payload),
                    (f = typeof m == `function` ? m.call(g, d, f) : m),
                    f == null)
                  )
                    break a;
                  d = C({}, d, f);
                  break a;
                case 2:
                  vo = !0;
              }
            }
            ((f = s.callback),
              f !== null &&
                ((e.flags |= 64),
                p && (e.flags |= 8192),
                (p = i.callbacks),
                p === null ? (i.callbacks = [f]) : p.push(f)));
          } else
            ((p = {
              lane: f,
              tag: s.tag,
              payload: s.payload,
              callback: s.callback,
              next: null,
            }),
              u === null ? ((l = u = p), (c = d)) : (u = u.next = p),
              (o |= f));
          if (((s = s.next), s === null)) {
            if (((s = i.shared.pending), s === null)) break;
            ((p = s),
              (s = p.next),
              (p.next = null),
              (i.lastBaseUpdate = p),
              (i.shared.pending = null));
          }
        } while (1);
        (u === null && (c = d),
          (i.baseState = c),
          (i.firstBaseUpdate = l),
          (i.lastBaseUpdate = u),
          a === null && (i.shared.lanes = 0),
          (sd |= o),
          (e.lanes = o),
          (e.memoizedState = d));
      }
    }
    function Oo(e, t) {
      if (typeof e != `function`) throw Error(i(191, e));
      e.call(t);
    }
    function ko(e, t) {
      var n = e.callbacks;
      if (n !== null)
        for (e.callbacks = null, e = 0; e < n.length; e++) Oo(n[e], t);
    }
    var Ao = De(null),
      jo = De(0);
    function Mo(e, t) {
      ((e = od), k(jo, e), k(Ao, t), (od = e | t.baseLanes));
    }
    function No() {
      (k(jo, od), k(Ao, Ao.current));
    }
    function Po() {
      ((od = jo.current), Oe(Ao), Oe(jo));
    }
    var Fo = De(null),
      Io = null;
    function Lo(e) {
      var t = e.alternate;
      (k(Ho, Ho.current & 1),
        k(Fo, e),
        Io === null &&
          (t === null || Ao.current !== null || t.memoizedState !== null) &&
          (Io = e));
    }
    function Ro(e) {
      (k(Ho, Ho.current), k(Fo, e), Io === null && (Io = e));
    }
    function zo(e) {
      e.tag === 22
        ? (k(Ho, Ho.current), k(Fo, e), Io === null && (Io = e))
        : Bo();
    }
    function Bo() {
      (k(Ho, Ho.current), k(Fo, Fo.current));
    }
    function Vo(e) {
      (Oe(Fo), Io === e && (Io = null), Oe(Ho));
    }
    var Ho = De(0);
    function Uo(e, t) {
      (k(Fo, Fo.current), k(Ho, t));
    }
    function Wo(e) {
      (Oe(Ho), Oe(Fo), Io === e && (Io = null));
    }
    function Go(e) {
      for (var t = e; t !== null;) {
        if (t.tag === 13) {
          var n = t.memoizedState;
          if (n !== null && ((n = n.dehydrated), n === null || om(n) || sm(n)))
            return t;
        } else if (
          t.tag === 19 &&
          t.memoizedProps.revealOrder !== `independent`
        ) {
          if (t.flags & 128) return t;
        } else if (t.child !== null) {
          ((t.child.return = t), (t = t.child));
          continue;
        }
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return null;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
      return null;
    }
    var Ko = 0,
      L = null,
      R = null,
      qo = null,
      Jo = !1,
      Yo = !1,
      Xo = !1,
      Zo = 0,
      Qo = 0,
      $o = null,
      es = 0;
    function z() {
      throw Error(i(321));
    }
    function ts(e, t) {
      if (t === null) return !1;
      for (var n = 0; n < t.length && n < e.length; n++)
        if (!Kr(e[n], t[n])) return !1;
      return !0;
    }
    function ns(e, t, n, r, i, a) {
      return (
        (Ko = a),
        (L = t),
        (t.memoizedState = null),
        (t.updateQueue = null),
        (t.lanes = 0),
        (D.H = e === null || e.memoizedState === null ? vc : yc),
        (Xo = !1),
        (a = n(r, i)),
        (Xo = !1),
        Yo && (a = is(t, n, r, i)),
        rs(e),
        a
      );
    }
    function rs(e) {
      D.H = _c;
      var t = R !== null && R.next !== null;
      if (((Ko = 0), (qo = R = L = null), (Jo = !1), (Qo = 0), ($o = null), t))
        throw Error(i(300));
      e === null ||
        Ic ||
        ((e = e.dependencies), e !== null && Da(e) && (Ic = !0));
    }
    function is(e, t, n, r) {
      L = e;
      var a = 0;
      do {
        if ((Yo && ($o = null), (Qo = 0), (Yo = !1), 25 <= a))
          throw Error(i(301));
        if (((a += 1), (qo = R = null), e.updateQueue != null)) {
          var o = e.updateQueue;
          ((o.lastEffect = null),
            (o.events = null),
            (o.stores = null),
            o.memoCache != null && (o.memoCache.index = 0));
        }
        ((D.H = bc), (o = t(n, r)));
      } while (Yo);
      return o;
    }
    function as() {
      var e = D.H,
        t = e.useState()[0];
      return (
        (t = typeof t.then == `function` ? ds(t) : t),
        (e = e.useState()[0]),
        (R === null ? null : R.memoizedState) !== e && (L.flags |= 1024),
        t
      );
    }
    function os() {
      var e = Zo !== 0;
      return ((Zo = 0), e);
    }
    function ss(e, t, n) {
      ((t.updateQueue = e.updateQueue), (t.flags &= -2053), (e.lanes &= ~n));
    }
    function cs(e) {
      if (Jo) {
        for (e = e.memoizedState; e !== null;) {
          var t = e.queue;
          (t !== null && (t.pending = null), (e = e.next));
        }
        Jo = !1;
      }
      ((Ko = 0), (qo = R = L = null), (Yo = !1), (Qo = Zo = 0), ($o = null));
    }
    function ls() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null,
      };
      return (
        qo === null ? (L.memoizedState = qo = e) : (qo = qo.next = e),
        qo
      );
    }
    function B() {
      if (R === null) {
        var e = L.alternate;
        e = e === null ? null : e.memoizedState;
      } else e = R.next;
      var t = qo === null ? L.memoizedState : qo.next;
      if (t !== null) ((qo = t), (R = e));
      else {
        if (e === null)
          throw L.alternate === null ? Error(i(467)) : Error(i(310));
        ((R = e),
          (e = {
            memoizedState: R.memoizedState,
            baseState: R.baseState,
            baseQueue: R.baseQueue,
            queue: R.queue,
            next: null,
          }),
          qo === null ? (L.memoizedState = qo = e) : (qo = qo.next = e));
      }
      return qo;
    }
    function us() {
      return {
        lastEffect: null,
        events: null,
        stores: null,
        memoCache: null,
      };
    }
    function ds(e) {
      var t = Qo;
      return (
        (Qo += 1),
        $o === null && ($o = []),
        (e = io($o, e, t)),
        (t = L),
        (qo === null ? t.memoizedState : qo.next) === null &&
          ((t = t.alternate),
          (D.H = t === null || t.memoizedState === null ? vc : yc)),
        e
      );
    }
    function fs(e) {
      if (typeof e == `object` && e) {
        if (typeof e.then == `function`) return ds(e);
        if (e.$$typeof === ve) return;
        if (e.$$typeof === E) return ka(e);
      }
      throw Error(i(438, String(e)));
    }
    function ps(e) {
      var t = null,
        n = L.updateQueue;
      if ((n !== null && (t = n.memoCache), t == null)) {
        var r = L.alternate;
        r !== null &&
          ((r = r.updateQueue),
          r !== null &&
            ((r = r.memoCache),
            r != null &&
              (t = {
                data: r.data.map(function (e) {
                  return e.slice();
                }),
                index: 0,
              })));
      }
      if (
        ((t ??= {
          data: [],
          index: 0,
        }),
        n === null && ((n = us()), (L.updateQueue = n)),
        (n.memoCache = t),
        (n = t.data[t.index]),
        n === void 0)
      )
        for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = ge;
      return (t.index++, n);
    }
    function ms(e, t) {
      return typeof t == `function` ? t(e) : t;
    }
    function hs(e) {
      return gs(B(), R, e);
    }
    function gs(e, t, n) {
      var r = e.queue;
      if (r === null) throw Error(i(311));
      r.lastRenderedReducer = n;
      var a = e.baseQueue,
        o = r.pending;
      if (o !== null) {
        if (a !== null) {
          var s = a.next;
          ((a.next = o.next), (o.next = s));
        }
        ((t.baseQueue = a = o), (r.pending = null));
      }
      if (((o = e.baseState), a === null)) e.memoizedState = o;
      else {
        t = a.next;
        var c = (s = null),
          l = null,
          u = t,
          d = !1;
        do {
          var f = u.lane & -536870913;
          if (f === u.lane ? (Ko & f) === f : (q & f) === f) {
            var p = u.revertLane;
            if (p === 0)
              (l !== null &&
                (l = l.next =
                  {
                    lane: 0,
                    revertLane: 0,
                    gesture: null,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null,
                  }),
                f === Ua && (d = !0));
            else if ((Ko & p) === p) {
              ((u = u.next), p === Ua && (d = !0));
              continue;
            } else
              ((f = {
                lane: 0,
                revertLane: u.revertLane,
                gesture: null,
                action: u.action,
                hasEagerState: u.hasEagerState,
                eagerState: u.eagerState,
                next: null,
              }),
                l === null ? ((c = l = f), (s = o)) : (l = l.next = f),
                (L.lanes |= p),
                (sd |= p));
            ((f = u.action),
              Xo && n(o, f),
              (o = u.hasEagerState ? u.eagerState : n(o, f)));
          } else
            ((p = {
              lane: f,
              revertLane: u.revertLane,
              gesture: u.gesture,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null,
            }),
              l === null ? ((c = l = p), (s = o)) : (l = l.next = p),
              (L.lanes |= f),
              (sd |= f));
          u = u.next;
        } while (u !== null && u !== t);
        if (
          (l === null ? (s = o) : (l.next = c),
          !Kr(o, e.memoizedState) && ((Ic = !0), d && ((n = Wa), n !== null)))
        )
          throw n;
        ((e.memoizedState = o),
          (e.baseState = s),
          (e.baseQueue = l),
          (r.lastRenderedState = o));
      }
      return (a === null && (r.lanes = 0), [e.memoizedState, r.dispatch]);
    }
    function _s(e) {
      var t = B(),
        n = t.queue;
      if (n === null) throw Error(i(311));
      n.lastRenderedReducer = e;
      var r = n.dispatch,
        a = n.pending,
        o = t.memoizedState;
      if (a !== null) {
        n.pending = null;
        var s = (a = a.next);
        do ((o = e(o, s.action)), (s = s.next));
        while (s !== a);
        (Kr(o, t.memoizedState) || (Ic = !0),
          (t.memoizedState = o),
          t.baseQueue === null && (t.baseState = o),
          (n.lastRenderedState = o));
      }
      return [o, r];
    }
    function vs(e, t, n) {
      var r = L,
        a = B(),
        o = I;
      if (o) {
        if (n === void 0) throw Error(i(407));
        n = n();
      } else n = t();
      var s = !Kr((R || a).memoizedState, n);
      if (
        (s && ((a.memoizedState = n), (Ic = !0)),
        (a = a.queue),
        Us(xs.bind(null, r, a, e), [e]),
        (e =
          a.getSnapshot !== t ||
          s ||
          (qo !== null && !!(qo.memoizedState.tag & 1))),
        Rs(
          e ? 9 : 8,
          {
            destroy: void 0,
          },
          bs.bind(null, r, a, n, t),
          null,
        ),
        e)
      ) {
        if (((r.flags |= 2048), G === null)) throw Error(i(349));
        o || Ko & 127 || ys(r, t, n);
      }
      return n;
    }
    function ys(e, t, n) {
      ((e.flags |= 16384),
        (e = {
          getSnapshot: t,
          value: n,
        }),
        (t = L.updateQueue),
        t === null
          ? ((t = us()), (L.updateQueue = t), (t.stores = [e]))
          : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
    }
    function bs(e, t, n, r) {
      ((t.value = n), (t.getSnapshot = r), Ss(t) && Cs(e));
    }
    function xs(e, t, n) {
      return n(function () {
        Ss(t) && Cs(e);
      });
    }
    function Ss(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var n = t();
        return !Kr(e, n);
      } catch {
        return !0;
      }
    }
    function Cs(e) {
      var t = Mi(e, 2);
      t !== null && Pd(t, e, 2);
    }
    function ws(e) {
      var t = ls();
      if (typeof e == `function`) {
        var n = e;
        if (((e = n()), Xo)) {
          ot(!0);
          try {
            n();
          } finally {
            ot(!1);
          }
        }
      }
      return (
        (t.memoizedState = t.baseState = e),
        (t.queue = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: ms,
          lastRenderedState: e,
        }),
        t
      );
    }
    function Ts(e, t, n, r) {
      return ((e.baseState = n), gs(e, R, typeof r == `function` ? r : ms));
    }
    function Es(e, t, n, r, a) {
      if (mc(e)) throw Error(i(485));
      if (((e = t.action), e !== null)) {
        var o = {
          payload: a,
          action: e,
          next: null,
          isTransition: !0,
          status: `pending`,
          value: null,
          reason: null,
          listeners: [],
          then: function (e) {
            o.listeners.push(e);
          },
        };
        (D.T === null ? (o.isTransition = !1) : n(!0),
          r(o),
          (n = t.pending),
          n === null
            ? ((o.next = t.pending = o), Ds(t, o))
            : ((o.next = n.next), (t.pending = n.next = o)));
      }
    }
    function Ds(e, t) {
      var n = t.action,
        r = t.payload,
        i = e.state;
      if (t.isTransition) {
        var a = D.T,
          o = {};
        ((o.types = a === null ? null : a.types), (D.T = o));
        try {
          var s = n(i, r),
            c = D.S;
          (c !== null && c(o, s), Os(e, t, s));
        } catch (n) {
          As(e, t, n);
        } finally {
          (a !== null && o.types !== null && (a.types = o.types), (D.T = a));
        }
      } else
        try {
          ((a = n(i, r)), Os(e, t, a));
        } catch (n) {
          As(e, t, n);
        }
    }
    function Os(e, t, n) {
      typeof n == `object` && n && typeof n.then == `function`
        ? n.then(
            function (n) {
              ks(e, t, n);
            },
            function (n) {
              return As(e, t, n);
            },
          )
        : ks(e, t, n);
    }
    function ks(e, t, n) {
      ((t.status = `fulfilled`),
        (t.value = n),
        js(t),
        (e.state = n),
        (t = e.pending),
        t !== null &&
          ((n = t.next),
          n === t
            ? (e.pending = null)
            : ((n = n.next), (t.next = n), Ds(e, n))));
    }
    function As(e, t, n) {
      var r = e.pending;
      if (((e.pending = null), r !== null)) {
        r = r.next;
        do ((t.status = `rejected`), (t.reason = n), js(t), (t = t.next));
        while (t !== r);
      }
      e.action = null;
    }
    function js(e) {
      e = e.listeners;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
    function Ms(e, t) {
      return t;
    }
    function Ns(e, t) {
      if (I) {
        var n = G.formState;
        if (n !== null) {
          a: {
            var r = L;
            if (I) {
              if (F) {
                b: {
                  for (var i = F, a = ua; i.nodeType !== 8;) {
                    if (!a) {
                      i = null;
                      break b;
                    }
                    if (((i = lm(i.nextSibling)), i === null)) {
                      i = null;
                      break b;
                    }
                  }
                  ((a = i.data), (i = a === `F!` || a === `F` ? i : null));
                }
                if (i) {
                  ((F = lm(i.nextSibling)), (r = i.data === `F!`));
                  break a;
                }
              }
              fa(r);
            }
            r = !1;
          }
          r && (t = n[0]);
        }
      }
      return (
        (n = ls()),
        (n.memoizedState = n.baseState = t),
        (r = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Ms,
          lastRenderedState: t,
        }),
        (n.queue = r),
        (n = dc.bind(null, L, r)),
        (r.dispatch = n),
        (r = ws(!1)),
        (a = pc.bind(null, L, !1, r.queue)),
        (r = ls()),
        (i = {
          state: t,
          dispatch: null,
          action: e,
          pending: null,
        }),
        (r.queue = i),
        (n = Es.bind(null, L, i, a, n)),
        (i.dispatch = n),
        (r.memoizedState = e),
        [t, n, !1]
      );
    }
    function Ps(e) {
      return Fs(B(), R, e);
    }
    function Fs(e, t, n) {
      if (
        ((t = gs(e, t, Ms)[0]),
        (e = hs(ms)[0]),
        typeof t == `object` && t && typeof t.then == `function`)
      )
        try {
          var r = ds(t);
        } catch (e) {
          throw e === $a ? to : e;
        }
      else r = t;
      t = B();
      var i = t.queue,
        a = i.dispatch;
      return (
        n !== t.memoizedState &&
          ((L.flags |= 2048),
          Rs(
            9,
            {
              destroy: void 0,
            },
            Is.bind(null, i, n),
            null,
          )),
        [r, a, e]
      );
    }
    function Is(e, t) {
      e.action = t;
    }
    function Ls(e) {
      var t = B(),
        n = R;
      if (n !== null) return Fs(t, n, e);
      (B(), (t = t.memoizedState), (n = B()));
      var r = n.queue.dispatch;
      return ((n.memoizedState = e), [t, r, !1]);
    }
    function Rs(e, t, n, r) {
      return (
        (e = {
          tag: e,
          create: n,
          deps: r,
          inst: t,
          next: null,
        }),
        (t = L.updateQueue),
        t === null && ((t = us()), (L.updateQueue = t)),
        (n = t.lastEffect),
        n === null
          ? (t.lastEffect = e.next = e)
          : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e)),
        e
      );
    }
    function zs() {
      return B().memoizedState;
    }
    function Bs(e, t, n, r) {
      var i = ls();
      ((L.flags |= e),
        (i.memoizedState = Rs(
          1 | t,
          {
            destroy: void 0,
          },
          n,
          r === void 0 ? null : r,
        )));
    }
    function Vs(e, t, n, r) {
      var i = B();
      r = r === void 0 ? null : r;
      var a = i.memoizedState.inst;
      R !== null && r !== null && ts(r, R.memoizedState.deps)
        ? (i.memoizedState = Rs(t, a, n, r))
        : ((L.flags |= e), (i.memoizedState = Rs(1 | t, a, n, r)));
    }
    function Hs(e, t) {
      Bs(8390656, 8, e, t);
    }
    function Us(e, t) {
      Vs(2048, 8, e, t);
    }
    function Ws(e) {
      L.flags |= 4;
      var t = L.updateQueue;
      if (t === null) ((t = us()), (L.updateQueue = t), (t.events = [e]));
      else {
        var n = t.events;
        n === null ? (t.events = [e]) : n.push(e);
      }
    }
    function Gs(e) {
      var t = B().memoizedState;
      return (
        Ws({
          ref: t,
          nextImpl: e,
        }),
        function () {
          if (W & 2) throw Error(i(440));
          return t.impl.apply(void 0, arguments);
        }
      );
    }
    function Ks(e, t) {
      return Vs(4, 2, e, t);
    }
    function qs(e, t) {
      return Vs(4, 4, e, t);
    }
    function Js(e, t) {
      if (typeof t == `function`) {
        e = e();
        var n = t(e);
        return function () {
          typeof n == `function` ? n() : t(null);
        };
      }
      if (t != null)
        return (
          (e = e()),
          (t.current = e),
          function () {
            t.current = null;
          }
        );
    }
    function Ys(e, t, n) {
      ((n = n == null ? null : n.concat([e])),
        Vs(4, 4, Js.bind(null, t, e), n));
    }
    function Xs() {}
    function Zs(e, t) {
      var n = B();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      return t !== null && ts(t, r[1]) ? r[0] : ((n.memoizedState = [e, t]), e);
    }
    function Qs(e, t) {
      var n = B();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      if (t !== null && ts(t, r[1])) return r[0];
      if (((r = e()), Xo)) {
        ot(!0);
        try {
          e();
        } finally {
          ot(!1);
        }
      }
      return ((n.memoizedState = [r, t]), r);
    }
    function $s(e, t, n) {
      return n === void 0 || (Ko & 1073741824 && !(q & 261930))
        ? (e.memoizedState = t)
        : ((e.memoizedState = n), (e = Md()), (L.lanes |= e), (sd |= e), n);
    }
    function ec(e, t, n, r) {
      return Kr(n, t)
        ? n
        : Ao.current === null
          ? !(Ko & 106) || (Ko & 1073741824 && !(q & 261930))
            ? ((Ic = !0), (e.memoizedState = n))
            : ((e = Md()), (L.lanes |= e), (sd |= e), t)
          : ((e = $s(e, n, r)), Kr(e, t) || (Ic = !0), e);
    }
    function tc(e, t, n, r, i) {
      var a = O.p;
      O.p = a !== 0 && 8 > a ? a : 8;
      var o = D.T,
        s = {};
      ((s.types = o === null ? null : o.types), (D.T = s), pc(e, !1, t, n));
      try {
        var c = i(),
          l = D.S;
        (l !== null && l(s, c),
          typeof c == `object` && c && typeof c.then == `function`
            ? fc(e, t, qa(c, r), jd(e))
            : fc(e, t, r, jd(e)));
      } catch (n) {
        fc(
          e,
          t,
          {
            then: function () {},
            status: `rejected`,
            reason: n,
          },
          jd(),
        );
      } finally {
        ((O.p = a),
          o !== null && s.types !== null && (o.types = s.types),
          (D.T = o));
      }
    }
    function nc() {}
    function rc(e, t, n, r) {
      if (e.tag !== 5) throw Error(i(476));
      var a = ic(e).queue;
      tc(
        e,
        a,
        t,
        we,
        n === null
          ? nc
          : function () {
              return (ac(e), n(r));
            },
      );
    }
    function ic(e) {
      var t = e.memoizedState;
      if (t !== null) return t;
      t = {
        memoizedState: we,
        baseState: we,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: ms,
          lastRenderedState: we,
        },
        next: null,
      };
      var n = {};
      return (
        (t.next = {
          memoizedState: n,
          baseState: n,
          baseQueue: null,
          queue: {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: ms,
            lastRenderedState: n,
          },
          next: null,
        }),
        (e.memoizedState = t),
        (e = e.alternate),
        e !== null && (e.memoizedState = t),
        t
      );
    }
    function ac(e) {
      var t = ic(e);
      (t.next === null && (t = e.alternate.memoizedState),
        fc(e, t.next.queue, {}, jd()));
    }
    function oc() {
      return ka(sh);
    }
    function sc() {
      return B().memoizedState;
    }
    function cc() {
      return B().memoizedState;
    }
    function lc(e) {
      for (var t = e.return; t !== null;) {
        switch (t.tag) {
          case 24:
          case 3:
            var n = jd();
            e = xo(n);
            var r = So(t, e, n);
            (r !== null && (Pd(r, t, n), Co(r, t, n)),
              (t = {
                cache: Ia(),
              }),
              (e.payload = t));
            return;
        }
        t = t.return;
      }
    }
    function uc(e, t, n) {
      var r = jd();
      ((n = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
        mc(e)
          ? hc(t, n)
          : ((n = ji(e, t, n, r)), n !== null && (Pd(n, e, r), gc(n, t, r))));
    }
    function dc(e, t, n) {
      fc(e, t, n, jd());
    }
    function fc(e, t, n, r) {
      var i = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
      if (mc(e)) hc(t, i);
      else {
        var a = e.alternate;
        if (
          e.lanes === 0 &&
          (a === null || a.lanes === 0) &&
          ((a = t.lastRenderedReducer), a !== null)
        )
          try {
            var o = t.lastRenderedState,
              s = a(o, n);
            if (((i.hasEagerState = !0), (i.eagerState = s), Kr(s, o)))
              return (Ai(e, t, i, 0), G === null && ki(), !1);
          } catch {}
        if (((n = ji(e, t, i, r)), n !== null))
          return (Pd(n, e, r), gc(n, t, r), !0);
      }
      return !1;
    }
    function pc(e, t, n, r) {
      if (
        ((r = {
          lane: 2,
          revertLane: Pf(),
          gesture: null,
          action: r,
          hasEagerState: !1,
          eagerState: null,
          next: null,
        }),
        mc(e))
      ) {
        if (t) throw Error(i(479));
      } else ((t = ji(e, n, r, 2)), t !== null && Pd(t, e, 2));
    }
    function mc(e) {
      var t = e.alternate;
      return e === L || (t !== null && t === L);
    }
    function hc(e, t) {
      Yo = Jo = !0;
      var n = e.pending;
      (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
        (e.pending = t));
    }
    function gc(e, t, n) {
      if (n & 4194048) {
        var r = t.lanes;
        ((r &= e.pendingLanes), (n |= r), (t.lanes = n), wt(e, n));
      }
    }
    var _c = {
        readContext: ka,
        use: fs,
        useCallback: z,
        useContext: z,
        useEffect: z,
        useImperativeHandle: z,
        useLayoutEffect: z,
        useInsertionEffect: z,
        useMemo: z,
        useReducer: z,
        useRef: z,
        useState: z,
        useDebugValue: z,
        useDeferredValue: z,
        useTransition: z,
        useSyncExternalStore: z,
        useId: z,
        useHostTransitionStatus: z,
        useFormState: z,
        useActionState: z,
        useOptimistic: z,
        useMemoCache: z,
        useCacheRefresh: z,
        useEffectEvent: z,
      },
      vc = {
        readContext: ka,
        use: fs,
        useCallback: function (e, t) {
          return ((ls().memoizedState = [e, t === void 0 ? null : t]), e);
        },
        useContext: ka,
        useEffect: Hs,
        useImperativeHandle: function (e, t, n) {
          ((n = n == null ? null : n.concat([e])),
            Bs(4194308, 4, Js.bind(null, t, e), n));
        },
        useLayoutEffect: function (e, t) {
          return Bs(4194308, 4, e, t);
        },
        useInsertionEffect: function (e, t) {
          Bs(4, 2, e, t);
        },
        useMemo: function (e, t) {
          var n = ls();
          t = t === void 0 ? null : t;
          var r = e();
          if (Xo) {
            ot(!0);
            try {
              e();
            } finally {
              ot(!1);
            }
          }
          return ((n.memoizedState = [r, t]), r);
        },
        useReducer: function (e, t, n) {
          var r = ls();
          if (n !== void 0) {
            var i = n(t);
            if (Xo) {
              ot(!0);
              try {
                n(t);
              } finally {
                ot(!1);
              }
            }
          } else i = t;
          return (
            (r.memoizedState = r.baseState = i),
            (e = {
              pending: null,
              lanes: 0,
              dispatch: null,
              lastRenderedReducer: e,
              lastRenderedState: i,
            }),
            (r.queue = e),
            (e = e.dispatch = uc.bind(null, L, e)),
            [r.memoizedState, e]
          );
        },
        useRef: function (e) {
          var t = ls();
          return (
            (e = {
              current: e,
            }),
            (t.memoizedState = e)
          );
        },
        useState: function (e) {
          e = ws(e);
          var t = e.queue,
            n = dc.bind(null, L, t);
          return ((t.dispatch = n), [e.memoizedState, n]);
        },
        useDebugValue: Xs,
        useDeferredValue: function (e, t) {
          return $s(ls(), e, t);
        },
        useTransition: function () {
          var e = ws(!1);
          return (
            (e = tc.bind(null, L, e.queue, !0, !1)),
            (ls().memoizedState = e),
            [!1, e]
          );
        },
        useSyncExternalStore: function (e, t, n) {
          var r = L,
            a = ls();
          if (I) {
            if (n === void 0) throw Error(i(407));
            n = n();
          } else {
            if (((n = t()), G === null)) throw Error(i(349));
            q & 127 || ys(r, t, n);
          }
          a.memoizedState = n;
          var o = {
            value: n,
            getSnapshot: t,
          };
          return (
            (a.queue = o),
            Hs(xs.bind(null, r, o, e), [e]),
            (r.flags |= 2048),
            Rs(
              9,
              {
                destroy: void 0,
              },
              bs.bind(null, r, o, n, t),
              null,
            ),
            n
          );
        },
        useId: function () {
          var e = ls(),
            t = G.identifierPrefix;
          if (I) {
            var n = na,
              r = ta;
            ((n = (r & ~(1 << (32 - st(r) - 1))).toString(32) + n),
              (t = `_` + t + `R_` + n),
              (n = Zo++),
              0 < n && (t += `H` + n.toString(32)),
              (t += `_`));
          } else ((n = es++), (t = `_` + t + `r_` + n.toString(32) + `_`));
          return (e.memoizedState = t);
        },
        useHostTransitionStatus: oc,
        useFormState: Ns,
        useActionState: Ns,
        useOptimistic: function (e) {
          var t = ls();
          t.memoizedState = t.baseState = e;
          var n = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: null,
            lastRenderedState: null,
          };
          return (
            (t.queue = n),
            (t = pc.bind(null, L, !0, n)),
            (n.dispatch = t),
            [e, t]
          );
        },
        useMemoCache: ps,
        useCacheRefresh: function () {
          return (ls().memoizedState = lc.bind(null, L));
        },
        useEffectEvent: function (e) {
          var t = ls(),
            n = {
              impl: e,
            };
          return (
            (t.memoizedState = n),
            function () {
              if (W & 2) throw Error(i(440));
              return n.impl.apply(void 0, arguments);
            }
          );
        },
      },
      yc = {
        readContext: ka,
        use: fs,
        useCallback: Zs,
        useContext: ka,
        useEffect: Us,
        useImperativeHandle: Ys,
        useInsertionEffect: Ks,
        useLayoutEffect: qs,
        useMemo: Qs,
        useReducer: hs,
        useRef: zs,
        useState: function () {
          return hs(ms);
        },
        useDebugValue: Xs,
        useDeferredValue: function (e, t) {
          return ec(B(), R.memoizedState, e, t);
        },
        useTransition: function () {
          var e = hs(ms)[0],
            t = B().memoizedState;
          return [typeof e == `boolean` ? e : ds(e), t];
        },
        useSyncExternalStore: vs,
        useId: sc,
        useHostTransitionStatus: oc,
        useFormState: Ps,
        useActionState: Ps,
        useOptimistic: function (e, t) {
          return Ts(B(), R, e, t);
        },
        useMemoCache: ps,
        useCacheRefresh: cc,
        useEffectEvent: Gs,
      },
      bc = {
        readContext: ka,
        use: fs,
        useCallback: Zs,
        useContext: ka,
        useEffect: Us,
        useImperativeHandle: Ys,
        useInsertionEffect: Ks,
        useLayoutEffect: qs,
        useMemo: Qs,
        useReducer: _s,
        useRef: zs,
        useState: function () {
          return _s(ms);
        },
        useDebugValue: Xs,
        useDeferredValue: function (e, t) {
          var n = B();
          return R === null ? $s(n, e, t) : ec(n, R.memoizedState, e, t);
        },
        useTransition: function () {
          var e = _s(ms)[0],
            t = B().memoizedState;
          return [typeof e == `boolean` ? e : ds(e), t];
        },
        useSyncExternalStore: vs,
        useId: sc,
        useHostTransitionStatus: oc,
        useFormState: Ls,
        useActionState: Ls,
        useOptimistic: function (e, t) {
          var n = B();
          return R === null
            ? ((n.baseState = e), [e, n.queue.dispatch])
            : Ts(n, R, e, t);
        },
        useMemoCache: ps,
        useCacheRefresh: cc,
        useEffectEvent: Gs,
      };
    function xc(e, t, n, r) {
      ((t = e.memoizedState),
        (n = n(r, t)),
        (n = n == null ? t : C({}, t, n)),
        (e.memoizedState = n),
        e.lanes === 0 && (e.updateQueue.baseState = n));
    }
    var Sc = {
      enqueueSetState: function (e, t, n) {
        e = e._reactInternals;
        var r = jd(),
          i = xo(r);
        ((i.payload = t),
          n != null && (i.callback = n),
          (t = So(e, i, r)),
          t !== null && (Pd(t, e, r), Co(t, e, r)));
      },
      enqueueReplaceState: function (e, t, n) {
        e = e._reactInternals;
        var r = jd(),
          i = xo(r);
        ((i.tag = 1),
          (i.payload = t),
          n != null && (i.callback = n),
          (t = So(e, i, r)),
          t !== null && (Pd(t, e, r), Co(t, e, r)));
      },
      enqueueForceUpdate: function (e, t) {
        e = e._reactInternals;
        var n = jd(),
          r = xo(n);
        ((r.tag = 2),
          t != null && (r.callback = t),
          (t = So(e, r, n)),
          t !== null && (Pd(t, e, n), Co(t, e, n)));
      },
    };
    function Cc(e, t, n, r, i, a, o) {
      return (
        (e = e.stateNode),
        typeof e.shouldComponentUpdate == `function`
          ? e.shouldComponentUpdate(r, a, o)
          : t.prototype && t.prototype.isPureReactComponent
            ? !qr(n, r) || !qr(i, a)
            : !0
      );
    }
    function wc(e, t, n, r) {
      ((e = t.state),
        typeof t.componentWillReceiveProps == `function` &&
          t.componentWillReceiveProps(n, r),
        typeof t.UNSAFE_componentWillReceiveProps == `function` &&
          t.UNSAFE_componentWillReceiveProps(n, r),
        t.state !== e && Sc.enqueueReplaceState(t, t.state, null));
    }
    function Tc(e, t) {
      var n = t;
      if (`ref` in t) for (var r in ((n = {}), t)) r !== `ref` && (n[r] = t[r]);
      if ((e = e.defaultProps))
        for (var i in (n === t && (n = C({}, n)), e))
          n[i] === void 0 && (n[i] = e[i]);
      return n;
    }
    function Ec(e) {
      Ti(e);
    }
    function Dc(e) {
      console.error(e);
    }
    function Oc(e) {
      Ti(e);
    }
    function kc(e, t) {
      try {
        var n = e.onUncaughtError;
        n(t.value, {
          componentStack: t.stack,
        });
      } catch (e) {
        setTimeout(function () {
          throw e;
        });
      }
    }
    function Ac(e, t, n) {
      try {
        var r = e.onCaughtError;
        r(n.value, {
          componentStack: n.stack,
          errorBoundary: t.tag === 1 ? t.stateNode : null,
        });
      } catch (e) {
        setTimeout(function () {
          throw e;
        });
      }
    }
    function jc(e, t, n) {
      return (
        (n = xo(n)),
        (n.tag = 3),
        (n.payload = {
          element: null,
        }),
        (n.callback = function () {
          kc(e, t);
        }),
        n
      );
    }
    function Mc(e) {
      return ((e = xo(e)), (e.tag = 3), e);
    }
    function Nc(e, t, n, r) {
      var i = n.type.getDerivedStateFromError;
      if (typeof i == `function`) {
        var a = r.value;
        ((e.payload = function () {
          return i(a);
        }),
          (e.callback = function () {
            Ac(t, n, r);
          }));
      }
      var o = n.stateNode;
      o !== null &&
        typeof o.componentDidCatch == `function` &&
        (e.callback = function () {
          (Ac(t, n, r),
            typeof i != `function` &&
              (yd === null ? (yd = new Set([this])) : yd.add(this)));
          var e = r.stack;
          this.componentDidCatch(r.value, {
            componentStack: e === null ? `` : e,
          });
        });
    }
    function Pc(e, t, n, r, a) {
      if (
        ((n.flags |= 32768),
        typeof r == `object` && r && typeof r.then == `function`)
      ) {
        if (
          ((t = n.alternate),
          t !== null && Ea(t, n, a, !0),
          (n = Fo.current),
          n !== null)
        ) {
          switch (n.tag) {
            case 31:
            case 13:
            case 19:
              return (
                Io === null ? Kd() : n.alternate === null && Y === 0 && (Y = 3),
                (n.flags &= -257),
                (n.flags |= 65536),
                (n.lanes = a),
                r === no
                  ? (n.flags |= 16384)
                  : ((t = n.updateQueue),
                    t === null ? (n.updateQueue = new Set([r])) : t.add(r),
                    mf(e, r, a)),
                !1
              );
            case 22:
              return (
                (n.flags |= 65536),
                r === no
                  ? (n.flags |= 16384)
                  : ((t = n.updateQueue),
                    t === null
                      ? ((t = {
                          transitions: null,
                          markerInstances: null,
                          retryQueue: new Set([r]),
                        }),
                        (n.updateQueue = t))
                      : ((n = t.retryQueue),
                        n === null ? (t.retryQueue = new Set([r])) : n.add(r)),
                    mf(e, r, a)),
                !1
              );
          }
          throw Error(i(435, n.tag));
        }
        return (mf(e, r, a), Kd(), !1);
      }
      if (I)
        return (
          (t = Fo.current),
          t === null
            ? (r !== da &&
                ((t = Error(i(423), {
                  cause: r,
                })),
                va(qi(t, n))),
              (e = e.current.alternate),
              (e.flags |= 65536),
              (a &= -a),
              (e.lanes |= a),
              (r = qi(r, n)),
              (a = jc(e.stateNode, r, a)),
              wo(e, a),
              Y !== 4 && (Y = 2))
            : (!(t.flags & 65536) && (t.flags |= 256),
              (t.flags |= 65536),
              (t.lanes = a),
              r !== da &&
                ((e = Error(i(422), {
                  cause: r,
                })),
                va(qi(e, n)))),
          !1
        );
      var o = Error(i(520), {
        cause: r,
      });
      if (
        ((o = qi(o, n)),
        fd === null ? (fd = [o]) : fd.push(o),
        Y !== 4 && (Y = 2),
        t === null)
      )
        return !0;
      ((r = qi(r, n)), (n = t));
      do {
        switch (n.tag) {
          case 3:
            return (
              (n.flags |= 65536),
              (e = a & -a),
              (n.lanes |= e),
              (e = jc(n.stateNode, r, e)),
              wo(n, e),
              !1
            );
          case 1:
            if (
              ((t = n.type),
              (o = n.stateNode),
              !(n.flags & 128) &&
                (typeof t.getDerivedStateFromError == `function` ||
                  (o !== null &&
                    typeof o.componentDidCatch == `function` &&
                    (yd === null || !yd.has(o)))))
            )
              return (
                (n.flags |= 65536),
                (a &= -a),
                (n.lanes |= a),
                (a = Mc(a)),
                Nc(a, e, n, r),
                wo(n, a),
                !1
              );
            break;
          case 22:
            if (n.memoizedState !== null) return ((n.flags |= 65536), !1);
        }
        n = n.return;
      } while (n !== null);
      return !1;
    }
    var Fc = Error(i(461)),
      Ic = !1;
    function Lc(e, t, n, r) {
      t.child = e === null ? _o(t, null, n, r) : go(t, e.child, n, r);
    }
    function Rc(e, t, n, r, i) {
      n = n.render;
      var a = t.ref;
      if (`ref` in r) {
        var o = {};
        for (var s in r) s !== `ref` && (o[s] = r[s]);
      } else o = r;
      return (
        Oa(t),
        (r = ns(e, t, n, o, a, i)),
        (s = os()),
        e !== null && !Ic
          ? (ss(e, t, i), fl(e, t, i))
          : (I && s && aa(t), (t.flags |= 1), Lc(e, t, r, i), t.child)
      );
    }
    function zc(e, t, n, r, i) {
      if (e === null) {
        var a = n.type;
        return typeof a == `function` &&
          !Ri(a) &&
          a.defaultProps === void 0 &&
          n.compare === null
          ? ((t.tag = 15), (t.type = a), Bc(e, t, a, r, i))
          : ((e = Vi(n.type, null, r, t, t.mode, i)),
            (e.ref = t.ref),
            (e.return = t),
            (t.child = e));
      }
      if (((a = e.child), !pl(e, i))) {
        var o = a.memoizedProps;
        if (
          ((n = n.compare),
          (n = n === null ? qr : n),
          n(o, r) && e.ref === t.ref)
        )
          return fl(e, t, i);
      }
      return (
        (t.flags |= 1),
        (e = zi(a, r)),
        (e.ref = t.ref),
        (e.return = t),
        (t.child = e)
      );
    }
    function Bc(e, t, n, r, i) {
      if (e !== null) {
        var a = e.memoizedProps;
        if (qr(a, r) && e.ref === t.ref) {
          if (((Ic = !1), (t.pendingProps = r = a), pl(e, i)))
            e.flags & 131072 && (Ic = !0);
          else return ((t.lanes = e.lanes), fl(e, t, i));
        }
      }
      return Jc(e, t, n, r, i);
    }
    function Vc(e, t, n, r) {
      var i = r.children,
        a = e === null ? null : e.memoizedState;
      if (
        (e === null &&
          t.stateNode === null &&
          (t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null,
          }),
        r.mode === `hidden`)
      ) {
        if (t.flags & 128) {
          if (((a = a === null ? n : a.baseLanes | n), e !== null)) {
            for (r = t.child = e.child, i = 0; r !== null;)
              ((i = i | r.lanes | r.childLanes), (r = r.sibling));
            r = i & ~a;
          } else ((r = 0), (t.child = null));
          return Uc(e, t, a, n, r);
        }
        if (n & 536870912)
          ((t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
          }),
            e !== null && Za(t, a === null ? null : a.cachePool),
            a === null ? No() : Mo(t, a),
            zo(t));
        else
          return (
            (r = t.lanes = 536870912),
            Uc(e, t, a === null ? n : a.baseLanes | n, n, r)
          );
      } else
        a === null
          ? (e !== null && Za(t, null), No(), Bo())
          : (Za(t, a.cachePool), Mo(t, a), Bo(), (t.memoizedState = null));
      return (Lc(e, t, i, n), t.child);
    }
    function Hc(e, t) {
      return (
        (e !== null && e.tag === 22) ||
          t.stateNode !== null ||
          (t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null,
          }),
        t.sibling
      );
    }
    function Uc(e, t, n, r, i) {
      var a = Xa();
      return (
        (a =
          a === null
            ? null
            : {
                parent: Fa._currentValue,
                pool: a,
              }),
        (t.memoizedState = {
          baseLanes: n,
          cachePool: a,
        }),
        e !== null && Za(t, null),
        No(),
        zo(t),
        e !== null && Ea(e, t, r, !0),
        (t.childLanes = i),
        null
      );
    }
    function Wc(e, t) {
      return (
        (t = rl(
          {
            mode: t.mode,
            children: t.children,
          },
          e.mode,
        )),
        (t.ref = e.ref),
        (e.child = t),
        (t.return = e),
        t
      );
    }
    function Gc(e, t, n) {
      return (
        go(t, e.child, null, n),
        (e = Wc(t, t.pendingProps)),
        (e.flags |= 2),
        Vo(t),
        (t.memoizedState = null),
        e
      );
    }
    function Kc(e, t, n) {
      var r = t.pendingProps,
        a = !!(t.flags & 128);
      if (((t.flags &= -129), e === null)) {
        if (I) {
          if (r.mode === `hidden`)
            return (
              (e = Wc(t, r)),
              (t.lanes = 536870912),
              (e.memoizedState = {
                baseLanes: 0,
                cachePool: null,
              }),
              Hc(null, e)
            );
          if (
            (Ro(t),
            (e = F)
              ? ((e = am(e, ua)),
                (e = e !== null && e.data === `&` ? e : null),
                e !== null &&
                  ((t.memoizedState = {
                    dehydrated: e,
                    treeContext:
                      ea === null
                        ? null
                        : {
                            id: ta,
                            overflow: na,
                          },
                    retryLane: 536870912,
                    hydrationErrors: null,
                  }),
                  (n = Wi(e)),
                  (n.return = t),
                  (t.child = n),
                  (ca = t),
                  (F = null)))
              : (e = null),
            e === null)
          )
            throw fa(t);
          return ((t.lanes = 536870912), null);
        }
        return Wc(t, r);
      }
      var o = e.memoizedState;
      if (o !== null) {
        var s = o.dehydrated;
        if ((Ro(t), a)) {
          if (t.flags & 256) ((t.flags &= -257), (t = Gc(e, t, n)));
          else if (t.memoizedState !== null)
            ((t.child = e.child), (t.flags |= 128), (t = null));
          else throw Error(i(558));
        } else if (
          (Ic || Ea(e, t, n, !1), (a = (n & e.childLanes) !== 0), Ic || a)
        ) {
          if (Ao.current === null) {
            if (
              ((r = G),
              r !== null && ((s = Tt(r, n)), s !== 0 && s !== o.retryLane))
            )
              throw ((o.retryLane = s), Mi(e, s), Pd(r, e, s), Fc);
            Kd();
          }
          t = Gc(e, t, n);
        } else
          ((e = o.treeContext),
            (F = lm(s.nextSibling)),
            (ca = t),
            (I = !0),
            (la = null),
            (ua = !1),
            e !== null && sa(t, e),
            (t = Wc(t, r)),
            (t.flags |= 134221824));
        return t;
      }
      return (
        (e = zi(e.child, {
          mode: r.mode,
          children: r.children,
        })),
        (e.ref = t.ref),
        (t.child = e),
        (e.return = t),
        e
      );
    }
    function qc(e, t) {
      var n = t.ref;
      if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
      else {
        if (typeof n != `function` && typeof n != `object`) throw Error(i(284));
        (e === null || e.ref !== n) && (t.flags |= 4194816);
      }
    }
    function Jc(e, t, n, r, i) {
      return (
        Oa(t),
        (n = ns(e, t, n, r, void 0, i)),
        (r = os()),
        e !== null && !Ic
          ? (ss(e, t, i), fl(e, t, i))
          : (I && r && aa(t), (t.flags |= 1), Lc(e, t, n, i), t.child)
      );
    }
    function Yc(e, t, n, r, i, a) {
      return (
        Oa(t),
        (t.updateQueue = null),
        (n = is(t, r, n, i)),
        rs(e),
        (r = os()),
        e !== null && !Ic
          ? (ss(e, t, a), fl(e, t, a))
          : (I && r && aa(t), (t.flags |= 1), Lc(e, t, n, a), t.child)
      );
    }
    function Xc(e, t, n, r, i) {
      if ((Oa(t), t.stateNode === null)) {
        var a = Fi,
          o = n.contextType;
        (typeof o == `object` && o && (a = ka(o)),
          (a = new n(r, a)),
          (t.memoizedState =
            a.state !== null && a.state !== void 0 ? a.state : null),
          (a.updater = Sc),
          (t.stateNode = a),
          (a._reactInternals = t),
          (a = t.stateNode),
          (a.props = r),
          (a.state = t.memoizedState),
          (a.refs = {}),
          yo(t),
          (o = n.contextType),
          (a.context = typeof o == `object` && o ? ka(o) : Fi),
          (a.state = t.memoizedState),
          (o = n.getDerivedStateFromProps),
          typeof o == `function` &&
            (xc(t, n, o, r), (a.state = t.memoizedState)),
          typeof n.getDerivedStateFromProps == `function` ||
            typeof a.getSnapshotBeforeUpdate == `function` ||
            (typeof a.UNSAFE_componentWillMount != `function` &&
              typeof a.componentWillMount != `function`) ||
            ((o = a.state),
            typeof a.componentWillMount == `function` && a.componentWillMount(),
            typeof a.UNSAFE_componentWillMount == `function` &&
              a.UNSAFE_componentWillMount(),
            o !== a.state && Sc.enqueueReplaceState(a, a.state, null),
            Do(t, r, a, i),
            Eo(),
            (a.state = t.memoizedState)),
          typeof a.componentDidMount == `function` && (t.flags |= 4194308),
          (r = !0));
      } else if (e === null) {
        a = t.stateNode;
        var s = t.memoizedProps,
          c = Tc(n, s);
        a.props = c;
        var l = a.context,
          u = n.contextType;
        ((o = Fi), typeof u == `object` && u && (o = ka(u)));
        var d = n.getDerivedStateFromProps;
        ((u =
          typeof d == `function` ||
          typeof a.getSnapshotBeforeUpdate == `function`),
          (s = t.pendingProps !== s),
          u ||
            (typeof a.UNSAFE_componentWillReceiveProps != `function` &&
              typeof a.componentWillReceiveProps != `function`) ||
            ((s || l !== o) && wc(t, a, r, o)),
          (vo = !1));
        var f = t.memoizedState;
        ((a.state = f),
          Do(t, r, a, i),
          Eo(),
          (l = t.memoizedState),
          s || f !== l || vo
            ? (typeof d == `function` &&
                (xc(t, n, d, r), (l = t.memoizedState)),
              (c = vo || Cc(t, n, c, r, f, l, o))
                ? (u ||
                    (typeof a.UNSAFE_componentWillMount != `function` &&
                      typeof a.componentWillMount != `function`) ||
                    (typeof a.componentWillMount == `function` &&
                      a.componentWillMount(),
                    typeof a.UNSAFE_componentWillMount == `function` &&
                      a.UNSAFE_componentWillMount()),
                  typeof a.componentDidMount == `function` &&
                    (t.flags |= 4194308))
                : (typeof a.componentDidMount == `function` &&
                    (t.flags |= 4194308),
                  (t.memoizedProps = r),
                  (t.memoizedState = l)),
              (a.props = r),
              (a.state = l),
              (a.context = o),
              (r = c))
            : (typeof a.componentDidMount == `function` && (t.flags |= 4194308),
              (r = !1)));
      } else {
        ((a = t.stateNode),
          bo(e, t),
          (o = t.memoizedProps),
          (u = Tc(n, o)),
          (a.props = u),
          (d = t.pendingProps),
          (f = a.context),
          (l = n.contextType),
          (c = Fi),
          typeof l == `object` && l && (c = ka(l)),
          (s = n.getDerivedStateFromProps),
          (l =
            typeof s == `function` ||
            typeof a.getSnapshotBeforeUpdate == `function`) ||
            (typeof a.UNSAFE_componentWillReceiveProps != `function` &&
              typeof a.componentWillReceiveProps != `function`) ||
            ((o !== d || f !== c) && wc(t, a, r, c)),
          (vo = !1),
          (f = t.memoizedState),
          (a.state = f),
          Do(t, r, a, i),
          Eo());
        var p = t.memoizedState;
        o !== d ||
        f !== p ||
        vo ||
        (e !== null && e.dependencies !== null && Da(e.dependencies))
          ? (typeof s == `function` && (xc(t, n, s, r), (p = t.memoizedState)),
            (u =
              vo ||
              Cc(t, n, u, r, f, p, c) ||
              (e !== null && e.dependencies !== null && Da(e.dependencies)))
              ? (l ||
                  (typeof a.UNSAFE_componentWillUpdate != `function` &&
                    typeof a.componentWillUpdate != `function`) ||
                  (typeof a.componentWillUpdate == `function` &&
                    a.componentWillUpdate(r, p, c),
                  typeof a.UNSAFE_componentWillUpdate == `function` &&
                    a.UNSAFE_componentWillUpdate(r, p, c)),
                typeof a.componentDidUpdate == `function` && (t.flags |= 4),
                typeof a.getSnapshotBeforeUpdate == `function` &&
                  (t.flags |= 1024))
              : (typeof a.componentDidUpdate != `function` ||
                  (o === e.memoizedProps && f === e.memoizedState) ||
                  (t.flags |= 4),
                typeof a.getSnapshotBeforeUpdate != `function` ||
                  (o === e.memoizedProps && f === e.memoizedState) ||
                  (t.flags |= 1024),
                (t.memoizedProps = r),
                (t.memoizedState = p)),
            (a.props = r),
            (a.state = p),
            (a.context = c),
            (r = u))
          : (typeof a.componentDidUpdate != `function` ||
              (o === e.memoizedProps && f === e.memoizedState) ||
              (t.flags |= 4),
            typeof a.getSnapshotBeforeUpdate != `function` ||
              (o === e.memoizedProps && f === e.memoizedState) ||
              (t.flags |= 1024),
            (r = !1));
      }
      return (
        (a = r),
        qc(e, t),
        (r = !!(t.flags & 128)),
        a || r
          ? ((a = t.stateNode),
            (n =
              r && typeof n.getDerivedStateFromError != `function`
                ? null
                : a.render()),
            (t.flags |= 1),
            e !== null && r
              ? ((t.child = go(t, e.child, null, i)),
                (t.child = go(t, null, n, i)))
              : Lc(e, t, n, i),
            (t.memoizedState = a.state),
            (e = t.child))
          : (e = fl(e, t, i)),
        e
      );
    }
    function Zc(e, t, n, r) {
      return (ga(), (t.flags |= 256), Lc(e, t, n, r), t.child);
    }
    var Qc = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null,
    };
    function $c(e) {
      return {
        baseLanes: e,
        cachePool: Qa(),
      };
    }
    function el(e, t, n) {
      return ((e = e === null ? 0 : e.childLanes & ~n), t && (e |= ud), e);
    }
    function tl(e, t, n) {
      var r = t.pendingProps,
        i = !1,
        a = !!(t.flags & 128),
        o;
      if (
        ((o = a) ||
          (o =
            e !== null && e.memoizedState === null ? !1 : !!(Ho.current & 2)),
        o && ((i = !0), (t.flags &= -129)),
        (o = !!(t.flags & 32)),
        (t.flags &= -33),
        e === null)
      ) {
        if (I) {
          if (
            (i ? Lo(t) : Bo(),
            (e = F)
              ? ((e = am(e, ua)),
                (e = e !== null && e.data !== `&` ? e : null),
                e !== null &&
                  ((t.memoizedState = {
                    dehydrated: e,
                    treeContext:
                      ea === null
                        ? null
                        : {
                            id: ta,
                            overflow: na,
                          },
                    retryLane: 536870912,
                    hydrationErrors: null,
                  }),
                  (n = Wi(e)),
                  (n.return = t),
                  (t.child = n),
                  (ca = t),
                  (F = null)))
              : (e = null),
            e === null)
          )
            throw fa(t);
          return ((t.lanes = sm(e) ? 32 : 536870912), null);
        }
        return (
          (a = r.children),
          (r = r.fallback),
          i
            ? (Bo(),
              (i = t.mode),
              (a = rl(
                {
                  mode: `hidden`,
                  children: a,
                },
                i,
              )),
              (r = Hi(r, i, n, null)),
              (a.return = t),
              (r.return = t),
              (a.sibling = r),
              (t.child = a),
              (r = t.child),
              (r.memoizedState = $c(n)),
              (r.childLanes = el(e, o, n)),
              (t.memoizedState = Qc),
              Hc(null, r))
            : (Lo(t), nl(t, a))
        );
      }
      var s = e.memoizedState;
      if (s !== null) {
        var c = s.dehydrated;
        if (c !== null) return al(e, t, a, o, r, c, s, n);
      }
      return i
        ? (Bo(),
          (i = r.fallback),
          (a = t.mode),
          (s = e.child),
          (c = s.sibling),
          (r = zi(s, {
            mode: `hidden`,
            children: r.children,
          })),
          (r.subtreeFlags = s.subtreeFlags & 1206910976),
          c === null
            ? ((i = Hi(i, a, n, null)), (i.flags |= 2))
            : (i = zi(c, i)),
          (i.return = t),
          (r.return = t),
          (r.sibling = i),
          (t.child = r),
          Hc(null, r),
          (r = t.child),
          (i = e.child.memoizedState),
          i === null
            ? (i = $c(n))
            : ((a = i.cachePool),
              a === null
                ? (a = Qa())
                : ((s = Fa._currentValue),
                  (a =
                    a.parent === s
                      ? a
                      : {
                          parent: s,
                          pool: s,
                        })),
              (i = {
                baseLanes: i.baseLanes | n,
                cachePool: a,
              })),
          (r.memoizedState = i),
          (r.childLanes = el(e, o, n)),
          (t.memoizedState = Qc),
          Hc(e.child, r))
        : (Lo(t),
          (n = e.child),
          (e = n.sibling),
          (n = zi(n, {
            mode: `visible`,
            children: r.children,
          })),
          (n.return = t),
          (n.sibling = null),
          e !== null &&
            ((o = t.deletions),
            o === null ? ((t.deletions = [e]), (t.flags |= 16)) : o.push(e)),
          (t.child = n),
          (t.memoizedState = null),
          n);
    }
    function nl(e, t) {
      return (
        (t = rl(
          {
            mode: `visible`,
            children: t,
          },
          e.mode,
        )),
        (t.return = e),
        (e.child = t)
      );
    }
    function rl(e, t) {
      return ((e = Li(22, e, null, t)), (e.lanes = 0), e);
    }
    function il(e, t, n) {
      return (
        go(t, e.child, null, n),
        (e = nl(t, t.pendingProps.children)),
        (e.flags |= 2),
        (t.memoizedState = null),
        e
      );
    }
    function al(e, t, n, r, a, o, s, c) {
      if (n)
        return t.flags & 256
          ? (Lo(t), (t.flags &= -257), il(e, t, c))
          : t.memoizedState === null
            ? (Bo(),
              (o = a.fallback),
              (s = t.mode),
              (a = rl(
                {
                  mode: `visible`,
                  children: a.children,
                },
                s,
              )),
              (o = Hi(o, s, c, null)),
              (o.flags |= 2),
              (a.return = t),
              (o.return = t),
              (a.sibling = o),
              (t.child = a),
              go(t, e.child, null, c),
              (a = t.child),
              (a.memoizedState = $c(c)),
              (a.childLanes = el(e, r, c)),
              (t.memoizedState = Qc),
              Hc(null, a))
            : (Bo(), (t.child = e.child), (t.flags |= 128), null);
      if ((Lo(t), sm(o))) {
        if (((r = o.nextSibling && o.nextSibling.dataset), r)) var l = r.dgst;
        return (
          (r = l),
          r !== `` &&
            ((a = Error(i(419))),
            (a.stack = ``),
            (a.digest = r),
            va({
              value: a,
              source: null,
              stack: null,
            })),
          il(e, t, c)
        );
      }
      if ((Ic || Ea(e, t, c, !1), (r = (c & e.childLanes) !== 0), Ic || r)) {
        if (Ao.current !== null) return il(e, t, c);
        if (
          ((r = G),
          r !== null && ((a = Tt(r, c)), a !== 0 && a !== s.retryLane))
        )
          throw ((s.retryLane = a), Mi(e, a), Pd(r, e, a), Fc);
        return (om(o) || Kd(), il(e, t, c));
      }
      return om(o)
        ? ((t.flags |= 192), (t.child = e.child), null)
        : ((e = s.treeContext),
          (F = lm(o.nextSibling)),
          (ca = t),
          (I = !0),
          (la = null),
          (ua = !1),
          e !== null && sa(t, e),
          (t = nl(t, a.children)),
          (t.flags |= 134221824),
          t);
    }
    function ol(e, t, n) {
      e.lanes |= t;
      var r = e.alternate;
      (r !== null && (r.lanes |= t), wa(e.return, t, n));
    }
    function sl(e) {
      for (var t = null; e !== null;) {
        var n = e.alternate;
        (n !== null && Go(n) === null && (t = e), (e = e.sibling));
      }
      return t;
    }
    function cl(e, t, n, r, i, a) {
      var o = e.memoizedState;
      o === null
        ? (e.memoizedState = {
            isBackwards: t,
            rendering: null,
            renderingStartTime: 0,
            last: r,
            tail: n,
            tailMode: i,
            treeForkCount: a,
          })
        : ((o.isBackwards = t),
          (o.rendering = null),
          (o.renderingStartTime = 0),
          (o.last = r),
          (o.tail = n),
          (o.tailMode = i),
          (o.treeForkCount = a));
    }
    function ll(e) {
      var t = e.child;
      for (e.child = null; t !== null;) {
        var n = t.sibling;
        ((t.sibling = e.child), (e.child = t), (t = n));
      }
    }
    function ul(e, t, n) {
      var r = t.pendingProps,
        i = r.revealOrder,
        a = r.tail;
      r = r.children;
      var o = Ho.current;
      if (t.flags & 128) return (Uo(t, o), null);
      var s = !!(o & 2);
      if (
        (s ? ((o = (o & 1) | 2), (t.flags |= 128)) : (o &= 1),
        Uo(t, o),
        i === `backwards` && e !== null
          ? (ll(e), Lc(e, t, r, n), ll(e))
          : Lc(e, t, r, n),
        (r = I ? Zi : 0),
        !s && e !== null && e.flags & 128)
      )
        a: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && ol(e, n, t);
          else if (e.tag === 19) ol(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break a;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break a;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      switch (i) {
        case `backwards`:
          ((n = sl(t.child)),
            n === null
              ? ((i = t.child), (t.child = null))
              : ((i = n.sibling), (n.sibling = null), ll(t)),
            cl(t, !0, i, null, a, r));
          break;
        case `unstable_legacy-backwards`:
          for (n = null, i = t.child, t.child = null; i !== null;) {
            if (((e = i.alternate), e !== null && Go(e) === null)) {
              t.child = i;
              break;
            }
            ((e = i.sibling), (i.sibling = n), (n = i), (i = e));
          }
          cl(t, !0, n, null, a, r);
          break;
        case `together`:
          cl(t, !1, null, null, void 0, r);
          break;
        case `independent`:
          t.memoizedState = null;
          break;
        default:
          ((n = sl(t.child)),
            n === null
              ? ((i = t.child), (t.child = null))
              : ((i = n.sibling), (n.sibling = null)),
            cl(t, !1, i, n, a, r));
      }
      return t.child;
    }
    function dl(e, t, n) {
      var r = t.pendingProps;
      return (Sa(t, t.type, r.value), Lc(e, t, r.children, n), t.child);
    }
    function fl(e, t, n) {
      if (
        (e !== null && (t.dependencies = e.dependencies),
        (sd |= t.lanes),
        (n & t.childLanes) === 0)
      ) {
        if (e !== null) {
          if ((Ea(e, t, n, !1), (n & t.childLanes) === 0)) return null;
        } else return null;
      }
      if (e !== null && t.child !== e.child) throw Error(i(153));
      if (t.child !== null) {
        for (
          e = t.child, n = zi(e, e.pendingProps), t.child = n, n.return = t;
          e.sibling !== null;
        )
          ((e = e.sibling),
            (n = n.sibling = zi(e, e.pendingProps)),
            (n.return = t));
        n.sibling = null;
      }
      return t.child;
    }
    function pl(e, t) {
      return (
        (e.lanes & t) !== 0 || ((e = e.dependencies), !!(e !== null && Da(e)))
      );
    }
    function ml(e, t, n) {
      switch (t.tag) {
        case 3:
          (Ne(t, t.stateNode.containerInfo),
            Sa(t, Fa, e.memoizedState.cache),
            ga());
          break;
        case 27:
        case 5:
          Fe(t);
          break;
        case 4:
          Ne(t, t.stateNode.containerInfo);
          break;
        case 10:
          Sa(t, t.type, t.memoizedProps.value);
          break;
        case 31:
          if (t.memoizedState !== null) return ((t.flags |= 128), Ro(t), null);
          break;
        case 13:
          var r = t.memoizedState;
          if (r !== null) {
            if (r.dehydrated !== null) return (Lo(t), (t.flags |= 128), null);
            r = Ea(e, t, n, !1);
            var i = t.child.childLanes;
            return r || (n & i) !== 0
              ? tl(e, t, n)
              : (Lo(t), (e = fl(e, t, n)), e === null ? null : e.sibling);
          }
          Lo(t);
          break;
        case 19:
          if (t.flags & 128) return ul(e, t, n);
          if (
            ((i = !!(e.flags & 128)),
            (r = (n & t.childLanes) !== 0),
            (r ||= (Ea(e, t, n, !1), (n & t.childLanes) !== 0)),
            i)
          ) {
            if (r) return ul(e, t, n);
            t.flags |= 128;
          }
          if (
            ((i = t.memoizedState),
            i !== null &&
              ((i.rendering = null), (i.tail = null), (i.lastEffect = null)),
            Uo(t, Ho.current),
            r)
          )
            break;
          return null;
        case 22:
          return ((t.lanes = 0), Vc(e, t, n, t.pendingProps));
        case 24:
          Sa(t, Fa, e.memoizedState.cache);
      }
      return fl(e, t, n);
    }
    function hl(e, t, n) {
      if (e !== null) {
        if (e.memoizedProps !== t.pendingProps) Ic = !0;
        else {
          if (!pl(e, n) && !(t.flags & 128)) return ((Ic = !1), ml(e, t, n));
          Ic = !!(e.flags & 131072);
        }
      } else ((Ic = !1), I && t.flags & 1048576 && ia(t, Zi, t.index));
      switch (((t.lanes = 0), t.tag)) {
        case 16:
          a: {
            var r = t.pendingProps;
            if (((e = ao(t.elementType)), (t.type = e), typeof e == `function`))
              Ri(e)
                ? ((r = Tc(e, r)), (t.tag = 1), (t = Xc(null, t, e, r, n)))
                : ((t.tag = 0), (t = Jc(null, t, e, r, n)));
            else {
              if (e != null) {
                var a = e.$$typeof;
                if (a === le) {
                  ((t.tag = 11), (t = Rc(null, t, e, r, n)));
                  break a;
                }
                if (a === fe) {
                  ((t.tag = 14), (t = zc(null, t, e, r, n)));
                  break a;
                }
                if (a === E) {
                  ((t.tag = 10), (t.type = e), (t = dl(null, t, n)));
                  break a;
                }
              }
              throw ((t = Se(e) || e), Error(i(306, t, ``)));
            }
          }
          return t;
        case 0:
          return Jc(e, t, t.type, t.pendingProps, n);
        case 1:
          return ((r = t.type), (a = Tc(r, t.pendingProps)), Xc(e, t, r, a, n));
        case 3:
          a: {
            if ((Ne(t, t.stateNode.containerInfo), e === null))
              throw Error(i(387));
            r = t.pendingProps;
            var o = t.memoizedState;
            ((a = o.element), bo(e, t), Do(t, r, null, n));
            var s = t.memoizedState;
            if (
              ((r = s.cache),
              Sa(t, Fa, r),
              r !== o.cache && Ta(t, [Fa], n, !0),
              Eo(),
              (r = s.element),
              o.isDehydrated)
            ) {
              if (
                ((o = {
                  element: r,
                  isDehydrated: !1,
                  cache: s.cache,
                }),
                (t.updateQueue.baseState = o),
                (t.memoizedState = o),
                t.flags & 256)
              ) {
                t = Zc(e, t, r, n);
                break a;
              }
              if (r !== a) {
                ((a = qi(Error(i(424)), t)), va(a), (t = Zc(e, t, r, n)));
                break a;
              }
              switch (((e = t.stateNode.containerInfo), e.nodeType)) {
                case 9:
                  e = e.body;
                  break;
                default:
                  e = e.nodeName === `HTML` ? e.ownerDocument.body : e;
              }
              for (
                F = lm(e.firstChild),
                  ca = t,
                  I = !0,
                  la = null,
                  ua = !0,
                  n = _o(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 134221824), (n = n.sibling));
            } else {
              if ((ga(), r === a)) {
                t = fl(e, t, n);
                break a;
              }
              Lc(e, t, r, n);
            }
            t = t.child;
          }
          return t;
        case 26:
          return (
            qc(e, t),
            e === null
              ? (n = Nm(t.type, null, t.pendingProps, null))
                ? (t.memoizedState = n)
                : I || (t.stateNode = fp(t.type, t.pendingProps, je.current, t))
              : (t.memoizedState = Nm(
                  t.type,
                  e.memoizedProps,
                  t.pendingProps,
                  e.memoizedState,
                )),
            null
          );
        case 27:
          return (
            Fe(t),
            e === null &&
              I &&
              ((r = t.stateNode = hm(t.type, t.pendingProps, je.current)),
              (ca = t),
              (ua = !0),
              (a = F),
              Sp(t.type) ? ((um = a), (F = lm(r.firstChild))) : (F = a)),
            Lc(e, t, t.pendingProps.children, n),
            qc(e, t),
            e === null && (t.flags |= 4194304),
            t.child
          );
        case 5:
          return (
            e === null &&
              I &&
              ((a = r = F) &&
                ((r = rm(r, t.type, t.pendingProps, ua)),
                r === null
                  ? (a = !1)
                  : ((t.stateNode = r),
                    (ca = t),
                    (F = lm(r.firstChild)),
                    (ua = !1),
                    (a = !0))),
              a || fa(t)),
            Fe(t),
            (a = t.type),
            (o = t.pendingProps),
            (s = e === null ? null : e.memoizedProps),
            (r = o.children),
            pp(a, o) ? (r = null) : s !== null && pp(a, s) && (t.flags |= 32),
            t.memoizedState !== null &&
              ((a = ns(e, t, as, null, null, n)), (sh._currentValue = a)),
            qc(e, t),
            Lc(e, t, r, n),
            t.child
          );
        case 6:
          return (
            e === null &&
              I &&
              ((e = n = F) &&
                ((n = im(n, t.pendingProps, ua)),
                n === null
                  ? (e = !1)
                  : ((t.stateNode = n), (ca = t), (F = null), (e = !0))),
              e || fa(t)),
            null
          );
        case 13:
          return tl(e, t, n);
        case 4:
          return (
            Ne(t, t.stateNode.containerInfo),
            (r = t.pendingProps),
            e === null ? (t.child = go(t, null, r, n)) : Lc(e, t, r, n),
            t.child
          );
        case 11:
          return Rc(e, t, t.type, t.pendingProps, n);
        case 7:
          return ((r = t.pendingProps), qc(e, t), Lc(e, t, r, n), t.child);
        case 8:
          return (Lc(e, t, t.pendingProps.children, n), t.child);
        case 12:
          return (Lc(e, t, t.pendingProps.children, n), t.child);
        case 10:
          return dl(e, t, n);
        case 9:
          return (
            (a = t.type._context),
            (r = t.pendingProps.children),
            Oa(t),
            (a = ka(a)),
            (r = r(a)),
            (t.flags |= 1),
            Lc(e, t, r, n),
            t.child
          );
        case 14:
          return zc(e, t, t.type, t.pendingProps, n);
        case 15:
          return Bc(e, t, t.type, t.pendingProps, n);
        case 19:
          return ul(e, t, n);
        case 31:
          return Kc(e, t, n);
        case 22:
          return Vc(e, t, n, t.pendingProps);
        case 24:
          return (
            Oa(t),
            (r = ka(Fa)),
            e === null
              ? ((a = Xa()),
                a === null &&
                  ((a = G),
                  (o = Ia()),
                  (a.pooledCache = o),
                  o.refCount++,
                  o !== null && (a.pooledCacheLanes |= n),
                  (a = o)),
                (t.memoizedState = {
                  parent: r,
                  cache: a,
                }),
                yo(t),
                Sa(t, Fa, a))
              : ((e.lanes & n) !== 0 && (bo(e, t), Do(t, null, null, n), Eo()),
                (a = e.memoizedState),
                (o = t.memoizedState),
                a.parent === r
                  ? ((r = o.cache),
                    Sa(t, Fa, r),
                    r !== a.cache && Ta(t, [Fa], n, !0))
                  : ((a = {
                      parent: r,
                      cache: r,
                    }),
                    (t.memoizedState = a),
                    t.lanes === 0 &&
                      (t.memoizedState = t.updateQueue.baseState = a),
                    Sa(t, Fa, r))),
            Lc(e, t, t.pendingProps.children, n),
            t.child
          );
        case 30:
          return (
            t.stateNode === null &&
              (t.stateNode = {
                autoName: null,
                paired: null,
                clones: null,
                ref: null,
              }),
            (r = t.pendingProps),
            r.name != null && r.name !== `auto`
              ? (t.flags |= e === null ? 18882560 : 18874368)
              : I && aa(t),
            e !== null && e.memoizedProps.name !== r.name
              ? (t.flags |= 4194816)
              : qc(e, t),
            Lc(e, t, r.children, n),
            t.child
          );
        case 29:
          throw t.pendingProps;
      }
      throw Error(i(156, t.tag));
    }
    function gl(e) {
      e.flags |= 4;
    }
    function _l(e, t, n, r, i) {
      var a;
      if (
        ((a = !!(e.mode & 32)) &&
          (a =
            n === null
              ? Jm(t, r)
              : Jm(t, r) && (r.src !== n.src || r.srcSet !== n.srcSet)),
        a)
      ) {
        if (((e.flags |= 16777216), (i & 335544128) === i)) {
          if (e.stateNode.complete) e.flags |= 8192;
          else if (Ud()) e.flags |= 8192;
          else throw ((oo = no), eo);
        }
      } else e.flags &= -16777217;
    }
    function vl(e, t) {
      if (t.type !== `stylesheet` || t.state.loading & 4) e.flags &= -16777217;
      else if (((e.flags |= 16777216), !Ym(t))) {
        if (Ud()) e.flags |= 8192;
        else throw ((oo = no), eo);
      }
    }
    function yl(e, t) {
      (t !== null && (e.flags |= 4),
        e.flags & 16384 &&
          ((t = e.tag === 22 ? 536870912 : yt()), (e.lanes |= t), (dd |= t)));
    }
    function bl(e, t) {
      if (!I)
        switch (e.tailMode) {
          case `visible`:
            break;
          case `collapsed`:
            for (var n = e.tail, r = null; n !== null;)
              (n.alternate !== null && (r = n), (n = n.sibling));
            r === null
              ? t || e.tail === null
                ? (e.tail = null)
                : (e.tail.sibling = null)
              : (r.sibling = null);
            break;
          default:
            for (t = e.tail, n = null; t !== null;)
              (t.alternate !== null && (n = t), (t = t.sibling));
            n === null ? (e.tail = null) : (n.sibling = null);
        }
    }
    function V(e) {
      var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
      if (t)
        for (var i = e.child; i !== null;)
          ((n |= i.lanes | i.childLanes),
            (r |= i.subtreeFlags & 1206910976),
            (r |= i.flags & 1206910976),
            (i.return = e),
            (i = i.sibling));
      else
        for (i = e.child; i !== null;)
          ((n |= i.lanes | i.childLanes),
            (r |= i.subtreeFlags),
            (r |= i.flags),
            (i.return = e),
            (i = i.sibling));
      return ((e.subtreeFlags |= r), (e.childLanes = n), t);
    }
    function xl(e, t, n) {
      var r = t.pendingProps;
      switch ((oa(t), t.tag)) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return (V(t), null);
        case 1:
          return (V(t), null);
        case 3:
          return (
            (n = t.stateNode),
            (r = null),
            e !== null && (r = e.memoizedState.cache),
            t.memoizedState.cache !== r && (t.flags |= 2048),
            Ca(Fa),
            Pe(),
            n.pendingContext &&
              ((n.context = n.pendingContext), (n.pendingContext = null)),
            (e === null || e.child === null) &&
              (ha(t)
                ? gl(t)
                : e === null ||
                  (e.memoizedState.isDehydrated && !(t.flags & 256)) ||
                  ((t.flags |= 1024), _a())),
            V(t),
            null
          );
        case 26:
          var a = t.type,
            o = t.memoizedState;
          return (
            e === null
              ? (gl(t),
                o === null ? (V(t), _l(t, a, null, r, n)) : (V(t), vl(t, o)))
              : o
                ? o === e.memoizedState
                  ? (V(t), (t.flags &= -16777217))
                  : (gl(t), V(t), vl(t, o))
                : ((e = e.memoizedProps),
                  e !== r && gl(t),
                  V(t),
                  _l(t, a, e, r, n)),
            null
          );
        case 27:
          if (
            (Ie(t),
            (n = je.current),
            (a = t.type),
            e !== null && t.stateNode != null)
          )
            e.memoizedProps !== r && gl(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return (V(t), (t.subtreeFlags &= -33554433), null);
            }
            ((e = ke.current),
              ha(t) ? pa(t, e) : ((e = hm(a, r, n)), (t.stateNode = e), gl(t)));
          }
          return (V(t), (t.subtreeFlags &= -33554433), null);
        case 5:
          if ((Ie(t), (a = t.type), e !== null && t.stateNode != null))
            e.memoizedProps !== r && gl(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return (V(t), (t.subtreeFlags &= -33554433), null);
            }
            if (((o = ke.current), ha(t))) pa(t, o);
            else {
              var s = lp(je.current);
              switch (o) {
                case 1:
                  o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                  break;
                case 2:
                  o = s.createElementNS(
                    `http://www.w3.org/1998/Math/MathML`,
                    a,
                  );
                  break;
                default:
                  switch (a) {
                    case `svg`:
                      o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                      break;
                    case `math`:
                      o = s.createElementNS(
                        `http://www.w3.org/1998/Math/MathML`,
                        a,
                      );
                      break;
                    case `script`:
                      ((o = s.createElement(`div`)),
                        (o.innerHTML = `<script><\/script>`),
                        (o = o.removeChild(o.firstChild)));
                      break;
                    case `select`:
                      ((o =
                        typeof r.is == `string`
                          ? s.createElement(`select`, {
                              is: r.is,
                            })
                          : s.createElement(`select`)),
                        r.multiple
                          ? (o.multiple = !0)
                          : r.size && (o.size = r.size));
                      break;
                    default:
                      o =
                        typeof r.is == `string`
                          ? s.createElement(a, {
                              is: r.is,
                            })
                          : s.createElement(a);
                  }
              }
              ((o[jt] = t), (o[Mt] = r));
              a: for (s = t.child; s !== null;) {
                if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
                else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
                  ((s.child.return = s), (s = s.child));
                  continue;
                }
                if (s === t) break a;
                for (; s.sibling === null;) {
                  if (s.return === null || s.return === t) break a;
                  s = s.return;
                }
                ((s.sibling.return = s.return), (s = s.sibling));
              }
              t.stateNode = o;
              a: switch ((np(o, a, r), a)) {
                case `button`:
                case `input`:
                case `select`:
                case `textarea`:
                  r = !!r.autoFocus;
                  break a;
                case `img`:
                  r = !0;
                  break a;
                default:
                  r = !1;
              }
              r && gl(t);
            }
          }
          return (
            V(t),
            (t.subtreeFlags &= -33554433),
            _l(
              t,
              t.type,
              e === null ? null : e.memoizedProps,
              t.pendingProps,
              n,
            ),
            null
          );
        case 6:
          if (e && t.stateNode != null) e.memoizedProps !== r && gl(t);
          else {
            if (typeof r != `string` && t.stateNode === null)
              throw Error(i(166));
            if (((e = je.current), ha(t))) {
              if (
                ((e = t.stateNode),
                (n = t.memoizedProps),
                (r = null),
                (a = ca),
                a !== null)
              )
                switch (a.tag) {
                  case 27:
                  case 5:
                    r = a.memoizedProps;
                }
              ((e[jt] = t),
                (e = !!(
                  e.nodeValue === n ||
                  (r !== null && !0 === r.suppressHydrationWarning) ||
                  ep(e.nodeValue, n)
                )),
                e || fa(t, !0));
            } else
              ((e = lp(e).createTextNode(r)), (e[jt] = t), (t.stateNode = e));
          }
          return (V(t), null);
        case 31:
          if (((n = t.memoizedState), e === null || e.memoizedState !== null)) {
            if (((r = ha(t)), n !== null)) {
              if (e === null) {
                if (!r) throw Error(i(318));
                if (
                  ((e = t.memoizedState),
                  (e = e === null ? null : e.dehydrated),
                  !e)
                )
                  throw Error(i(557));
                e[jt] = t;
              } else
                (ga(),
                  !(t.flags & 128) && (t.memoizedState = null),
                  (t.flags |= 4));
              (V(t), (e = !1));
            } else
              ((n = _a()),
                e !== null &&
                  e.memoizedState !== null &&
                  (e.memoizedState.hydrationErrors = n),
                (e = !0));
            if (!e) return t.flags & 256 ? (Vo(t), t) : (Vo(t), null);
            if (t.flags & 128) throw Error(i(558));
          }
          return (V(t), null);
        case 13:
          if (
            ((r = t.memoizedState),
            e === null ||
              (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
          ) {
            if (((a = ha(t)), r !== null && r.dehydrated !== null)) {
              if (e === null) {
                if (!a) throw Error(i(318));
                if (
                  ((a = t.memoizedState),
                  (a = a === null ? null : a.dehydrated),
                  !a)
                )
                  throw Error(i(317));
                a[jt] = t;
              } else
                (ga(),
                  !(t.flags & 128) && (t.memoizedState = null),
                  (t.flags |= 4));
              (V(t), (a = !1));
            } else
              ((a = _a()),
                e !== null &&
                  e.memoizedState !== null &&
                  (e.memoizedState.hydrationErrors = a),
                (a = !0));
            if (!a) return t.flags & 256 ? (Vo(t), t) : (Vo(t), null);
          }
          return (
            Vo(t),
            t.flags & 128
              ? ((t.lanes = n), t)
              : ((n = r !== null),
                (e = e !== null && e.memoizedState !== null),
                n &&
                  ((r = t.child),
                  (a = null),
                  r.alternate !== null &&
                    r.alternate.memoizedState !== null &&
                    r.alternate.memoizedState.cachePool !== null &&
                    (a = r.alternate.memoizedState.cachePool.pool),
                  (o = null),
                  r.memoizedState !== null &&
                    r.memoizedState.cachePool !== null &&
                    (o = r.memoizedState.cachePool.pool),
                  o !== a && (r.flags |= 2048)),
                n !== e && n && (t.child.flags |= 8192),
                yl(t, t.updateQueue),
                V(t),
                null)
          );
        case 4:
          return (
            Pe(),
            e === null && Wf(t.stateNode.containerInfo),
            (t.flags |= 67108864),
            V(t),
            null
          );
        case 10:
          return (Ca(t.type), V(t), null);
        case 19:
          if ((Wo(t), (r = t.memoizedState), r === null)) return (V(t), null);
          if (((a = !!(t.flags & 128)), (o = r.rendering), o === null)) {
            if (a) bl(r, !1);
            else {
              if (Y !== 0 || (e !== null && e.flags & 128))
                for (e = t.child; e !== null;) {
                  if (((o = Go(e)), o !== null)) {
                    for (
                      t.flags |= 128,
                        bl(r, !1),
                        e = o.updateQueue,
                        t.updateQueue = e,
                        yl(t, e),
                        t.subtreeFlags = 0,
                        e = n,
                        n = t.child;
                      n !== null;
                    )
                      (Bi(n, e), (n = n.sibling));
                    return (
                      Uo(t, (Ho.current & 1) | 2),
                      I && ra(t, r.treeForkCount),
                      t.child
                    );
                  }
                  e = e.sibling;
                }
              r.tail !== null &&
                Ye() > _d &&
                ((t.flags |= 128), (a = !0), bl(r, !1), (t.lanes = 4194304));
            }
          } else {
            if (!a) {
              if (((e = Go(o)), e !== null)) {
                if (
                  ((t.flags |= 128),
                  (a = !0),
                  (e = e.updateQueue),
                  (t.updateQueue = e),
                  yl(t, e),
                  bl(r, !0),
                  r.tail === null &&
                    r.tailMode !== `collapsed` &&
                    r.tailMode !== `visible` &&
                    !o.alternate &&
                    !I)
                )
                  return (V(t), null);
              } else
                2 * Ye() - r.renderingStartTime > _d &&
                  n !== 536870912 &&
                  ((t.flags |= 128), (a = !0), bl(r, !1), (t.lanes = 4194304));
            }
            r.isBackwards
              ? ((o.sibling = t.child), (t.child = o))
              : ((e = r.last),
                e === null ? (t.child = o) : (e.sibling = o),
                (r.last = o));
          }
          if (r.tail !== null) {
            e = r.tail;
            a: {
              for (n = e; n !== null;) {
                if (n.alternate !== null) {
                  n = !1;
                  break a;
                }
                n = n.sibling;
              }
              n = !0;
            }
            return (
              (r.rendering = e),
              (r.tail = e.sibling),
              (r.renderingStartTime = Ye()),
              (e.sibling = null),
              (o = Ho.current),
              (o = a ? (o & 1) | 2 : o & 1),
              r.tailMode === `visible` || r.tailMode === `collapsed` || !n || I
                ? Uo(t, o)
                : ((n = o), k(Fo, t), k(Ho, n), Io === null && (Io = t)),
              I && ra(t, r.treeForkCount),
              e
            );
          }
          return (V(t), null);
        case 22:
        case 23:
          return (
            Vo(t),
            Po(),
            (r = t.memoizedState !== null),
            e === null
              ? r && (t.flags |= 8192)
              : (e.memoizedState !== null) !== r && (t.flags |= 8192),
            r
              ? n & 536870912 &&
                !(t.flags & 128) &&
                (V(t), t.subtreeFlags & 6 && (t.flags |= 8192))
              : V(t),
            (n = t.updateQueue),
            n !== null && yl(t, n.retryQueue),
            (n = null),
            e !== null &&
              e.memoizedState !== null &&
              e.memoizedState.cachePool !== null &&
              (n = e.memoizedState.cachePool.pool),
            (r = null),
            t.memoizedState !== null &&
              t.memoizedState.cachePool !== null &&
              (r = t.memoizedState.cachePool.pool),
            r !== n && (t.flags |= 2048),
            e !== null && Oe(Ya),
            null
          );
        case 24:
          return (
            (n = null),
            e !== null && (n = e.memoizedState.cache),
            t.memoizedState.cache !== n && (t.flags |= 2048),
            Ca(Fa),
            V(t),
            null
          );
        case 25:
          return null;
        case 30:
          return ((t.flags |= 33554432), V(t), null);
      }
      throw Error(i(156, t.tag));
    }
    function Sl(e, t) {
      switch ((oa(t), t.tag)) {
        case 1:
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 3:
          return (
            Ca(Fa),
            Pe(),
            (e = t.flags),
            e & 65536 && !(e & 128) ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 26:
        case 27:
        case 5:
          return (Ie(t), null);
        case 31:
          if (t.memoizedState !== null) {
            if ((Vo(t), t.alternate === null)) throw Error(i(340));
            ga();
          }
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 13:
          if (
            (Vo(t), (e = t.memoizedState), e !== null && e.dehydrated !== null)
          ) {
            if (t.alternate === null) throw Error(i(340));
            ga();
          }
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 19:
          return (
            Wo(t),
            (e = t.flags),
            e & 65536
              ? ((t.flags = (e & -65537) | 128),
                (e = t.memoizedState),
                e !== null && ((e.rendering = null), (e.tail = null)),
                (t.flags |= 4),
                t)
              : null
          );
        case 4:
          return (Pe(), null);
        case 10:
          return (Ca(t.type), null);
        case 22:
        case 23:
          return (
            Vo(t),
            Po(),
            e !== null && Oe(Ya),
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 24:
          return (Ca(Fa), null);
        case 25:
          return null;
        default:
          return null;
      }
    }
    function Cl(e, t) {
      switch ((oa(t), t.tag)) {
        case 3:
          (Ca(Fa), Pe());
          break;
        case 26:
        case 27:
        case 5:
          Ie(t);
          break;
        case 4:
          Pe();
          break;
        case 31:
          t.memoizedState !== null && Vo(t);
          break;
        case 13:
          Vo(t);
          break;
        case 19:
          Wo(t);
          break;
        case 10:
          Ca(t.type);
          break;
        case 22:
        case 23:
          (Vo(t), Po(), e !== null && Oe(Ya));
          break;
        case 24:
          Ca(Fa);
      }
    }
    function wl(e, t) {
      try {
        var n = t.updateQueue,
          r = n === null ? null : n.lastEffect;
        if (r !== null) {
          var i = r.next;
          n = i;
          do {
            if ((n.tag & e) === e) {
              r = void 0;
              var a = n.create,
                o = n.inst;
              ((r = a()), (o.destroy = r));
            }
            n = n.next;
          } while (n !== i);
        }
      } catch (e) {
        Z(t, t.return, e);
      }
    }
    function Tl(e, t, n) {
      try {
        var r = t.updateQueue,
          i = r === null ? null : r.lastEffect;
        if (i !== null) {
          var a = i.next;
          r = a;
          do {
            if ((r.tag & e) === e) {
              var o = r.inst,
                s = o.destroy;
              if (s !== void 0) {
                ((o.destroy = void 0), (i = t));
                var c = n,
                  l = s;
                try {
                  l();
                } catch (e) {
                  Z(i, c, e);
                }
              }
            }
            r = r.next;
          } while (r !== a);
        }
      } catch (e) {
        Z(t, t.return, e);
      }
    }
    function El(e) {
      var t = e.updateQueue;
      if (t !== null) {
        var n = e.stateNode;
        try {
          ko(t, n);
        } catch (t) {
          Z(e, e.return, t);
        }
      }
    }
    function Dl(e, t, n) {
      ((n.props = Tc(e.type, e.memoizedProps)), (n.state = e.memoizedState));
      try {
        n.componentWillUnmount();
      } catch (n) {
        Z(e, t, n);
      }
    }
    function Ol(e, t) {
      try {
        var n = e.ref;
        if (n !== null) {
          switch (e.tag) {
            case 26:
            case 27:
            case 5:
              var r = e.stateNode;
              break;
            case 30:
              var i = e.stateNode,
                a = Si(e.memoizedProps, i);
              ((i.ref === null || i.ref.name !== a) && (i.ref = Pp(a)),
                (r = i.ref));
              break;
            case 7:
              if (e.stateNode === null) {
                var o = new Fp(e);
                (h(e.child, !1, Qp, o, void 0, void 0), (e.stateNode = o));
              }
              r = e.stateNode;
              break;
            default:
              r = e.stateNode;
          }
          typeof n == `function` ? (e.refCleanup = n(r)) : (n.current = r);
        }
      } catch (n) {
        Z(e, t, n);
      }
    }
    function kl(e, t) {
      var n = e.ref,
        r = e.refCleanup;
      if (n !== null) {
        if (typeof r == `function`)
          try {
            r();
          } catch (n) {
            Z(e, t, n);
          } finally {
            ((e.refCleanup = null),
              (e = e.alternate),
              e != null && (e.refCleanup = null));
          }
        else if (typeof n == `function`)
          try {
            n(null);
          } catch (n) {
            Z(e, t, n);
          }
        else n.current = null;
      }
    }
    function Al(e, t) {
      if (
        (e.tag === 5 || e.tag === 27 || e.tag === 6) &&
        e.alternate === null &&
        t !== null
      )
        for (var n = 0; n < t.length; n++) em(e.stateNode, t[n]);
    }
    function jl(e) {
      for (
        var t = e.return;
        t !== null && (Pl(t) && em(e.stateNode, t.stateNode), !Nl(t));
      )
        t = t.return;
    }
    function Ml(e) {
      for (
        var t = e.return;
        t !== null && (Pl(t) && tm(e.stateNode, t.stateNode), !Nl(t));
      )
        t = t.return;
    }
    function Nl(e) {
      return e.tag === 5 || e.tag === 3 || e.tag === 27;
    }
    function Pl(e) {
      return e && e.tag === 7 && e.stateNode !== null;
    }
    function Fl(e) {
      var t = e.type,
        n = e.memoizedProps,
        r = e.stateNode;
      try {
        a: switch (t) {
          case `button`:
          case `input`:
          case `select`:
          case `textarea`:
            n.autoFocus && r.focus();
            break a;
          case `img`:
            n.src ? (r.src = n.src) : n.srcSet && (r.srcset = n.srcSet);
        }
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    function Il(e, t, n) {
      try {
        var r = e.stateNode;
        (ip(r, e.type, n, t), (r[Mt] = t));
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    function Ll(e) {
      return (
        e.tag === 5 ||
        e.tag === 3 ||
        e.tag === 26 ||
        (e.tag === 27 && Sp(e.type)) ||
        e.tag === 4
      );
    }
    function Rl(e) {
      a: for (;;) {
        for (; e.sibling === null;) {
          if (e.return === null || Ll(e.return)) return null;
          e = e.return;
        }
        for (
          e.sibling.return = e.return, e = e.sibling;
          e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
        ) {
          if (
            (e.tag === 27 && Sp(e.type)) ||
            e.flags & 2 ||
            e.child === null ||
            e.tag === 4
          )
            continue a;
          ((e.child.return = e), (e = e.child));
        }
        if (!(e.flags & 2)) return e.stateNode;
      }
    }
    function zl(e, t, n, r) {
      var i = e.tag;
      if (i === 5 || i === 6)
        ((i = e.stateNode),
          t
            ? (n.nodeType === 9
                ? n.body
                : n.nodeName === `HTML`
                  ? n.ownerDocument.body
                  : n
              ).insertBefore(i, t)
            : ((t =
                n.nodeType === 9
                  ? n.body
                  : n.nodeName === `HTML`
                    ? n.ownerDocument.body
                    : n),
              t.appendChild(i),
              (n = n._reactRootContainer),
              n != null || t.onclick !== null || (t.onclick = Dn)),
          Al(e, r),
          (A = !0));
      else if (
        i !== 4 &&
        (i === 27 &&
          (Al(e, r), (r = null), Sp(e.type) && ((n = e.stateNode), (t = null))),
        (e = e.child),
        e !== null)
      )
        for (zl(e, t, n, r), e = e.sibling; e !== null;)
          (zl(e, t, n, r), (e = e.sibling));
    }
    function Bl(e, t, n, r) {
      var i = e.tag;
      if (i === 5 || i === 6)
        ((i = e.stateNode),
          t ? n.insertBefore(i, t) : n.appendChild(i),
          Al(e, r),
          (A = !0));
      else if (
        i !== 4 &&
        (i === 27 && (Al(e, r), (r = null), Sp(e.type) && (n = e.stateNode)),
        (e = e.child),
        e !== null)
      )
        for (Bl(e, t, n, r), e = e.sibling; e !== null;)
          (Bl(e, t, n, r), (e = e.sibling));
    }
    function Vl(e) {
      var t = e.stateNode,
        n = e.memoizedProps;
      try {
        for (var r = e.type, i = t.attributes; i.length;)
          t.removeAttributeNode(i[0]);
        (np(t, r, n), (t[jt] = e), (t[Mt] = n));
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    var Hl = !1,
      Ul = null;
    function Wl(e) {
      (e.tag === 30 || e.subtreeFlags & 33554432) && (Hl = !0);
    }
    var Gl = null;
    function Kl() {
      var e = Gl;
      return ((Gl = null), e);
    }
    var ql = 0;
    function Jl(e, t, n, r, i) {
      return ((ql = 0), Yl(e.child, t, n, r, i));
    }
    function Yl(e, t, n, r, i) {
      for (var a = !1; e !== null;) {
        if (e.tag === 5) {
          var o = e.stateNode;
          if (r !== null) {
            var s = Op(o);
            (r.push(s), s.view && (a = !0));
          } else a || (Op(o).view && (a = !0));
          ((Hl = !0), Tp(o, ql === 0 ? t : t + `_` + ql, n), ql++);
        } else
          (e.tag !== 22 || e.memoizedState === null) &&
            ((e.tag === 30 && i) || (Yl(e.child, t, n, r, i) && (a = !0)));
        e = e.sibling;
      }
      return a;
    }
    function Xl(e, t) {
      for (; e !== null;)
        (e.tag === 5
          ? Ep(e.stateNode, e.memoizedProps)
          : (e.tag !== 22 || e.memoizedState === null) &&
            ((e.tag === 30 && t) || Xl(e.child, t)),
          (e = e.sibling));
    }
    function Zl(e) {
      if (e.subtreeFlags & 18874368)
        for (e = e.child; e !== null;) {
          if (
            (e.tag !== 22 || e.memoizedState === null) &&
            (Zl(e), e.tag === 30 && e.flags & 18874368 && e.stateNode.paired)
          ) {
            var t = e.memoizedProps;
            if (t.name == null || t.name === `auto`) throw Error(i(544));
            var n = t.name;
            ((t = wi(t.default, t.share)),
              t !== `none` && (Jl(e, n, t, null, !1) || Xl(e.child, !1)));
          }
          e = e.sibling;
        }
    }
    function Ql(e, t) {
      if (e.tag === 30) {
        var n = e.stateNode,
          r = e.memoizedProps,
          i = Si(r, n),
          a = wi(r.default, n.paired ? r.share : r.enter);
        a === `none`
          ? Zl(e)
          : Jl(e, i, a, null, !1)
            ? (Zl(e), n.paired || t || Nd(e, r.onEnter))
            : Xl(e.child, !1);
      } else if (e.subtreeFlags & 33554432)
        for (e = e.child; e !== null;) (Ql(e, t), (e = e.sibling));
      else Zl(e);
    }
    function $l(e) {
      if (Ul !== null && Ul.size !== 0) {
        var t = Ul;
        if (e.subtreeFlags & 18874368)
          for (e = e.child; e !== null;) {
            if (e.tag !== 22 || e.memoizedState === null) {
              if (e.tag === 30 && e.flags & 18874368) {
                var n = e.memoizedProps,
                  r = n.name;
                if (r != null && r !== `auto`) {
                  var i = t.get(r);
                  if (i !== void 0) {
                    var a = wi(n.default, n.share);
                    if (
                      (a !== `none` &&
                        (Jl(e, r, a, null, !1)
                          ? ((a = e.stateNode),
                            (i.paired = a),
                            (a.paired = i),
                            Nd(e, n.onShare))
                          : Xl(e.child, !1)),
                      t.delete(r),
                      t.size === 0)
                    )
                      break;
                  }
                }
              }
              $l(e);
            }
            e = e.sibling;
          }
      }
    }
    function eu(e) {
      if (e.tag === 30) {
        var t = e.memoizedProps,
          n = Si(t, e.stateNode),
          r = Ul === null ? void 0 : Ul.get(n),
          i = wi(t.default, r === void 0 ? t.exit : t.share);
        (i !== `none` &&
          (Jl(e, n, i, null, !1)
            ? r === void 0
              ? Nd(e, t.onExit)
              : ((i = e.stateNode),
                (r.paired = i),
                (i.paired = r),
                Ul.delete(n),
                Nd(e, t.onShare))
            : Xl(e.child, !1)),
          Ul !== null && $l(e));
      } else if (e.subtreeFlags & 33554432)
        for (e = e.child; e !== null;) (eu(e), (e = e.sibling));
      else Ul !== null && $l(e);
    }
    function tu(e) {
      for (e = e.child; e !== null;) {
        if (e.tag === 30) {
          var t = e.memoizedProps,
            n = Si(t, e.stateNode);
          ((t = wi(t.default, t.update)),
            (e.flags &= -5),
            t !== `none` && Jl(e, n, t, (e.memoizedState = []), !1));
        } else e.subtreeFlags & 33554432 && tu(e);
        e = e.sibling;
      }
    }
    function nu(e) {
      if (e.subtreeFlags & 18874368)
        for (e = e.child; e !== null;) {
          if (e.tag !== 22 || e.memoizedState === null) {
            if (e.tag === 30 && e.flags & 18874368) {
              var t = e.stateNode;
              t.paired !== null && ((t.paired = null), Xl(e.child, !1));
            }
            nu(e);
          }
          e = e.sibling;
        }
    }
    function ru(e) {
      if (e.tag === 30) ((e.stateNode.paired = null), Xl(e.child, !1), nu(e));
      else if (e.subtreeFlags & 33554432)
        for (e = e.child; e !== null;) (ru(e), (e = e.sibling));
      else nu(e);
    }
    function iu(e) {
      for (e = e.child; e !== null;)
        (e.tag === 30 ? Xl(e.child, !1) : e.subtreeFlags & 33554432 && iu(e),
          (e = e.sibling));
    }
    function au(e, t, n, r, i, a, o) {
      for (var s = !1; t !== null;) {
        if (t.tag === 5) {
          var c = t.stateNode;
          if (a !== null && ql < a.length) {
            var l = a[ql],
              u = Op(c);
            (l.view || u.view) && (s = !0);
            var d;
            if ((d = !(e.flags & 4))) {
              if (u.clip) d = !0;
              else {
                d = l.rect;
                var f = u.rect;
                d =
                  d.y !== f.y ||
                  d.x !== f.x ||
                  d.height !== f.height ||
                  d.width !== f.width;
              }
            }
            (d && (e.flags |= 4),
              u.abs
                ? (u = !l.abs)
                : ((l = l.rect),
                  (u = u.rect),
                  (u = l.height !== u.height || l.width !== u.width)),
              u && (e.flags |= 32));
          } else e.flags |= 32;
          (e.flags & 4 && Tp(c, ql === 0 ? n : n + `_` + ql, i),
            (s && e.flags & 4) ||
              (Gl === null && (Gl = []),
              Gl.push(c, ql === 0 ? r : r + `_` + ql, t.memoizedProps)),
            ql++);
        } else
          (t.tag !== 22 || t.memoizedState === null) &&
            (t.tag === 30 && o
              ? (e.flags |= t.flags & 32)
              : au(e, t.child, n, r, i, a, o) && (s = !0));
        t = t.sibling;
      }
      return s;
    }
    function ou(e, t) {
      for (e = e.child; e !== null;) {
        if (e.tag === 30) {
          var n = e.memoizedProps,
            r = e.stateNode,
            i = Si(n, r),
            a = wi(n.default, n.update);
          if (t) {
            r = r.clones;
            var o = r === null ? null : r.map(kp);
          } else ((o = e.memoizedState), (e.memoizedState = null));
          r = e;
          var s = e.child;
          ((ql = 0),
            (i = au(r, s, i, i, a, o, !1)),
            e.flags & 4 && i && (t || Nd(e, n.onUpdate)));
        } else e.subtreeFlags & 33554432 && ou(e, t);
        e = e.sibling;
      }
    }
    var su = !1,
      H = !1,
      cu = !1,
      lu = !1,
      uu = typeof WeakSet == `function` ? WeakSet : Set,
      du = null,
      fu = !1,
      pu = !1,
      mu = !1,
      hu = !1;
    function gu(e, t, n) {
      if (((e = e.containerInfo), (sp = gh), (e = Qr(e)), $r(e))) {
        if (`selectionStart` in e)
          var r = {
            start: e.selectionStart,
            end: e.selectionEnd,
          };
        else
          a: {
            r = ((r = e.ownerDocument) && r.defaultView) || window;
            var i = r.getSelection && r.getSelection();
            if (i && i.rangeCount !== 0) {
              r = i.anchorNode;
              var a = i.anchorOffset,
                o = i.focusNode;
              i = i.focusOffset;
              try {
                (r.nodeType, o.nodeType);
              } catch {
                r = null;
                break a;
              }
              var s = 0,
                c = -1,
                l = -1,
                u = 0,
                d = 0,
                f = e,
                p = null;
              b: for (;;) {
                for (
                  var m;
                  f !== r || (a !== 0 && f.nodeType !== 3) || (c = s + a),
                    f !== o || (i !== 0 && f.nodeType !== 3) || (l = s + i),
                    f.nodeType === 3 && (s += f.nodeValue.length),
                    (m = f.firstChild) !== null;
                )
                  ((p = f), (f = m));
                for (;;) {
                  if (f === e) break b;
                  if (
                    (p === r && ++u === a && (c = s),
                    p === o && ++d === i && (l = s),
                    (m = f.nextSibling) !== null)
                  )
                    break;
                  ((f = p), (p = f.parentNode));
                }
                f = m;
              }
              r =
                c === -1 || l === -1
                  ? null
                  : {
                      start: c,
                      end: l,
                    };
            } else r = null;
          }
        r ||= {
          start: 0,
          end: 0,
        };
      } else r = null;
      for (
        cp = {
          focusedElem: e,
          selectionRange: r,
        },
          gh = !1,
          n = (n & 335544064) === n,
          du = t,
          t = n ? 9270 : 1024;
        du !== null;
      ) {
        if (((e = du), n && ((r = e.deletions), r !== null)))
          for (a = 0; a < r.length; a++) n && eu(r[a]);
        if (e.alternate === null && e.flags & 2) (n && Wl(e), _u(n));
        else {
          if (e.tag === 22) {
            if (((r = e.alternate), e.memoizedState !== null)) {
              (r !== null && r.memoizedState === null && n && eu(r), _u(n));
              continue;
            }
            if (r !== null && r.memoizedState !== null) {
              (n && Wl(e), _u(n));
              continue;
            }
          }
          ((r = e.child),
            (e.subtreeFlags & t) !== 0 && r !== null
              ? ((r.return = e), (du = r))
              : (n && tu(e), _u(n)));
        }
      }
      Ul = null;
    }
    function _u(e) {
      for (; du !== null;) {
        var t = du,
          n = e,
          r = t.alternate,
          a = t.flags;
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            break;
          case 1:
            if (a & 1024 && r !== null) {
              ((n = void 0), (a = r.memoizedProps), (r = r.memoizedState));
              var o = t.stateNode;
              try {
                var s = Tc(t.type, a);
                ((n = o.getSnapshotBeforeUpdate(s, r)),
                  (o.__reactInternalSnapshotBeforeUpdate = n));
              } catch (e) {
                Z(t, t.return, e);
              }
            }
            break;
          case 3:
            if (a & 1024) {
              if (((r = t.stateNode.containerInfo), (n = r.nodeType), n === 9))
                nm(r);
              else if (n === 1)
                switch (r.nodeName) {
                  case `HEAD`:
                  case `HTML`:
                  case `BODY`:
                    nm(r);
                    break;
                  default:
                    r.textContent = ``;
                }
            }
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          case 30:
            n &&
              r !== null &&
              ((n = Si(r.memoizedProps, r.stateNode)),
              (a = t.memoizedProps),
              (a = wi(a.default, a.update)),
              a !== `none` && Jl(r, n, a, (r.memoizedState = []), !0));
            break;
          default:
            if (a & 1024) throw Error(i(163));
        }
        if (((r = t.sibling), r !== null)) {
          ((r.return = t.return), (du = r));
          break;
        }
        du = t.return;
      }
    }
    function vu(e, t, n) {
      var r = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          (Lu(e, n), r & 4 && wl(5, n));
          break;
        case 1:
          if ((Lu(e, n), r & 4)) {
            if (((e = n.stateNode), t === null))
              try {
                e.componentDidMount();
              } catch (e) {
                Z(n, n.return, e);
              }
            else {
              var i = Tc(n.type, t.memoizedProps);
              t = t.memoizedState;
              try {
                e.componentDidUpdate(
                  i,
                  t,
                  e.__reactInternalSnapshotBeforeUpdate,
                );
              } catch (e) {
                Z(n, n.return, e);
              }
            }
          }
          (r & 64 && El(n), r & 512 && Ol(n, n.return));
          break;
        case 3:
          if ((Lu(e, n), r & 64 && ((e = n.updateQueue), e !== null))) {
            if (((t = null), n.child !== null))
              switch (n.child.tag) {
                case 27:
                case 5:
                  t = n.child.stateNode;
                  break;
                case 1:
                  t = n.child.stateNode;
              }
            try {
              ko(e, t);
            } catch (e) {
              Z(n, n.return, e);
            }
          }
          break;
        case 27:
          t === null && r & 4 && Vl(n);
        case 26:
        case 5:
          (Lu(e, n), t === null && r & 4 && Fl(n), r & 512 && Ol(n, n.return));
          break;
        case 12:
          Lu(e, n);
          break;
        case 31:
          (Lu(e, n), r & 4 && Eu(e, n));
          break;
        case 13:
          (Lu(e, n),
            r & 4 && Du(e, n),
            r & 64 &&
              ((e = n.memoizedState),
              e !== null &&
                ((e = e.dehydrated),
                e !== null && ((n = _f.bind(null, n)), cm(e, n)))));
          break;
        case 22:
          if (((r = n.memoizedState !== null || su), !r)) {
            var a = (t !== null && t.memoizedState !== null) || H;
            ((t = su),
              (i = H),
              (su = r),
              (H = a) && !i
                ? ((r = 2), n.subtreeFlags & 8772 && (r |= 1), zu(e, n, r))
                : Lu(e, n),
              (su = t),
              (H = i));
          }
          break;
        case 30:
          (Lu(e, n), r & 512 && Ol(n, n.return));
          break;
        case 7:
          r & 512 && Ol(n, n.return);
        default:
          Lu(e, n);
      }
    }
    function yu(e, t) {
      for (e = e.child; e !== null;) (bu(e, t), (e = e.sibling));
    }
    function bu(e, t) {
      switch (e.tag) {
        case 5:
        case 26:
          try {
            var n = e.stateNode;
            if (t) {
              var r = n.style;
              typeof r.setProperty == `function`
                ? r.setProperty(`display`, `none`, `important`)
                : (r.display = `none`);
            } else {
              var i = e.stateNode,
                a = e.memoizedProps.style,
                o = a != null && a.hasOwnProperty(`display`) ? a.display : null;
              i.style.display =
                o == null || typeof o == `boolean` ? `` : (`` + o).trim();
            }
          } catch (t) {
            Z(e, e.return, t);
          }
          xu(e, t);
          break;
        case 6:
          try {
            ((e.stateNode.nodeValue = t ? `` : e.memoizedProps), (A = !0));
          } catch (t) {
            Z(e, e.return, t);
          }
          break;
        case 18:
          try {
            var s = e.stateNode;
            t ? wp(s, !0) : wp(e.stateNode, !1);
          } catch (t) {
            Z(e, e.return, t);
          }
          break;
        case 22:
        case 23:
          e.memoizedState === null && yu(e, t);
          break;
        default:
          yu(e, t);
      }
    }
    function xu(e, t) {
      if (e.subtreeFlags & 67108864)
        for (e = e.child; e !== null;) {
          a: {
            var n = e,
              r = t;
            switch (n.tag) {
              case 4:
                bu(n, r);
                break a;
              case 22:
                n.memoizedState === null && xu(n, r);
                break a;
              default:
                xu(n, r);
            }
          }
          e = e.sibling;
        }
    }
    function Su(e) {
      var t = e.alternate;
      (t !== null && ((e.alternate = null), Su(t)),
        (e.child = null),
        (e.deletions = null),
        (e.sibling = null),
        e.tag === 5 && ((t = e.stateNode), t !== null && Bt(t)),
        (e.stateNode = null),
        (e.return = null),
        (e.dependencies = null),
        (e.memoizedProps = null),
        (e.memoizedState = null),
        (e.pendingProps = null),
        (e.stateNode = null),
        (e.updateQueue = null));
    }
    var U = null,
      Cu = !1;
    function wu(e, t, n) {
      for (n = n.child; n !== null;) (Tu(e, t, n), (n = n.sibling));
    }
    function Tu(e, t, n) {
      if (at && typeof at.onCommitFiberUnmount == `function`)
        try {
          at.onCommitFiberUnmount(it, n);
        } catch {}
      switch (n.tag) {
        case 26:
          (H || kl(n, t),
            wu(e, t, n),
            n.memoizedState
              ? n.memoizedState.count--
              : n.stateNode &&
                !H &&
                ((n = n.stateNode), n.parentNode.removeChild(n)));
          break;
        case 27:
          (H || kl(n, t), Ml(n));
          var r = U,
            i = Cu;
          (Sp(n.type) && ((U = n.stateNode), (Cu = !1)),
            wu(e, t, n),
            gm(n.stateNode, n.type, n.memoizedProps),
            (U = r),
            (Cu = i));
          break;
        case 5:
          (H || kl(n, t), Ml(n));
        case 6:
          if (
            (n.tag === 6 && Ml(n),
            (r = U),
            (i = Cu),
            (U = null),
            wu(e, t, n),
            (U = r),
            (Cu = i),
            U !== null)
          ) {
            if (Cu)
              try {
                ((U.nodeType === 9
                  ? U.body
                  : U.nodeName === `HTML`
                    ? U.ownerDocument.body
                    : U
                ).removeChild(n.stateNode),
                  (A = !0));
              } catch (e) {
                Z(n, t, e);
              }
            else
              try {
                (U.removeChild(n.stateNode), (A = !0));
              } catch (e) {
                Z(n, t, e);
              }
          }
          break;
        case 18:
          U !== null &&
            (Cu
              ? ((e = U),
                Cp(
                  e.nodeType === 9
                    ? e.body
                    : e.nodeName === `HTML`
                      ? e.ownerDocument.body
                      : e,
                  n.stateNode,
                ),
                Hh(e))
              : Cp(U, n.stateNode));
          break;
        case 4:
          ((r = U),
            (i = Cu),
            (U = n.stateNode.containerInfo),
            (Cu = !0),
            wu(e, t, n),
            (U = r),
            (Cu = i));
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          (Tl(2, n, t), H || Tl(4, n, t), wu(e, t, n));
          break;
        case 1:
          (H ||
            (kl(n, t),
            (r = n.stateNode),
            typeof r.componentWillUnmount == `function` && Dl(n, t, r)),
            wu(e, t, n));
          break;
        case 21:
          wu(e, t, n);
          break;
        case 22:
          ((H = (r = H) || n.memoizedState !== null), wu(e, t, n), (H = r));
          break;
        case 30:
          (kl(n, t), wu(e, t, n));
          break;
        case 7:
          (H || kl(n, t), wu(e, t, n));
          break;
        default:
          wu(e, t, n);
      }
    }
    function Eu(e, t) {
      if (
        t.memoizedState === null &&
        ((e = t.alternate), e !== null && ((e = e.memoizedState), e !== null))
      ) {
        e = e.dehydrated;
        try {
          Hh(e);
        } catch (e) {
          Z(t, t.return, e);
        }
      }
    }
    function Du(e, t) {
      if (
        t.memoizedState === null &&
        ((e = t.alternate),
        e !== null &&
          ((e = e.memoizedState),
          e !== null && ((e = e.dehydrated), e !== null)))
      )
        try {
          Hh(e);
        } catch (e) {
          Z(t, t.return, e);
        }
    }
    function Ou(e) {
      switch (e.tag) {
        case 31:
        case 13:
        case 19:
          var t = e.stateNode;
          return (t === null && (t = e.stateNode = new uu()), t);
        case 22:
          return (
            (e = e.stateNode),
            (t = e._retryCache),
            t === null && (t = e._retryCache = new uu()),
            t
          );
        default:
          throw Error(i(435, e.tag));
      }
    }
    function ku(e, t) {
      var n = Ou(e);
      t.forEach(function (t) {
        if (!n.has(t)) {
          n.add(t);
          var r = vf.bind(null, e, t);
          t.then(r, r);
        }
      });
    }
    function Au(e, t, n) {
      var r = t.deletions;
      if (r !== null)
        for (var a = 0; a < r.length; a++) {
          var o = r[a],
            s = e,
            c = t,
            l = c;
          a: for (; l !== null;) {
            switch (l.tag) {
              case 27:
                if (Sp(l.type)) {
                  ((U = l.stateNode), (Cu = !1));
                  break a;
                }
                break;
              case 5:
                ((U = l.stateNode), (Cu = !1));
                break a;
              case 3:
              case 4:
                ((U = l.stateNode.containerInfo), (Cu = !0));
                break a;
            }
            l = l.return;
          }
          if (U === null) throw Error(i(160));
          (Tu(s, c, o),
            (U = null),
            (Cu = !1),
            (s = o.alternate),
            s !== null && (s.return = null),
            (o.return = null));
        }
      if (t.subtreeFlags & 13886)
        for (t = t.child; t !== null;) (Mu(t, e, n), (t = t.sibling));
    }
    var ju = null;
    function Mu(e, t, n) {
      var r = e.alternate,
        a = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          if (
            a & 4 &&
            ((r = e.updateQueue),
            (r = r === null ? null : r.events),
            r !== null)
          )
            for (var o = 0; o < r.length; o++) {
              var s = r[o];
              s.ref.impl = s.nextImpl;
            }
          (Au(t, e, n),
            Nu(e),
            a & 4 && (Tl(3, e, e.return), wl(3, e), Tl(5, e, e.return)));
          break;
        case 1:
          (Au(t, e, n),
            Nu(e),
            a & 512 && (H || r === null || kl(r, r.return)),
            a & 64 &&
              su &&
              ((e = e.updateQueue),
              e !== null &&
                ((t = e.callbacks),
                t !== null &&
                  ((n = e.shared.hiddenCallbacks),
                  (e.shared.hiddenCallbacks = n === null ? t : n.concat(t))))));
          break;
        case 26:
          if (
            ((o = ju),
            Au(t, e, n),
            Nu(e),
            a & 512 && (H || r === null || kl(r, r.return)),
            a & 4)
          ) {
            if (
              ((a = r === null ? null : r.memoizedState),
              (n = e.memoizedState),
              r === null)
            ) {
              if (n === null) {
                if (e.stateNode === null) {
                  if (su)
                    e.stateNode = fp(
                      e.type,
                      e.memoizedProps,
                      t.containerInfo,
                      e,
                    );
                  else {
                    a: {
                      ((t = e.type),
                        (n = e.memoizedProps),
                        (a = o.ownerDocument || o));
                      b: switch (t) {
                        case `title`:
                          ((r = a.getElementsByTagName(`title`)[0]),
                            (!r ||
                              r[Rt] ||
                              r[jt] ||
                              r.namespaceURI === `http://www.w3.org/2000/svg` ||
                              r.hasAttribute(`itemprop`)) &&
                              ((r = a.createElement(t)),
                              a.head.insertBefore(
                                r,
                                a.querySelector(`head > title`),
                              )),
                            np(r, t, n),
                            (r[jt] = e),
                            Gt(r),
                            (t = r));
                          break a;
                        case `link`:
                          if (
                            (o = Gm(`link`, `href`, a).get(t + (n.href || ``)))
                          ) {
                            for (s = 0; s < o.length; s++)
                              if (
                                ((r = o[s]),
                                r.getAttribute(`href`) ===
                                  (n.href == null || n.href === ``
                                    ? null
                                    : n.href) &&
                                  r.getAttribute(`rel`) ===
                                    (n.rel == null ? null : n.rel) &&
                                  r.getAttribute(`title`) ===
                                    (n.title == null ? null : n.title) &&
                                  r.getAttribute(`crossorigin`) ===
                                    (n.crossOrigin == null
                                      ? null
                                      : n.crossOrigin))
                              ) {
                                o.splice(s, 1);
                                break b;
                              }
                          }
                          ((r = a.createElement(t)),
                            np(r, t, n),
                            a.head.appendChild(r));
                          break;
                        case `meta`:
                          if (
                            (o = Gm(`meta`, `content`, a).get(
                              t + (n.content || ``),
                            ))
                          ) {
                            for (s = 0; s < o.length; s++)
                              if (
                                ((r = o[s]),
                                r.getAttribute(`content`) ===
                                  (n.content == null ? null : `` + n.content) &&
                                  r.getAttribute(`name`) ===
                                    (n.name == null ? null : n.name) &&
                                  r.getAttribute(`property`) ===
                                    (n.property == null ? null : n.property) &&
                                  r.getAttribute(`http-equiv`) ===
                                    (n.httpEquiv == null
                                      ? null
                                      : n.httpEquiv) &&
                                  r.getAttribute(`charset`) ===
                                    (n.charSet == null ? null : n.charSet))
                              ) {
                                o.splice(s, 1);
                                break b;
                              }
                          }
                          ((r = a.createElement(t)),
                            np(r, t, n),
                            a.head.appendChild(r));
                          break;
                        default:
                          throw Error(i(468, t));
                      }
                      ((r[jt] = e), Gt(r), (t = r));
                    }
                    e.stateNode = t;
                  }
                } else su || Km(o, e.type, e.stateNode);
              } else e.stateNode = Bm(o, n, e.memoizedProps);
            } else
              a === n
                ? n === null &&
                  e.stateNode !== null &&
                  Il(e, e.memoizedProps, r.memoizedProps)
                : (a === null
                    ? ((t = r.stateNode),
                      t === null || H || t.parentNode.removeChild(t))
                    : a.count--,
                  n === null
                    ? su || Km(o, e.type, e.stateNode)
                    : Bm(o, n, e.memoizedProps));
          }
          break;
        case 27:
          (Au(t, e, n),
            Nu(e),
            a & 512 && (H || r === null || kl(r, r.return)),
            r !== null && a & 4 && Il(e, e.memoizedProps, r.memoizedProps));
          break;
        case 5:
          if (
            ((o = cu),
            (cu = !1),
            Au(t, e, n),
            (cu = o),
            Nu(e),
            a & 512 && (H || r === null || kl(r, r.return)),
            e.flags & 32)
          ) {
            t = e.stateNode;
            try {
              (yn(t, ``), (A = !0));
            } catch (t) {
              Z(e, e.return, t);
            }
          }
          (a & 4 &&
            e.stateNode != null &&
            ((t = e.memoizedProps), Il(e, t, r === null ? t : r.memoizedProps)),
            a & 1024 && (lu = !0));
          break;
        case 6:
          if ((Au(t, e, n), Nu(e), a & 4)) {
            if (e.stateNode === null) throw Error(i(162));
            ((t = e.memoizedProps), (n = e.stateNode));
            try {
              ((n.nodeValue = t), (A = !0));
            } catch (t) {
              Z(e, e.return, t);
            }
          }
          break;
        case 3:
          if (
            ((A = !1),
            (Wm = null),
            (o = ju),
            (ju = bm(t.containerInfo)),
            Au(t, e, n),
            (ju = o),
            Nu(e),
            a & 4 && r !== null && r.memoizedState.isDehydrated)
          )
            try {
              Hh(t.containerInfo);
            } catch (t) {
              Z(e, e.return, t);
            }
          (lu && ((lu = !1), Pu(e)), (A = !1));
          break;
        case 4:
          ((a = cu),
            (cu = su),
            (r = tn()),
            (o = ju),
            (ju = bm(e.stateNode.containerInfo)),
            Au(t, e, n),
            Nu(e),
            (ju = o),
            A && pu && (mu = !0),
            (A = r),
            (cu = a));
          break;
        case 12:
          (Au(t, e, n), Nu(e));
          break;
        case 31:
          (Au(t, e, n),
            Nu(e),
            a & 4 &&
              ((t = e.updateQueue),
              t !== null && ((e.updateQueue = null), ku(e, t))));
          break;
        case 13:
          (Au(t, e, n),
            Nu(e),
            e.child.flags & 8192 &&
              (e.memoizedState !== null) !=
                (r !== null && r.memoizedState !== null) &&
              (hd = Ye()),
            a & 4 &&
              ((t = e.updateQueue),
              t !== null && ((e.updateQueue = null), ku(e, t))));
          break;
        case 22:
          ((o = e.memoizedState !== null),
            (s = r !== null && r.memoizedState !== null));
          var c = su,
            l = H,
            u = cu;
          ((su = c || o),
            (cu = u || o),
            (H = l || s),
            Au(t, e, n),
            (H = l),
            (cu = u),
            (su = c),
            Nu(e),
            a & 8192 &&
              ((t = e.stateNode),
              (t._visibility = o ? t._visibility & -2 : t._visibility | 1),
              !o ||
                r === null ||
                s ||
                su ||
                H ||
                ((t = s || H),
                (n = su),
                (r = H),
                (su = o || su),
                (H = t),
                Ru(e, 2),
                (su = n),
                (H = r)),
              (!o && cu) || yu(e, o)),
            a & 4 &&
              ((t = e.updateQueue),
              t !== null &&
                ((n = t.retryQueue),
                n !== null && ((t.retryQueue = null), ku(e, n)))));
          break;
        case 19:
          (Au(t, e, n),
            Nu(e),
            a & 4 &&
              ((t = e.updateQueue),
              t !== null && ((e.updateQueue = null), ku(e, t))));
          break;
        case 30:
          (a & 512 && (H || r === null || kl(r, r.return)),
            (a = tn()),
            (o = pu),
            (s = (n & 335544064) === n),
            (c = e.memoizedProps),
            (pu = s && wi(c.default, c.update) !== `none`),
            Au(t, e, n),
            Nu(e),
            s && r !== null && A && (e.flags |= 4),
            (pu = o),
            (A = a));
          break;
        case 21:
          break;
        case 7:
          (a & 512 && (H || r === null || kl(r, r.return)),
            r && r.stateNode !== null && (r.stateNode._fragmentFiber = e));
        default:
          (Au(t, e, n), Nu(e));
      }
    }
    function Nu(e) {
      var t = e.flags;
      if (t & 2) {
        try {
          for (var n, r = e.return; r !== null;) {
            if (Ll(r)) {
              n = r;
              break;
            }
            r = r.return;
          }
          r = null;
          for (var a = e.return; a !== null;) {
            if (Pl(a)) {
              var o = a.stateNode;
              r === null ? (r = [o]) : r.push(o);
            }
            if (Nl(a)) break;
            a = a.return;
          }
          var s = r;
          if (n == null) throw Error(i(160));
          switch (n.tag) {
            case 27:
              var c = n.stateNode;
              Bl(e, Rl(e), c, s);
              break;
            case 5:
              var l = n.stateNode;
              (n.flags & 32 && (yn(l, ``), (n.flags &= -33)),
                Bl(e, Rl(e), l, s));
              break;
            case 3:
            case 4:
              var u = n.stateNode.containerInfo;
              zl(e, Rl(e), u, s);
              break;
            default:
              throw Error(i(161));
          }
        } catch (t) {
          Z(e, e.return, t);
        }
        e.flags &= -3;
      }
      t & 4096 && (e.flags &= -4097);
    }
    function Pu(e) {
      if (e.subtreeFlags & 1024)
        for (e = e.child; e !== null;) {
          var t = e;
          (Pu(t),
            t.tag === 5 &&
              t.flags & 1024 &&
              ((t = t.stateNode), (gh = !0), t.reset(), (gh = !1)),
            (e = e.sibling));
        }
    }
    function Fu(e, t) {
      if (t.subtreeFlags & 9270)
        for (t = t.child; t !== null;) (Iu(t, e), (t = t.sibling));
      else ou(t, !1);
    }
    function Iu(e, t) {
      var n = e.alternate;
      if (n === null) Ql(e, !1);
      else
        switch (e.tag) {
          case 3:
            if (((hu = fu = !1), Kl(), Fu(t, e), !fu && !mu)) {
              if (((e = Gl), e !== null))
                for (var r = 0; r < e.length; r += 3) {
                  n = e[r];
                  var i = e[r + 1];
                  (Ep(n, e[r + 2]),
                    (n = n.ownerDocument.documentElement),
                    n !== null &&
                      n.animate(
                        {
                          opacity: [0, 0],
                          pointerEvents: [`none`, `none`],
                        },
                        {
                          duration: 0,
                          fill: `forwards`,
                          pseudoElement: `::view-transition-group(` + i + `)`,
                        },
                      ));
                }
              ((e = t.containerInfo),
                (e =
                  e.nodeType === 9
                    ? e.documentElement
                    : e.ownerDocument.documentElement),
                e !== null &&
                  e.style.viewTransitionName === `` &&
                  ((e.style.viewTransitionName = `none`),
                  e.animate(
                    {
                      opacity: [0, 0],
                      pointerEvents: [`none`, `none`],
                    },
                    {
                      duration: 0,
                      fill: `forwards`,
                      pseudoElement: `::view-transition-group(root)`,
                    },
                  ),
                  e.animate(
                    {
                      width: [0, 0],
                      height: [0, 0],
                    },
                    {
                      duration: 0,
                      fill: `forwards`,
                      pseudoElement: `::view-transition`,
                    },
                  )),
                (hu = !0));
            }
            Gl = null;
            break;
          case 5:
            Fu(t, e);
            break;
          case 4:
            ((r = fu), (fu = !1), Fu(t, e), fu && (mu = !0), (fu = r));
            break;
          case 22:
            e.memoizedState === null &&
              (n.memoizedState === null ? Fu(t, e) : Ql(e, !1));
            break;
          case 30:
            ((r = fu), (i = Kl()), (fu = !1), Fu(t, e), fu && (e.flags |= 4));
            var a = e.memoizedProps,
              o = e.stateNode;
            ((t = Si(a, o)), (o = Si(n.memoizedProps, o)));
            var s = wi(a.default, a.update);
            (s === `none`
              ? (t = !1)
              : ((a = n.memoizedState),
                (n.memoizedState = null),
                (n = e.child),
                (ql = 0),
                (t = au(e, n, t, o, s, a, !0)),
                ql !== (a === null ? 0 : a.length) && (e.flags |= 32)),
              e.flags & 4 && t
                ? (Nd(e, e.memoizedProps.onUpdate), (Gl = i))
                : i !== null && (i.push.apply(i, Gl), (Gl = i)),
              (fu = e.flags & 32 ? !0 : r));
            break;
          default:
            Fu(t, e);
        }
    }
    function Lu(e, t) {
      if (t.subtreeFlags & 8772)
        for (t = t.child; t !== null;) (vu(e, t.alternate, t), (t = t.sibling));
    }
    function Ru(e, t) {
      for (e = e.child; e !== null;) {
        var n = e,
          r = t;
        switch (n.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            (Tl(4, n, n.return), Ru(n, r));
            break;
          case 1:
            kl(n, n.return);
            var i = n.stateNode;
            (typeof i.componentWillUnmount == `function` && Dl(n, n.return, i),
              Ru(n, r));
            break;
          case 27:
            r & 2 && gm(n.stateNode, n.type, n.memoizedProps);
          case 5:
            (kl(n, n.return), (n.tag !== 5 && n.tag !== 27) || Ml(n), Ru(n, r));
            break;
          case 6:
            Ml(n);
            break;
          case 26:
            (kl(n, n.return),
              (i = n.stateNode),
              n.memoizedState !== null ||
                i === null ||
                H ||
                i.parentNode.removeChild(i),
              Ru(n, r));
            break;
          case 22:
            n.memoizedState === null && Ru(n, r);
            break;
          case 30:
            (kl(n, n.return), Ru(n, r));
            break;
          case 7:
            kl(n, n.return);
          default:
            Ru(n, r);
        }
        e = e.sibling;
      }
    }
    function zu(e, t, n) {
      for (n = t.subtreeFlags & 8772 ? n : n & -2, t = t.child; t !== null;) {
        var r = t.alternate,
          i = e,
          a = t,
          o = a.flags,
          s = !!(n & 1);
        switch (a.tag) {
          case 0:
          case 11:
          case 15:
            (zu(i, a, n), wl(4, a));
            break;
          case 1:
            if (
              (zu(i, a, n),
              (r = a),
              (i = r.stateNode),
              typeof i.componentDidMount == `function`)
            )
              try {
                i.componentDidMount();
              } catch (e) {
                Z(r, r.return, e);
              }
            if (((r = a), (i = r.updateQueue), i !== null)) {
              var c = r.stateNode;
              try {
                var l = i.shared.hiddenCallbacks;
                if (l !== null)
                  for (
                    i.shared.hiddenCallbacks = null, i = 0;
                    i < l.length;
                    i++
                  )
                    Oo(l[i], c);
              } catch (e) {
                Z(r, r.return, e);
              }
            }
            (s && o & 64 && El(a), Ol(a, a.return));
            break;
          case 27:
            n & 2 && Vl(a);
          case 5:
            ((a.tag !== 5 && a.tag !== 27) || jl(a),
              zu(i, a, n),
              s && r === null && o & 4 && Fl(a),
              Ol(a, a.return));
            break;
          case 6:
            jl(a);
            break;
          case 26:
            ((c = a.stateNode),
              a.memoizedState !== null ||
                c === null ||
                su ||
                Km(bm(c.ownerDocument), a.type, c),
              zu(i, a, n),
              s && r === null && o & 4 && Fl(a),
              Ol(a, a.return));
            break;
          case 12:
            zu(i, a, n);
            break;
          case 31:
            (zu(i, a, n), s && o & 4 && Eu(i, a));
            break;
          case 13:
            (zu(i, a, n), s && o & 4 && Du(i, a));
            break;
          case 22:
            (a.memoizedState === null && zu(i, a, n), Ol(a, a.return));
            break;
          case 30:
            (zu(i, a, n), Ol(a, a.return));
            break;
          case 7:
            Ol(a, a.return);
          default:
            zu(i, a, n);
        }
        t = t.sibling;
      }
    }
    function Bu(e, t) {
      var n = null;
      (e !== null &&
        e.memoizedState !== null &&
        e.memoizedState.cachePool !== null &&
        (n = e.memoizedState.cachePool.pool),
        (e = null),
        t.memoizedState !== null &&
          t.memoizedState.cachePool !== null &&
          (e = t.memoizedState.cachePool.pool),
        e !== n && (e != null && e.refCount++, n != null && La(n)));
    }
    function Vu(e, t) {
      ((e = null),
        t.alternate !== null && (e = t.alternate.memoizedState.cache),
        (t = t.memoizedState.cache),
        t !== e && (t.refCount++, e != null && La(e)));
    }
    function Hu(e, t, n, r) {
      var i = (n & 335544064) === n;
      if (t.subtreeFlags & (i ? 10262 : 10256))
        for (t = t.child; t !== null;) (Uu(e, t, n, r), (t = t.sibling));
      else i && iu(t);
    }
    function Uu(e, t, n, r) {
      var i = (n & 335544064) === n;
      i &&
        t.alternate === null &&
        t.return !== null &&
        t.return.alternate !== null &&
        ru(t);
      var a = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          (Hu(e, t, n, r), a & 2048 && wl(9, t));
          break;
        case 1:
          Hu(e, t, n, r);
          break;
        case 3:
          (Hu(e, t, n, r),
            i &&
              hu &&
              ((e = e.containerInfo),
              (e =
                e.nodeType === 9
                  ? e.body
                  : e.nodeName === `HTML`
                    ? e.ownerDocument.body
                    : e),
              e.style.viewTransitionName === `root` &&
                (e.style.viewTransitionName = ``),
              (e = e.ownerDocument.documentElement),
              e !== null &&
                e.style.viewTransitionName === `none` &&
                (e.style.viewTransitionName = ``)),
            a & 2048 &&
              ((a = null),
              t.alternate !== null && (a = t.alternate.memoizedState.cache),
              (t = t.memoizedState.cache),
              t !== a && (t.refCount++, a != null && La(a))));
          break;
        case 12:
          if (a & 2048) {
            (Hu(e, t, n, r), (a = t.stateNode));
            try {
              var o = t.memoizedProps,
                s = o.id,
                c = o.onPostCommit;
              typeof c == `function` &&
                c(
                  s,
                  t.alternate === null ? `mount` : `update`,
                  a.passiveEffectDuration,
                  -0,
                );
            } catch (e) {
              Z(t, t.return, e);
            }
          } else Hu(e, t, n, r);
          break;
        case 31:
          Hu(e, t, n, r);
          break;
        case 13:
          Hu(e, t, n, r);
          break;
        case 23:
          break;
        case 22:
          ((o = t.stateNode),
            (s = t.alternate),
            t.memoizedState === null
              ? (i && s !== null && s.memoizedState !== null && ru(t),
                o._visibility & 2
                  ? Hu(e, t, n, r)
                  : ((o._visibility |= 2),
                    Wu(e, t, n, r, !!(t.subtreeFlags & 10256) || !1)))
              : (i && s !== null && s.memoizedState === null && ru(s),
                o._visibility & 2 ? Hu(e, t, n, r) : Gu(e, t)),
            a & 2048 && Bu(s, t));
          break;
        case 24:
          (Hu(e, t, n, r), a & 2048 && Vu(t.alternate, t));
          break;
        case 30:
          (i &&
            ((a = t.alternate),
            a !== null && (Xl(a.child, !0), Xl(t.child, !0))),
            Hu(e, t, n, r));
          break;
        default:
          Hu(e, t, n, r);
      }
    }
    function Wu(e, t, n, r, i) {
      for (i &&= !!(t.subtreeFlags & 10256) || !1, t = t.child; t !== null;) {
        var a = e,
          o = t,
          s = n,
          c = r,
          l = o.flags;
        switch (o.tag) {
          case 0:
          case 11:
          case 15:
            (Wu(a, o, s, c, i), wl(8, o));
            break;
          case 23:
            break;
          case 22:
            var u = o.stateNode;
            (o.memoizedState === null
              ? ((u._visibility |= 2), Wu(a, o, s, c, i))
              : u._visibility & 2
                ? Wu(a, o, s, c, i)
                : Gu(a, o),
              i && l & 2048 && Bu(o.alternate, o));
            break;
          case 24:
            (Wu(a, o, s, c, i), i && l & 2048 && Vu(o.alternate, o));
            break;
          default:
            Wu(a, o, s, c, i);
        }
        t = t.sibling;
      }
    }
    function Gu(e, t) {
      if (t.subtreeFlags & 10256)
        for (t = t.child; t !== null;) {
          var n = e,
            r = t,
            i = r.flags;
          switch (r.tag) {
            case 22:
              (Gu(n, r), i & 2048 && Bu(r.alternate, r));
              break;
            case 24:
              (Gu(n, r), i & 2048 && Vu(r.alternate, r));
              break;
            default:
              Gu(n, r);
          }
          t = t.sibling;
        }
    }
    var Ku = 8192;
    function qu(e, t, n) {
      if (e.subtreeFlags & Ku)
        for (e = e.child; e !== null;) (Ju(e, t, n), (e = e.sibling));
    }
    function Ju(e, t, n) {
      switch (e.tag) {
        case 26:
          (qu(e, t, n),
            e.flags & Ku &&
              (e.memoizedState === null
                ? ((e = e.stateNode), (t & 335544128) === t && Zm(n, e))
                : Qm(n, ju, e.memoizedState, e.memoizedProps)));
          break;
        case 5:
          (qu(e, t, n),
            e.flags & Ku &&
              ((e = e.stateNode), (t & 335544128) === t && Zm(n, e)));
          break;
        case 3:
        case 4:
          var r = ju;
          ((ju = bm(e.stateNode.containerInfo)), qu(e, t, n), (ju = r));
          break;
        case 22:
          e.memoizedState === null &&
            ((r = e.alternate),
            r !== null && r.memoizedState !== null
              ? ((r = Ku), (Ku = 16777216), qu(e, t, n), (Ku = r))
              : qu(e, t, n));
          break;
        case 30:
          if (
            (e.flags & Ku) !== 0 &&
            ((r = e.memoizedProps.name), r != null && r !== `auto`)
          ) {
            var i = e.stateNode;
            ((i.paired = null), Ul === null && (Ul = new Map()), Ul.set(r, i));
          }
          qu(e, t, n);
          break;
        default:
          qu(e, t, n);
      }
    }
    function Yu(e) {
      var t = e.alternate;
      if (t !== null && ((e = t.child), e !== null)) {
        t.child = null;
        do ((t = e.sibling), (e.sibling = null), (e = t));
        while (e !== null);
      }
    }
    function Xu(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            ((du = r), $u(r, e));
          }
        Yu(e);
      }
      if (e.subtreeFlags & 10256)
        for (e = e.child; e !== null;) (Zu(e), (e = e.sibling));
    }
    function Zu(e) {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          (Xu(e), e.flags & 2048 && Tl(9, e, e.return));
          break;
        case 3:
          Xu(e);
          break;
        case 12:
          Xu(e);
          break;
        case 22:
          var t = e.stateNode;
          e.memoizedState !== null &&
          t._visibility & 2 &&
          (e.return === null || e.return.tag !== 13)
            ? ((t._visibility &= -3), Qu(e))
            : Xu(e);
          break;
        default:
          Xu(e);
      }
    }
    function Qu(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            ((du = r), $u(r, e));
          }
        Yu(e);
      }
      for (e = e.child; e !== null;) {
        switch (((t = e), t.tag)) {
          case 0:
          case 11:
          case 15:
            (Tl(8, t, t.return), Qu(t));
            break;
          case 22:
            ((n = t.stateNode),
              n._visibility & 2 && ((n._visibility &= -3), Qu(t)));
            break;
          default:
            Qu(t);
        }
        e = e.sibling;
      }
    }
    function $u(e, t) {
      for (; du !== null;) {
        var n = du;
        switch (n.tag) {
          case 0:
          case 11:
          case 15:
            Tl(8, n, t);
            break;
          case 23:
          case 22:
            if (
              n.memoizedState !== null &&
              n.memoizedState.cachePool !== null
            ) {
              var r = n.memoizedState.cachePool.pool;
              r != null && r.refCount++;
            }
            break;
          case 24:
            La(n.memoizedState.cache);
        }
        if (((r = n.child), r !== null)) ((r.return = n), (du = r));
        else
          a: for (n = e; du !== null;) {
            r = du;
            var i = r.sibling,
              a = r.return;
            if ((Su(r), r === n)) {
              du = null;
              break a;
            }
            if (i !== null) {
              ((i.return = a), (du = i));
              break a;
            }
            du = a;
          }
      }
    }
    var ed = {
        getCacheForType: function (e) {
          var t = ka(Fa),
            n = t.data.get(e);
          return (n === void 0 && ((n = e()), t.data.set(e, n)), n);
        },
        cacheSignal: function () {
          return ka(Fa).controller.signal;
        },
      },
      td = typeof WeakMap == `function` ? WeakMap : Map,
      W = 0,
      G = null,
      K = null,
      q = 0,
      J = 0,
      nd = null,
      rd = !1,
      id = !1,
      ad = !1,
      od = 0,
      Y = 0,
      sd = 0,
      cd = 0,
      ld = 0,
      ud = 0,
      dd = 0,
      fd = null,
      pd = null,
      md = !1,
      hd = 0,
      gd = 0,
      _d = 1 / 0,
      vd = null,
      yd = null,
      X = 0,
      bd = null,
      xd = null,
      Sd = 0,
      Cd = 0,
      wd = null,
      Td = null,
      Ed = null,
      Dd = null,
      Od = null,
      kd = 0,
      Ad = null;
    function jd() {
      return W & 2 && q !== 0 ? q & -q : D.T === null ? Ot() : Pf();
    }
    function Md() {
      if (ud === 0) {
        if (!(q & 536870912) || I) {
          var e = ft;
          ((ft <<= 1), !(ft & 3932160) && (ft = 262144), (ud = e));
        } else ud = 536870912;
      }
      return ((e = Fo.current), e !== null && (e.flags |= 32), ud);
    }
    function Nd(e, t) {
      if (t != null) {
        var n = e.stateNode,
          r = n.ref;
        (r === null && (r = n.ref = Pp(Si(e.memoizedProps, n))),
          Dd === null && (Dd = []),
          Dd.push(t.bind(null, r)));
      }
    }
    function Pd(e, t, n) {
      (((e === G && (J === 2 || J === 9)) || e.cancelPendingCommit !== null) &&
        (Vd(e, 0), Rd(e, q, ud, !1)),
        xt(e, n),
        (!(W & 2) || e !== G) &&
          (e === G && (!(W & 2) && (cd |= n), Y === 4 && Rd(e, q, ud, !1)),
          Ef(e)));
    }
    function Fd(e, t, n) {
      if (W & 6) throw Error(i(327));
      var r = (!n && !(t & 127) && (t & e.expiredLanes) === 0) || gt(e, t),
        a = r ? Yd(e, t) : qd(e, t, !0),
        o = r;
      do {
        if (a === 0) {
          id && !r && Rd(e, t, 0, !1);
          break;
        }
        if (((n = e.current.alternate), o && !Ld(n))) {
          ((a = qd(e, t, !1)), (o = !1));
          continue;
        }
        if (a === 2) {
          if (((o = t), e.errorRecoveryDisabledLanes & o)) var s = 0;
          else
            ((s = e.pendingLanes & -536870913),
              (s = s === 0 ? (s & 536870912 ? 536870912 : 0) : s));
          if (s !== 0) {
            t = s;
            a: {
              var c = e;
              a = fd;
              var l = c.current.memoizedState.isDehydrated;
              if (
                (l && (Vd(c, s).flags |= 256),
                (s = qd(c, s, !1)),
                s !== 2 && s !== 6)
              ) {
                if (ad && !l) {
                  ((c.errorRecoveryDisabledLanes |= o), (cd |= o), (a = 4));
                  break a;
                }
                ((o = pd),
                  (pd = a),
                  o !== null &&
                    (pd === null ? (pd = o) : pd.push.apply(pd, o)));
              }
              a = s;
            }
            if (((o = !1), a !== 2)) continue;
          }
        }
        if (a === 1) {
          (Vd(e, 0), Rd(e, t, 0, !0));
          break;
        }
        a: {
          switch (((r = e), (o = a), o)) {
            case 0:
            case 1:
              throw Error(i(345));
            case 4:
              if ((t & 4194048) !== t && (t & 62914560) !== t) break;
            case 6:
              Rd(r, t, ud, !rd);
              break a;
            case 2:
              pd = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(i(329));
          }
          if ((t & 62914560) === t && ((a = hd + 300 - Ye()), 10 < a)) {
            if ((Rd(r, t, ud, !rd), ht(r, 0, !0) !== 0)) break a;
            ((Sd = t),
              (r.timeoutHandle = gp(
                Id.bind(
                  null,
                  r,
                  n,
                  pd,
                  vd,
                  md,
                  t,
                  ud,
                  cd,
                  dd,
                  rd,
                  o,
                  `Throttled`,
                  -0,
                  0,
                ),
                a,
              )));
            break a;
          }
          Id(r, n, pd, vd, md, t, ud, cd, dd, rd, o, null, -0, 0);
        }
        break;
      } while (1);
      Ef(e);
    }
    function Id(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
      e.timeoutHandle = -1;
      var m = t.subtreeFlags,
        h = (a & 335544064) === a;
      if (
        ((d = null),
        (h || m & 8192 || (m & 16785408) == 16785408) &&
          ((d = {
            stylesheets: null,
            count: 0,
            imgCount: 0,
            imgBytes: 0,
            suspenseyImages: [],
            waitingForImages: !0,
            waitingForViewTransition: !1,
            unsuspend: Dn,
          }),
          (Ul = null),
          Ju(t, a, d),
          h &&
            ((m = d),
            (h = e.containerInfo),
            (h = (h.nodeType === 9 ? h : h.ownerDocument)
              .__reactViewTransition),
            h != null &&
              (m.count++,
              (m.waitingForViewTransition = !0),
              (m = nh.bind(m)),
              h.finished.then(m, m))),
          (m =
            (a & 62914560) === a
              ? hd - Ye()
              : (a & 4194048) === a
                ? gd - Ye()
                : 0),
          (m = eh(d, m)),
          m !== null))
      ) {
        ((Sd = a),
          (e.cancelPendingCommit = m(
            nf.bind(null, e, t, a, n, r, i, o, s, c, l, u, d, null, f, p),
          )),
          Rd(e, a, o, !l));
        return;
      }
      nf(e, t, a, n, r, i, o, s, c, l, u, d);
    }
    function Ld(e) {
      for (var t = e; ;) {
        var n = t.tag;
        if (
          (n === 0 || n === 11 || n === 15) &&
          t.flags & 16384 &&
          ((n = t.updateQueue), n !== null && ((n = n.stores), n !== null))
        )
          for (var r = 0; r < n.length; r++) {
            var i = n[r],
              a = i.getSnapshot;
            i = i.value;
            try {
              if (!Kr(a(), i)) return !1;
            } catch {
              return !1;
            }
          }
        if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
          ((n.return = t), (t = n));
        else {
          if (t === e) break;
          for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return !0;
            t = t.return;
          }
          ((t.sibling.return = t.return), (t = t.sibling));
        }
      }
      return !0;
    }
    function Rd(e, t, n, r) {
      ((t = _t(e, t)),
        (t &= ~ld),
        (t &= ~cd),
        (e.suspendedLanes |= t),
        (e.pingedLanes &= ~t),
        r && (e.warmLanes |= t),
        (r = e.expirationTimes));
      for (var i = t; 0 < i;) {
        var a = 31 - st(i),
          o = 1 << a;
        ((r[a] = -1), (i &= ~o));
      }
      n !== 0 && Ct(e, n, t);
    }
    function zd() {
      return W & 6 ? !0 : (Df(0, !1), !1);
    }
    function Bd() {
      if (K !== null) {
        if (J === 0) var e = K.return;
        else ((e = K), (xa = ba = null), cs(e), (lo = null), (uo = 0), (e = K));
        for (; e !== null;) (Cl(e.alternate, e), (e = e.return));
        K = null;
      }
    }
    function Vd(e, t) {
      var n = e.timeoutHandle;
      return (
        n !== -1 && ((e.timeoutHandle = -1), _p(n)),
        (n = e.cancelPendingCommit),
        n !== null && ((e.cancelPendingCommit = null), n()),
        (Sd = 0),
        Bd(),
        (G = e),
        (K = n = zi(e.current, null)),
        (q = t),
        (J = 0),
        (nd = null),
        (rd = !1),
        (id = gt(e, t)),
        (ad = !1),
        (dd = ud = ld = cd = sd = Y = 0),
        (pd = fd = null),
        (md = !1),
        (od = _t(e, t)),
        ki(),
        n
      );
    }
    function Hd(e, t) {
      ((L = null),
        (D.H = _c),
        t === $a || t === to
          ? ((t = so()), (J = 3))
          : t === eo
            ? ((t = so()), (J = 4))
            : (J =
                t === Fc
                  ? 8
                  : typeof t == `object` && t && typeof t.then == `function`
                    ? 6
                    : 1),
        (nd = t),
        K === null && ((Y = 1), kc(e, qi(t, e.current))));
    }
    function Ud() {
      var e = Fo.current;
      return e === null
        ? !0
        : (q & 4194048) === q
          ? Io === null
          : (q & 62914560) === q || q & 536870912
            ? e === Io
            : !1;
    }
    function Wd() {
      var e = D.H;
      return ((D.H = _c), e === null ? _c : e);
    }
    function Gd() {
      var e = D.A;
      return ((D.A = ed), e);
    }
    function Kd() {
      ((Y = 4),
        rd || ((q & 4194048) !== q && Fo.current !== null) || (id = !0),
        (!(sd & 134217727) && !(cd & 134217727)) ||
          G === null ||
          Rd(G, q, ud, !1));
    }
    function qd(e, t, n) {
      var r = W;
      W |= 2;
      var i = Wd(),
        a = Gd();
      ((G !== e || q !== t) && ((vd = null), Vd(e, t)), (t = !1));
      var o = Y;
      a: do
        try {
          if (J !== 0 && K !== null) {
            var s = K,
              c = nd;
            switch (J) {
              case 8:
                (Bd(), (o = 6));
                break a;
              case 3:
              case 2:
              case 9:
              case 6:
                Fo.current === null && (t = !0);
                var l = J;
                if (((J = 0), (nd = null), $d(e, s, c, l), n && id)) {
                  o = 0;
                  break a;
                }
                break;
              default:
                ((l = J), (J = 0), (nd = null), $d(e, s, c, l));
            }
          }
          (Jd(), (o = Y));
          break;
        } catch (t) {
          Hd(e, t);
        }
      while (1);
      return (
        t && e.shellSuspendCounter++,
        (xa = ba = null),
        (W = r),
        (D.H = i),
        (D.A = a),
        K === null && ((G = null), (q = 0), ki()),
        o
      );
    }
    function Jd() {
      for (; K !== null;) Zd(K);
    }
    function Yd(e, t) {
      var n = W;
      W |= 2;
      var r = Wd(),
        a = Gd();
      G !== e || q !== t
        ? ((vd = null), (_d = Ye() + 500), Vd(e, t))
        : (id = gt(e, t));
      a: do
        try {
          if (J !== 0 && K !== null) {
            t = K;
            var o = nd;
            b: switch (J) {
              case 1:
                ((J = 0), (nd = null), $d(e, t, o, 1));
                break;
              case 2:
              case 9:
                if (ro(o)) {
                  ((J = 0), (nd = null), Qd(t));
                  break;
                }
                ((t = function () {
                  ((J !== 2 && J !== 9) || G !== e || (J = 7), Ef(e));
                }),
                  o.then(t, t));
                break a;
              case 3:
                J = 7;
                break a;
              case 4:
                J = 5;
                break a;
              case 7:
                ro(o)
                  ? ((J = 0), (nd = null), Qd(t))
                  : ((J = 0), (nd = null), $d(e, t, o, 7));
                break;
              case 5:
                var s = null;
                switch (K.tag) {
                  case 26:
                    s = K.memoizedState;
                  case 5:
                  case 27:
                    var c = K;
                    if (s ? Ym(s) : c.stateNode.complete) {
                      ((J = 0), (nd = null));
                      var l = c.sibling;
                      if (l !== null) K = l;
                      else {
                        var u = c.return;
                        u === null ? (K = null) : ((K = u), ef(u));
                      }
                      break b;
                    }
                }
                ((J = 0), (nd = null), $d(e, t, o, 5));
                break;
              case 6:
                ((J = 0), (nd = null), $d(e, t, o, 6));
                break;
              case 8:
                (Bd(), (Y = 6));
                break a;
              default:
                throw Error(i(462));
            }
          }
          Xd();
          break;
        } catch (t) {
          Hd(e, t);
        }
      while (1);
      return (
        (xa = ba = null),
        (D.H = r),
        (D.A = a),
        (W = n),
        K === null ? ((G = null), (q = 0), ki(), Y) : 0
      );
    }
    function Xd() {
      for (; K !== null && !qe();) Zd(K);
    }
    function Zd(e) {
      var t = hl(e.alternate, e, od);
      ((e.memoizedProps = e.pendingProps), t === null ? ef(e) : (K = t));
    }
    function Qd(e) {
      var t = e,
        n = t.alternate;
      switch (t.tag) {
        case 15:
        case 0:
          t = Yc(n, t, t.pendingProps, t.type, void 0, q);
          break;
        case 11:
          t = Yc(n, t, t.pendingProps, t.type.render, t.ref, q);
          break;
        case 5:
          cs(t);
          var r = t;
          r === ca &&
            (I
              ? (ma(r), r.tag === 5 && r.stateNode != null && (F = r.stateNode))
              : (ma(r), (I = !0)));
        default:
          (Cl(n, t), (t = K = Bi(t, od)), (t = hl(n, t, od)));
      }
      ((e.memoizedProps = e.pendingProps), t === null ? ef(e) : (K = t));
    }
    function $d(e, t, n, r) {
      ((xa = ba = null), cs(t), (lo = null), (uo = 0));
      var i = t.return;
      try {
        if (Pc(e, i, t, n, q)) {
          ((Y = 1), kc(e, qi(n, e.current)), (K = null));
          return;
        }
      } catch (t) {
        if (i !== null) throw ((K = i), t);
        ((Y = 1), kc(e, qi(n, e.current)), (K = null));
        return;
      }
      t.flags & 32768
        ? (I || r === 1
            ? (e = !0)
            : id || q & 536870912
              ? (e = !1)
              : ((rd = e = !0),
                (r === 2 || r === 9 || r === 3 || r === 6) &&
                  ((r = Fo.current),
                  r !== null && r.tag === 13 && (r.flags |= 16384))),
          tf(t, e))
        : ef(t);
    }
    function ef(e) {
      var t = e;
      do {
        if (t.flags & 32768) {
          tf(t, rd);
          return;
        }
        e = t.return;
        var n = xl(t.alternate, t, od);
        if (n !== null) {
          K = n;
          return;
        }
        if (((t = t.sibling), t !== null)) {
          K = t;
          return;
        }
        K = t = e;
      } while (t !== null);
      Y === 0 && (Y = 5);
    }
    function tf(e, t) {
      do {
        var n = Sl(e.alternate, e);
        if (n !== null) {
          ((n.flags &= 32767), (K = n));
          return;
        }
        if (
          ((n = e.return),
          n !== null &&
            ((n.flags |= 32768), (n.subtreeFlags = 0), (n.deletions = null)),
          !t && ((e = e.sibling), e !== null))
        ) {
          K = e;
          return;
        }
        K = e = n;
      } while (e !== null);
      ((Y = 6), (K = null));
    }
    function nf(e, t, n, r, a, o, s, c, l, u, d, f) {
      e.cancelPendingCommit = null;
      do df();
      while (X !== 0);
      if (W & 6) throw Error(i(327));
      if (t !== null) {
        if (t === e.current) throw Error(i(177));
        (e === G && ((K = G = null), (q = 0)),
          (xd = t),
          (bd = e),
          (Sd = n),
          (wd = a),
          (Td = r),
          rf(e, t, n, s, c, l, f));
      }
    }
    function rf(e, t, n, r, i, a, o) {
      var s = t.lanes | t.childLanes;
      if (
        ((Cd = s),
        (s |= Oi),
        St(e, n, s, r, i, a),
        (Dd = null),
        (n & 335544064) === n
          ? ((Od = Ba(e)), (r = 10262))
          : ((Od = null), (r = 10256)),
        (t.subtreeFlags & r) !== 0 || (t.flags & r) !== 0
          ? ((e.callbackNode = null),
            (e.callbackPriority = 0),
            yf($e, function () {
              return (ff(), null);
            }))
          : ((e.callbackNode = null), (e.callbackPriority = 0)),
        (Hl = !1),
        (r = !!(t.flags & 13878)),
        t.subtreeFlags & 13878 || r)
      ) {
        ((r = D.T), (D.T = null), (i = O.p), (O.p = 2), (a = W), (W |= 4));
        try {
          gu(e, t, n);
        } finally {
          ((W = a), (O.p = i), (D.T = r));
        }
      }
      ((X = 1),
        Hl
          ? (Ed = Mp(
              o,
              e.containerInfo,
              Od,
              sf,
              cf,
              of,
              lf,
              ff,
              af,
              null,
              null,
            ))
          : (sf(), cf(), lf()));
    }
    function af(e) {
      if (X !== 0) {
        var t = bd.onRecoverableError;
        t(e, {
          componentStack: null,
        });
      }
    }
    function of() {
      X === 3 && ((X = 0), Iu(xd, bd), (X = 4));
    }
    function sf() {
      if (X === 1) {
        X = 0;
        var e = bd,
          t = xd,
          n = Sd,
          r = !!(t.flags & 13878);
        if (t.subtreeFlags & 13878 || r) {
          ((r = D.T), (D.T = null));
          var i = O.p;
          O.p = 2;
          var a = W;
          W |= 4;
          try {
            ((pu = mu = !1), Mu(t, e, n), (n = cp));
            var o = Qr(e.containerInfo),
              s = n.focusedElem,
              c = n.selectionRange;
            if (
              o !== s &&
              s &&
              s.ownerDocument &&
              Zr(s.ownerDocument.documentElement, s)
            ) {
              if (c !== null && $r(s)) {
                var l = c.start,
                  u = c.end;
                if ((u === void 0 && (u = l), `selectionStart` in s))
                  ((s.selectionStart = l),
                    (s.selectionEnd = Math.min(u, s.value.length)));
                else {
                  var d = s.ownerDocument || document,
                    f = (d && d.defaultView) || window;
                  if (f.getSelection) {
                    var p = f.getSelection(),
                      m = s.textContent.length,
                      h = Math.min(c.start, m),
                      g = c.end === void 0 ? h : Math.min(c.end, m);
                    !p.extend && h > g && ((o = g), (g = h), (h = o));
                    var _ = Xr(s, h),
                      v = Xr(s, g);
                    if (
                      _ &&
                      v &&
                      (p.rangeCount !== 1 ||
                        p.anchorNode !== _.node ||
                        p.anchorOffset !== _.offset ||
                        p.focusNode !== v.node ||
                        p.focusOffset !== v.offset)
                    ) {
                      var y = d.createRange();
                      (y.setStart(_.node, _.offset),
                        p.removeAllRanges(),
                        h > g
                          ? (p.addRange(y), p.extend(v.node, v.offset))
                          : (y.setEnd(v.node, v.offset), p.addRange(y)));
                    }
                  }
                }
              }
              for (d = [], p = s; (p = p.parentNode);)
                p.nodeType === 1 &&
                  d.push({
                    element: p,
                    left: p.scrollLeft,
                    top: p.scrollTop,
                  });
              for (
                typeof s.focus == `function` && s.focus(), s = 0;
                s < d.length;
                s++
              ) {
                var b = d[s];
                ((b.element.scrollLeft = b.left),
                  (b.element.scrollTop = b.top));
              }
            }
            ((gh = !!sp), (cp = sp = null));
          } finally {
            ((W = a), (O.p = i), (D.T = r));
          }
        }
        ((e.current = t), (X = 2));
      }
    }
    function cf() {
      if (X === 2) {
        X = 0;
        var e = bd,
          t = xd,
          n = !!(t.flags & 8772);
        if (t.subtreeFlags & 8772 || n) {
          ((n = D.T), (D.T = null));
          var r = O.p;
          O.p = 2;
          var i = W;
          W |= 4;
          try {
            vu(e, t.alternate, t);
          } finally {
            ((W = i), (O.p = r), (D.T = n));
          }
        }
        X = 3;
      }
    }
    function lf() {
      if (X === 4 || X === 3) {
        X = 0;
        var e = Ed;
        ((Ed = null), Je());
        var t = bd,
          n = xd,
          r = Sd,
          i = Td,
          a = (r & 335544064) === r ? 10262 : 10256;
        if (
          ((n.subtreeFlags & a) !== 0 || (n.flags & a) !== 0
            ? (X = 5)
            : ((X = 0), (xd = bd = null), uf(t, t.pendingLanes)),
          (a = t.pendingLanes),
          a === 0 && (yd = null),
          Dt(r),
          (n = n.stateNode),
          at && typeof at.onCommitFiberRoot == `function`)
        )
          try {
            at.onCommitFiberRoot(it, n, void 0, (n.current.flags & 128) == 128);
          } catch {}
        if (i !== null) {
          ((n = D.T), (a = O.p), (O.p = 2), (D.T = null));
          try {
            for (var o = t.onRecoverableError, s = 0; s < i.length; s++) {
              var c = i[s];
              o(c.value, {
                componentStack: c.stack,
              });
            }
          } finally {
            ((D.T = n), (O.p = a));
          }
        }
        if (
          ((i = Dd),
          (o = Od),
          (Od = null),
          i !== null && ((Dd = null), o === null && (o = []), e !== null))
        )
          for (c = 0; c < i.length; c++)
            ((n = (0, i[c])(o)), n !== void 0 && e.finished.finally(n));
        (Sd & 3 && df(),
          Ef(t),
          (a = t.pendingLanes),
          r & 261930 && a & 42
            ? t === Ad
              ? kd++
              : ((kd = 0), (Ad = t))
            : ((kd = 0), (Ad = null)),
          Df(0, !1));
      }
    }
    function uf(e, t) {
      (e.pooledCacheLanes &= t) === 0 &&
        ((t = e.pooledCache), t != null && ((e.pooledCache = null), La(t)));
    }
    function df() {
      return (
        Ed !== null && (Ed.skipTransition(), (Ed = null)),
        sf(),
        cf(),
        lf(),
        ff()
      );
    }
    function ff() {
      if (X !== 5) return !1;
      var e = bd,
        t = Cd;
      Cd = 0;
      var n = Dt(Sd),
        r = D.T,
        a = O.p;
      try {
        ((O.p = 32 > n ? 32 : n), (D.T = null), (n = wd), (wd = null));
        var o = bd,
          s = Sd;
        if (((X = 0), (xd = bd = null), (Sd = 0), W & 6)) throw Error(i(331));
        var c = W;
        if (
          ((W |= 4),
          Zu(o.current),
          Uu(o, o.current, s, n),
          (W = c),
          Df(0, !1),
          at && typeof at.onPostCommitFiberRoot == `function`)
        )
          try {
            at.onPostCommitFiberRoot(it, o);
          } catch {}
        return !0;
      } finally {
        ((O.p = a), (D.T = r), uf(e, t));
      }
    }
    function pf(e, t, n) {
      ((t = qi(n, t)),
        (t = jc(e.stateNode, t, 2)),
        (e = So(e, t, 2)),
        e !== null && (xt(e, 2), Ef(e)));
    }
    function Z(e, t, n) {
      if (e.tag === 3) pf(e, e, n);
      else
        for (; t !== null;) {
          if (t.tag === 3) {
            pf(t, e, n);
            break;
          }
          if (t.tag === 1) {
            var r = t.stateNode;
            if (
              typeof t.type.getDerivedStateFromError == `function` ||
              (typeof r.componentDidCatch == `function` &&
                (yd === null || !yd.has(r)))
            ) {
              ((e = qi(n, e)),
                (n = Mc(2)),
                (r = So(t, n, 2)),
                r !== null && (Nc(n, r, t, e), xt(r, 2), Ef(r)));
              break;
            }
          }
          t = t.return;
        }
    }
    function mf(e, t, n) {
      var r = e.pingCache;
      if (r === null) {
        r = e.pingCache = new td();
        var i = new Set();
        r.set(t, i);
      } else ((i = r.get(t)), i === void 0 && ((i = new Set()), r.set(t, i)));
      i.has(n) ||
        ((ad = !0), i.add(n), (e = hf.bind(null, e, t, n)), t.then(e, e));
    }
    function hf(e, t, n) {
      var r = e.pingCache;
      (r !== null && r.delete(t),
        (e.pingedLanes |= e.suspendedLanes & n),
        (e.warmLanes &= ~n),
        G === e &&
          (q & n) === n &&
          (Y === 4 || (Y === 3 && (q & 62914560) === q && 300 > Ye() - hd)
            ? W & 2
              ? (ld |= n)
              : Vd(e, 0)
            : (ld |= n),
          dd === q && (dd = 0)),
        Ef(e));
    }
    function gf(e, t) {
      (t === 0 && (t = yt()), (e = Mi(e, t)), e !== null && (xt(e, t), Ef(e)));
    }
    function _f(e) {
      var t = e.memoizedState,
        n = 0;
      (t !== null && (n = t.retryLane), gf(e, n));
    }
    function vf(e, t) {
      var n = 0;
      switch (e.tag) {
        case 31:
        case 13:
          var r = e.stateNode,
            a = e.memoizedState;
          a !== null && (n = a.retryLane);
          break;
        case 19:
          r = e.stateNode;
          break;
        case 22:
          r = e.stateNode._retryCache;
          break;
        default:
          throw Error(i(314));
      }
      (r !== null && r.delete(t), gf(e, n));
    }
    function yf(e, t) {
      return Ge(e, t);
    }
    var bf = null,
      xf = null,
      Sf = !1,
      Cf = !1,
      wf = !1,
      Tf = 0;
    function Ef(e) {
      (e !== xf &&
        e.next === null &&
        (xf === null ? (bf = xf = e) : (xf = xf.next = e)),
        (Cf = !0),
        Sf || ((Sf = !0), Nf()));
    }
    function Df(e, t) {
      if (!wf && Cf) {
        wf = !0;
        do
          for (var n = !1, r = bf; r !== null;) {
            if (!t) {
              if (e !== 0) {
                var i = r.pendingLanes;
                if (i === 0) var a = 0;
                else {
                  var o = r.suspendedLanes,
                    s = r.pingedLanes;
                  ((a = (1 << (31 - st(42 | e) + 1)) - 1),
                    (a &= i & ~(o & ~s)),
                    (a = a & 201326741 ? (a & 201326741) | 1 : a ? a | 2 : 0));
                }
                a !== 0 && ((n = !0), Mf(r, a));
              } else
                ((a = q),
                  (a = ht(
                    r,
                    r === G ? a : 0,
                    r.cancelPendingCommit !== null || r.timeoutHandle !== -1,
                  )),
                  !(a & 3) || gt(r, a) || ((n = !0), Mf(r, a)));
            }
            r = r.next;
          }
        while (n);
        wf = !1;
      }
    }
    function Of() {
      kf();
    }
    function kf() {
      Cf = Sf = !1;
      var e = 0;
      Tf !== 0 && hp() && (e = Tf);
      for (var t = Ye(), n = null, r = bf; r !== null;) {
        var i = r.next,
          a = Af(r, t);
        (a === 0
          ? ((r.next = null),
            n === null ? (bf = i) : (n.next = i),
            i === null && (xf = n))
          : ((n = r), (e !== 0 || a & 3) && (Cf = !0)),
          (r = i));
      }
      ((X !== 0 && X !== 5) || Df(e, !1), Tf !== 0 && (Tf = 0));
    }
    function Af(e, t) {
      for (
        var n = e.suspendedLanes,
          r = e.pingedLanes,
          i = e.expirationTimes,
          a = e.pendingLanes & -62914561;
        0 < a;
      ) {
        var o = 31 - st(a),
          s = 1 << o,
          c = i[o];
        (c === -1
          ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = vt(s, t))
          : c <= t && (e.expiredLanes |= s),
          (a &= ~s));
      }
      if (
        ((t = G),
        (n = q),
        (n = ht(
          e,
          e === t ? n : 0,
          e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
        )),
        (r = e.callbackNode),
        n === 0 ||
          (e === t && (J === 2 || J === 9)) ||
          e.cancelPendingCommit !== null)
      )
        return (
          r !== null && r !== null && Ke(r),
          (e.callbackNode = null),
          (e.callbackPriority = 0)
        );
      if (!(n & 3) || gt(e, n)) {
        if (((t = n & -n), t === e.callbackPriority)) return t;
        switch ((r !== null && Ke(r), Dt(n))) {
          case 2:
          case 8:
            n = Qe;
            break;
          case 32:
            n = $e;
            break;
          case 268435456:
            n = tt;
            break;
          default:
            n = $e;
        }
        return (
          (r = jf.bind(null, e)),
          (n = Ge(n, r)),
          (e.callbackPriority = t),
          (e.callbackNode = n),
          t
        );
      }
      return (
        r !== null && r !== null && Ke(r),
        (e.callbackPriority = 2),
        (e.callbackNode = null),
        2
      );
    }
    function jf(e, t) {
      if (X !== 0 && X !== 5)
        return ((e.callbackNode = null), (e.callbackPriority = 0), null);
      var n = e.callbackNode;
      if (df() && e.callbackNode !== n) return null;
      var r = q;
      return (
        (r = ht(
          e,
          e === G ? r : 0,
          e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
        )),
        r === 0
          ? null
          : (Fd(e, r, t),
            Af(e, Ye()),
            e.callbackNode != null && e.callbackNode === n
              ? jf.bind(null, e)
              : null)
      );
    }
    function Mf(e, t) {
      if (df()) return null;
      Fd(e, t, !0);
    }
    function Nf() {
      bp(function () {
        W & 6 ? Ge(Ze, Of) : kf();
      });
    }
    function Pf() {
      if (Tf === 0) {
        var e = Ua;
        (e === 0 && ((e = dt), (dt <<= 1), !(dt & 261888) && (dt = 256)),
          (Tf = e));
      }
      return Tf;
    }
    function Ff(e) {
      return e == null || typeof e == `symbol` || typeof e == `boolean`
        ? null
        : typeof e == `function`
          ? e
          : En(e);
    }
    function If(e, t, n, r, i) {
      if (t === `submit` && n && n.stateNode === i) {
        var a = Ff((i[Mt] || null).action),
          o = r.submitter;
        o &&
          ((t = (t = o[Mt] || null)
            ? Ff(t.formAction)
            : o.getAttribute(`formAction`)),
          t !== null && ((a = t), (o = null)));
        var s = new qn(`action`, `action`, null, r, i);
        e.push({
          event: s,
          listeners: [
            {
              instance: null,
              listener: function () {
                if (r.defaultPrevented) {
                  if (Tf !== 0) {
                    var e = new FormData(i, o);
                    rc(
                      n,
                      {
                        pending: !0,
                        data: e,
                        method: i.method,
                        action: a,
                      },
                      null,
                      e,
                    );
                  }
                } else
                  typeof a == `function` &&
                    (s.preventDefault(),
                    (e = new FormData(i, o)),
                    rc(
                      n,
                      {
                        pending: !0,
                        data: e,
                        method: i.method,
                        action: a,
                      },
                      a,
                      e,
                    ));
              },
              currentTarget: i,
            },
          ],
        });
      }
    }
    for (var Lf = 0; Lf < yi.length; Lf++) {
      var Rf = yi[Lf];
      bi(Rf.toLowerCase(), `on` + (Rf[0].toUpperCase() + Rf.slice(1)));
    }
    (bi(di, `onAnimationEnd`),
      bi(fi, `onAnimationIteration`),
      bi(pi, `onAnimationStart`),
      bi(`dblclick`, `onDoubleClick`),
      bi(`focusin`, `onFocus`),
      bi(`focusout`, `onBlur`),
      bi(mi, `onTransitionRun`),
      bi(hi, `onTransitionStart`),
      bi(gi, `onTransitionCancel`),
      bi(_i, `onTransitionEnd`),
      Xt(`onMouseEnter`, [`mouseout`, `mouseover`]),
      Xt(`onMouseLeave`, [`mouseout`, `mouseover`]),
      Xt(`onPointerEnter`, [`pointerout`, `pointerover`]),
      Xt(`onPointerLeave`, [`pointerout`, `pointerover`]),
      Yt(
        `onChange`,
        `change click focusin focusout input keydown keyup selectionchange`.split(
          ` `,
        ),
      ),
      Yt(
        `onSelect`,
        `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(
          ` `,
        ),
      ),
      Yt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]),
      Yt(
        `onCompositionEnd`,
        `compositionend focusout keydown keypress keyup mousedown`.split(` `),
      ),
      Yt(
        `onCompositionStart`,
        `compositionstart focusout keydown keypress keyup mousedown`.split(` `),
      ),
      Yt(
        `onCompositionUpdate`,
        `compositionupdate focusout keydown keypress keyup mousedown`.split(
          ` `,
        ),
      ));
    var zf =
        `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(
          ` `,
        ),
      Bf = new Set(
        `beforetoggle cancel close invalid load scroll scrollend toggle`
          .split(` `)
          .concat(zf),
      );
    function Vf(e, t) {
      t = !!(t & 4);
      for (var n = 0; n < e.length; n++) {
        var r = e[n],
          i = r.event;
        r = r.listeners;
        a: {
          var a = void 0;
          if (t)
            for (var o = r.length - 1; 0 <= o; o--) {
              var s = r[o],
                c = s.instance,
                l = s.currentTarget;
              if (((s = s.listener), c !== a && i.isPropagationStopped()))
                break a;
              ((a = s), (i.currentTarget = l));
              try {
                a(i);
              } catch (e) {
                Ti(e);
              }
              ((i.currentTarget = null), (a = c));
            }
          else
            for (o = 0; o < r.length; o++) {
              if (
                ((s = r[o]),
                (c = s.instance),
                (l = s.currentTarget),
                (s = s.listener),
                c !== a && i.isPropagationStopped())
              )
                break a;
              ((a = s), (i.currentTarget = l));
              try {
                a(i);
              } catch (e) {
                Ti(e);
              }
              ((i.currentTarget = null), (a = c));
            }
        }
      }
    }
    function Q(e, t) {
      var n = t[Pt];
      n === void 0 && (n = t[Pt] = new Set());
      var r = e + `__bubble`;
      n.has(r) || (Gf(t, e, 2, !1), n.add(r));
    }
    function Hf(e, t, n) {
      var r = 0;
      (t && (r |= 4), Gf(n, e, r, t));
    }
    var Uf = `_reactListening` + Math.random().toString(36).slice(2);
    function Wf(e) {
      if (!e[Uf]) {
        ((e[Uf] = !0),
          qt.forEach(function (t) {
            t !== `selectionchange` &&
              (Bf.has(t) || Hf(t, !1, e), Hf(t, !0, e));
          }));
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[Uf] || ((t[Uf] = !0), Hf(`selectionchange`, !1, t));
      }
    }
    function Gf(e, t, n, r) {
      switch (Ch(t)) {
        case 2:
          var i = _h;
          break;
        case 8:
          i = vh;
          break;
        default:
          i = yh;
      }
      ((n = i.bind(null, t, n, e)),
        (i = void 0),
        !j ||
          (t !== `touchstart` && t !== `touchmove` && t !== `wheel`) ||
          (i = !0),
        r
          ? i === void 0
            ? e.addEventListener(t, n, !0)
            : e.addEventListener(t, n, {
                capture: !0,
                passive: i,
              })
          : i === void 0
            ? e.addEventListener(t, n, !1)
            : e.addEventListener(t, n, {
                passive: i,
              }));
    }
    function Kf(e, t, n, r, i) {
      var a = r;
      if (!(t & 1) && !(t & 2) && r !== null)
        a: for (;;) {
          if (r === null) return;
          var s = r.tag;
          if (s === 3 || s === 4) {
            var c = r.stateNode.containerInfo;
            if (c === i) break;
            if (s === 4)
              for (s = r.return; s !== null;) {
                var l = s.tag;
                if ((l === 3 || l === 4) && s.stateNode.containerInfo === i)
                  return;
                s = s.return;
              }
            for (; c !== null;) {
              if (((s = Vt(c)), s === null)) return;
              if (((l = s.tag), l === 5 || l === 6 || l === 26 || l === 27)) {
                r = a = s;
                continue a;
              }
              c = c.parentNode;
            }
          }
          r = r.return;
        }
      Pn(function () {
        var r = a,
          i = kn(n),
          s = [];
        a: {
          var c = vi.get(e);
          if (c !== void 0) {
            var l = qn,
              u = e;
            switch (e) {
              case `keypress`:
                if (Hn(n) === 0) break a;
              case `keydown`:
              case `keyup`:
                l = cr;
                break;
              case `focusin`:
                ((u = `focus`), (l = $n));
                break;
              case `focusout`:
                ((u = `blur`), (l = $n));
                break;
              case `beforeblur`:
              case `afterblur`:
                l = $n;
                break;
              case `click`:
                if (n.button === 2) break a;
              case `auxclick`:
              case `dblclick`:
              case `mousedown`:
              case `mousemove`:
              case `mouseup`:
              case `mouseout`:
              case `mouseover`:
              case `contextmenu`:
                l = Zn;
                break;
              case `drag`:
              case `dragend`:
              case `dragenter`:
              case `dragexit`:
              case `dragleave`:
              case `dragover`:
              case `dragstart`:
              case `drop`:
                l = Qn;
                break;
              case `touchcancel`:
              case `touchend`:
              case `touchmove`:
              case `touchstart`:
                l = dr;
                break;
              case di:
              case fi:
              case pi:
                l = er;
                break;
              case _i:
                l = fr;
                break;
              case `scroll`:
              case `scrollend`:
                l = Yn;
                break;
              case `wheel`:
                l = pr;
                break;
              case `copy`:
              case `cut`:
              case `paste`:
                l = tr;
                break;
              case `gotpointercapture`:
              case `lostpointercapture`:
              case `pointercancel`:
              case `pointerdown`:
              case `pointermove`:
              case `pointerout`:
              case `pointerover`:
              case `pointerup`:
                l = lr;
                break;
              case `submit`:
                l = ur;
                break;
              case `toggle`:
              case `beforetoggle`:
                l = mr;
            }
            var d = !!(t & 4),
              f = !d && (e === `scroll` || e === `scrollend`),
              p = d ? (c === null ? null : c + `Capture`) : c;
            d = [];
            for (var m = r, h; m !== null;) {
              var g = m;
              if (
                ((h = g.stateNode),
                (g = g.tag),
                (g !== 5 && g !== 26 && g !== 27) ||
                  h === null ||
                  p === null ||
                  ((g = Fn(m, p)), g != null && d.push(qf(m, g, h))),
                f)
              )
                break;
              m = m.return;
            }
            0 < d.length &&
              ((c = new l(c, u, null, n, i)),
              s.push({
                event: c,
                listeners: d,
              }));
          }
        }
        if (!(t & 7)) {
          a: {
            if (
              ((l = e === `mouseover` || e === `pointerover`),
              (c = e === `mouseout` || e === `pointerout`),
              l &&
                n !== On &&
                (u = n.relatedTarget || n.fromElement) &&
                (Vt(u) || u[Nt]))
            )
              break a;
            (c || l) &&
              ((u =
                i.window === i
                  ? i
                  : (l = i.ownerDocument)
                    ? l.defaultView || l.parentWindow
                    : window),
              c
                ? ((l = n.relatedTarget || n.toElement),
                  (c = r),
                  (l = l ? Vt(l) : null),
                  l !== null &&
                    ((f = o(l)),
                    (d = l.tag),
                    l !== f || (d !== 5 && d !== 27 && d !== 6)) &&
                    (l = null))
                : ((c = null), (l = r)),
              c !== l &&
                ((d = Zn),
                (g = `onMouseLeave`),
                (p = `onMouseEnter`),
                (m = `mouse`),
                (e === `pointerout` || e === `pointerover`) &&
                  ((d = lr),
                  (g = `onPointerLeave`),
                  (p = `onPointerEnter`),
                  (m = `pointer`)),
                (f = c == null ? u : Ut(c)),
                (h = l == null ? u : Ut(l)),
                (u = new d(g, m + `leave`, c, n, i)),
                (u.target = f),
                (u.relatedTarget = h),
                (g = null),
                Vt(i) === r &&
                  ((d = new d(p, m + `enter`, l, n, i)),
                  (d.target = h),
                  (d.relatedTarget = f),
                  (g = d)),
                (f = g),
                (d = c && l ? re(c, l, Yf) : null),
                c !== null && Xf(s, u, c, d, !1),
                l !== null && f !== null && Xf(s, f, l, d, !0)));
          }
          a: {
            if (
              ((c = r ? Ut(r) : window),
              (l = c.nodeName && c.nodeName.toLowerCase()),
              l === `select` || (l === `input` && c.type === `file`))
            )
              var _ = Pr;
            else if (Or(c)) {
              if (Fr) _ = Wr;
              else {
                _ = Hr;
                var v = Vr;
              }
            } else
              ((l = c.nodeName),
                !l ||
                l.toLowerCase() !== `input` ||
                (c.type !== `checkbox` && c.type !== `radio`)
                  ? r && Cn(r.elementType) && (_ = Pr)
                  : (_ = Ur));
            if ((_ &&= _(e, r))) {
              kr(s, _, n, i);
              break a;
            }
            v && v(e, c, r);
          }
          switch (((v = r ? Ut(r) : window), e)) {
            case `focusin`:
              (Or(v) || v.contentEditable === `true`) &&
                ((ti = v), (ni = r), (ri = null));
              break;
            case `focusout`:
              ri = ni = ti = null;
              break;
            case `mousedown`:
              ii = !0;
              break;
            case `contextmenu`:
            case `mouseup`:
            case `dragend`:
              ((ii = !1), ai(s, n, i));
              break;
            case `selectionchange`:
              if (ei) break;
            case `keydown`:
            case `keyup`:
              ai(s, n, i);
          }
          var y;
          if (gr)
            b: {
              switch (e) {
                case `compositionstart`:
                  var b = `onCompositionStart`;
                  break b;
                case `compositionend`:
                  b = `onCompositionEnd`;
                  break b;
                case `compositionupdate`:
                  b = `onCompositionUpdate`;
                  break b;
              }
              b = void 0;
            }
          else
            wr
              ? Sr(e, n) && (b = `onCompositionEnd`)
              : e === `keydown` &&
                n.keyCode === 229 &&
                (b = `onCompositionStart`);
          (b &&
            (yr &&
              n.locale !== `ko` &&
              (wr || b !== `onCompositionStart`
                ? b === `onCompositionEnd` && wr && (y = Vn())
                : ((Rn = i),
                  (zn = `value` in Rn ? Rn.value : Rn.textContent),
                  (wr = !0))),
            (v = Jf(r, b)),
            0 < v.length &&
              ((b = new nr(b, e, null, n, i)),
              s.push({
                event: b,
                listeners: v,
              }),
              y ? (b.data = y) : ((y = Cr(n)), y !== null && (b.data = y)))),
            (y = vr ? Tr(e, n) : Er(e, n)) &&
              ((b = Jf(r, `onBeforeInput`)),
              0 < b.length &&
                ((v = new nr(`onBeforeInput`, `beforeinput`, null, n, i)),
                s.push({
                  event: v,
                  listeners: b,
                }),
                (v.data = y))),
            If(s, e, r, n, i));
        }
        Vf(s, t);
      });
    }
    function qf(e, t, n) {
      return {
        instance: e,
        listener: t,
        currentTarget: n,
      };
    }
    function Jf(e, t) {
      for (var n = t + `Capture`, r = []; e !== null;) {
        var i = e,
          a = i.stateNode;
        if (
          ((i = i.tag),
          (i !== 5 && i !== 26 && i !== 27) ||
            a === null ||
            ((i = Fn(e, n)),
            i != null && r.unshift(qf(e, i, a)),
            (i = Fn(e, t)),
            i != null && r.push(qf(e, i, a))),
          e.tag === 3)
        )
          return r;
        e = e.return;
      }
      return [];
    }
    function Yf(e) {
      if (e === null) return null;
      do e = e.return;
      while (e && e.tag !== 5 && e.tag !== 27);
      return e || null;
    }
    function Xf(e, t, n, r, i) {
      for (var a = t._reactName, o = []; n !== null && n !== r;) {
        var s = n,
          c = s.alternate,
          l = s.stateNode;
        if (((s = s.tag), c !== null && c === r)) break;
        ((s !== 5 && s !== 26 && s !== 27) ||
          l === null ||
          ((c = l),
          i
            ? ((l = Fn(n, a)), l != null && o.unshift(qf(n, l, c)))
            : i || ((l = Fn(n, a)), l != null && o.push(qf(n, l, c)))),
          (n = n.return));
      }
      o.length !== 0 &&
        e.push({
          event: t,
          listeners: o,
        });
    }
    var Zf = /\r\n?/g,
      Qf = /\u0000|\uFFFD/g;
    function $f(e) {
      return (typeof e == `string` ? e : `` + e)
        .replace(
          Zf,
          `
    `,
        )
        .replace(Qf, ``);
    }
    function ep(e, t) {
      return ((t = $f(t)), $f(e) === t);
    }
    function $(e, t, n, r, a, o) {
      switch (n) {
        case `children`:
          if (typeof r == `string`)
            t === `body` || (t === `textarea` && r === ``) || yn(e, r);
          else if (typeof r == `number` || typeof r == `bigint`)
            t !== `body` && yn(e, `` + r);
          else return;
          break;
        case `className`:
          rn(e, `class`, r);
          break;
        case `tabIndex`:
          rn(e, `tabindex`, r);
          break;
        case `dir`:
        case `role`:
        case `viewBox`:
        case `width`:
        case `height`:
          rn(e, n, r);
          break;
        case `style`:
          Sn(e, r, o);
          return;
        case `data`:
          if (t !== `object`) {
            rn(e, `data`, r);
            break;
          }
        case `src`:
        case `href`:
          if (r === `` && (t !== `a` || n !== `href`)) {
            e.removeAttribute(n);
            break;
          }
          if (
            r == null ||
            typeof r == `function` ||
            typeof r == `symbol` ||
            typeof r == `boolean`
          ) {
            e.removeAttribute(n);
            break;
          }
          ((r = En(r)), e.setAttribute(n, r));
          break;
        case `action`:
        case `formAction`:
          if (typeof r == `function`) {
            e.setAttribute(
              n,
              `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`,
            );
            break;
          }
          if (
            (typeof o == `function` &&
              (n === `formAction`
                ? (t !== `input` && $(e, t, `name`, a.name, a, null),
                  $(e, t, `formEncType`, a.formEncType, a, null),
                  $(e, t, `formMethod`, a.formMethod, a, null),
                  $(e, t, `formTarget`, a.formTarget, a, null))
                : ($(e, t, `encType`, a.encType, a, null),
                  $(e, t, `method`, a.method, a, null),
                  $(e, t, `target`, a.target, a, null))),
            r == null || typeof r == `symbol` || typeof r == `boolean`)
          ) {
            e.removeAttribute(n);
            break;
          }
          ((r = En(r)), e.setAttribute(n, r));
          break;
        case `onClick`:
          r != null && (e.onclick = Dn);
          return;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          return;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          return;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (((n = r.__html), n != null)) {
              if (a.children != null) throw Error(i(60));
              o?.__html !== n && (e.innerHTML = n);
            }
          }
          break;
        case `multiple`:
          e.multiple = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `muted`:
          e.muted = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `defaultValue`:
        case `defaultChecked`:
        case `innerHTML`:
        case `ref`:
          break;
        case `autoFocus`:
          break;
        case `xlinkHref`:
          if (
            r == null ||
            typeof r == `function` ||
            typeof r == `boolean` ||
            typeof r == `symbol`
          ) {
            e.removeAttribute(`xlink:href`);
            break;
          }
          ((n = En(r)),
            e.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n));
          break;
        case `contentEditable`:
        case `spellCheck`:
        case `draggable`:
        case `value`:
        case `autoReverse`:
        case `externalResourcesRequired`:
        case `focusable`:
        case `preserveAlpha`:
          r != null && typeof r != `function` && typeof r != `symbol`
            ? e.setAttribute(n, r)
            : e.removeAttribute(n);
          break;
        case `inert`:
        case `allowFullScreen`:
        case `async`:
        case `autoPlay`:
        case `controls`:
        case `credentialless`:
        case `default`:
        case `defer`:
        case `disabled`:
        case `disablePictureInPicture`:
        case `disableRemotePlayback`:
        case `formNoValidate`:
        case `hidden`:
        case `loop`:
        case `noModule`:
        case `noValidate`:
        case `open`:
        case `playsInline`:
        case `readOnly`:
        case `required`:
        case `reversed`:
        case `scoped`:
        case `seamless`:
        case `itemScope`:
          r && typeof r != `function` && typeof r != `symbol`
            ? e.setAttribute(n, ``)
            : e.removeAttribute(n);
          break;
        case `capture`:
        case `download`:
          !0 === r
            ? e.setAttribute(n, ``)
            : !1 !== r &&
                r != null &&
                typeof r != `function` &&
                typeof r != `symbol`
              ? e.setAttribute(n, r)
              : e.removeAttribute(n);
          break;
        case `cols`:
        case `rows`:
        case `size`:
        case `span`:
          r != null &&
          typeof r != `function` &&
          typeof r != `symbol` &&
          !isNaN(r) &&
          1 <= r
            ? e.setAttribute(n, r)
            : e.removeAttribute(n);
          break;
        case `rowSpan`:
        case `start`:
          r == null ||
          typeof r == `function` ||
          typeof r == `symbol` ||
          isNaN(r)
            ? e.removeAttribute(n)
            : e.setAttribute(n, r);
          break;
        case `popover`:
          (Q(`beforetoggle`, e), Q(`toggle`, e), nn(e, `popover`, r));
          break;
        case `xlinkActuate`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r);
          break;
        case `xlinkArcrole`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r);
          break;
        case `xlinkRole`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:role`, r);
          break;
        case `xlinkShow`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:show`, r);
          break;
        case `xlinkTitle`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:title`, r);
          break;
        case `xlinkType`:
          an(e, `http://www.w3.org/1999/xlink`, `xlink:type`, r);
          break;
        case `xmlBase`:
          an(e, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r);
          break;
        case `xmlLang`:
          an(e, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r);
          break;
        case `xmlSpace`:
          an(e, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r);
          break;
        case `is`:
          nn(e, `is`, r);
          break;
        case `innerText`:
        case `textContent`:
          return;
        default:
          if (
            !(2 < n.length) ||
            (n[0] !== `o` && n[0] !== `O`) ||
            (n[1] !== `n` && n[1] !== `N`)
          )
            ((n = wn.get(n) || n), nn(e, n, r));
          else return;
      }
      A = !0;
    }
    function tp(e, t, n, r, a, o) {
      switch (n) {
        case `style`:
          Sn(e, r, o);
          return;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (((n = r.__html), n != null)) {
              if (a.children != null) throw Error(i(60));
              o?.__html !== n && (e.innerHTML = n);
            }
          }
          break;
        case `children`:
          if (typeof r == `string`) yn(e, r);
          else if (typeof r == `number` || typeof r == `bigint`) yn(e, `` + r);
          else return;
          break;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          return;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          return;
        case `onClick`:
          r != null && (e.onclick = Dn);
          return;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `innerHTML`:
        case `ref`:
          return;
        case `innerText`:
        case `textContent`:
          return;
        default:
          if (!Jt.hasOwnProperty(n))
            a: {
              if (
                n[0] === `o` &&
                n[1] === `n` &&
                ((a = n.endsWith(`Capture`)),
                (o = n.slice(2, a ? n.length - 7 : void 0)),
                (t = e[Mt] || null),
                (t = t == null ? null : t[n]),
                typeof t == `function` && e.removeEventListener(o, t, a),
                typeof r == `function`)
              ) {
                (typeof t != `function` &&
                  t !== null &&
                  (n in e
                    ? (e[n] = null)
                    : e.hasAttribute(n) && e.removeAttribute(n)),
                  e.addEventListener(o, r, a));
                break a;
              }
              ((A = !0),
                n in e
                  ? (e[n] = r)
                  : !0 === r
                    ? e.setAttribute(n, ``)
                    : nn(e, n, r));
            }
          return;
      }
      A = !0;
    }
    function np(e, t, n) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `img`:
          (Q(`error`, e), Q(`load`, e));
          var r = !1,
            a = !1,
            o;
          for (o in n)
            if (n.hasOwnProperty(o)) {
              var s = n[o];
              if (s != null)
                switch (o) {
                  case `src`:
                    r = !0;
                    break;
                  case `srcSet`:
                    a = !0;
                    break;
                  case `children`:
                  case `dangerouslySetInnerHTML`:
                    throw Error(i(137, t));
                  default:
                    $(e, t, o, s, n, null);
                }
            }
          (a && $(e, t, `srcSet`, n.srcSet, n, null),
            r && $(e, t, `src`, n.src, n, null));
          return;
        case `input`:
          Q(`invalid`, e);
          var c = (o = s = a = null),
            l = null,
            u = null;
          for (r in n)
            if (n.hasOwnProperty(r)) {
              var d = n[r];
              if (d != null)
                switch (r) {
                  case `name`:
                    a = d;
                    break;
                  case `type`:
                    s = d;
                    break;
                  case `checked`:
                    l = d;
                    break;
                  case `defaultChecked`:
                    u = d;
                    break;
                  case `value`:
                    o = d;
                    break;
                  case `defaultValue`:
                    c = d;
                    break;
                  case `children`:
                  case `dangerouslySetInnerHTML`:
                    if (d != null) throw Error(i(137, t));
                    break;
                  default:
                    $(e, t, r, d, n, null);
                }
            }
          mn(e, o, c, l, u, s, a, !1);
          return;
        case `select`:
          for (a in (Q(`invalid`, e), (r = s = o = null), n))
            if (n.hasOwnProperty(a) && ((c = n[a]), c != null))
              switch (a) {
                case `value`:
                  o = c;
                  break;
                case `defaultValue`:
                  s = c;
                  break;
                case `multiple`:
                  r = c;
                default:
                  $(e, t, a, c, n, null);
              }
          ((t = o),
            (n = s),
            (e.multiple = !!r),
            t == null ? n != null && gn(e, !!r, n, !0) : gn(e, !!r, t, !1));
          return;
        case `textarea`:
          for (s in (Q(`invalid`, e), (o = a = r = null), n))
            if (n.hasOwnProperty(s) && ((c = n[s]), c != null))
              switch (s) {
                case `value`:
                  r = c;
                  break;
                case `defaultValue`:
                  a = c;
                  break;
                case `children`:
                  o = c;
                  break;
                case `dangerouslySetInnerHTML`:
                  if (c != null) throw Error(i(91));
                  break;
                default:
                  $(e, t, s, c, n, null);
              }
          vn(e, r, a, o);
          return;
        case `option`:
          for (l in n)
            if (n.hasOwnProperty(l) && ((r = n[l]), r != null))
              switch (l) {
                case `selected`:
                  e.selected =
                    r && typeof r != `function` && typeof r != `symbol`;
                  break;
                default:
                  $(e, t, l, r, n, null);
              }
          return;
        case `dialog`:
          (Q(`beforetoggle`, e), Q(`toggle`, e), Q(`cancel`, e), Q(`close`, e));
          break;
        case `iframe`:
        case `object`:
          Q(`load`, e);
          break;
        case `video`:
        case `audio`:
          for (r = 0; r < zf.length; r++) Q(zf[r], e);
          break;
        case `image`:
          (Q(`error`, e), Q(`load`, e));
          break;
        case `details`:
          Q(`toggle`, e);
          break;
        case `embed`:
        case `source`:
        case `link`:
          (Q(`error`, e), Q(`load`, e));
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (u in n)
            if (n.hasOwnProperty(u) && ((r = n[u]), r != null))
              switch (u) {
                case `children`:
                case `dangerouslySetInnerHTML`:
                  throw Error(i(137, t));
                default:
                  $(e, t, u, r, n, null);
              }
          return;
        default:
          if (Cn(t)) {
            for (d in n)
              n.hasOwnProperty(d) &&
                ((r = n[d]), r !== void 0 && tp(e, t, d, r, n, void 0));
            return;
          }
      }
      for (c in n)
        n.hasOwnProperty(c) &&
          ((r = n[c]), r != null && $(e, t, c, r, n, null));
    }
    var rp = {};
    function ip(e, t, n, r) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `input`:
          var a = null,
            o = null,
            s = null,
            c = null,
            l = null,
            u = null,
            d = null;
          for (m in n) {
            var f = n[m];
            if (n.hasOwnProperty(m) && f != null)
              switch (m) {
                case `checked`:
                  break;
                case `value`:
                  break;
                case `defaultValue`:
                  l = f;
                default:
                  r.hasOwnProperty(m) || $(e, t, m, null, r, f);
              }
          }
          for (var p in r) {
            var m = r[p];
            if (((f = n[p]), r.hasOwnProperty(p) && (m != null || f != null)))
              switch (p) {
                case `type`:
                  (m !== f && (A = !0), (o = m));
                  break;
                case `name`:
                  (m !== f && (A = !0), (a = m));
                  break;
                case `checked`:
                  (m !== f && (A = !0), (u = m));
                  break;
                case `defaultChecked`:
                  (m !== f && (A = !0), (d = m));
                  break;
                case `value`:
                  (m !== f && (A = !0), (s = m));
                  break;
                case `defaultValue`:
                  (m !== f && (A = !0), (c = m));
                  break;
                case `children`:
                case `dangerouslySetInnerHTML`:
                  if (m != null) throw Error(i(137, t));
                  break;
                default:
                  m !== f && $(e, t, p, m, r, f);
              }
          }
          pn(e, s, c, l, u, d, o, a);
          return;
        case `select`:
          for (o in ((m = s = c = p = null), n))
            if (((l = n[o]), n.hasOwnProperty(o) && l != null))
              switch (o) {
                case `value`:
                  break;
                case `multiple`:
                  m = l;
                default:
                  r.hasOwnProperty(o) || $(e, t, o, null, r, l);
              }
          for (a in r)
            if (
              ((o = r[a]),
              (l = n[a]),
              r.hasOwnProperty(a) && (o != null || l != null))
            )
              switch (a) {
                case `value`:
                  (o !== l && (A = !0), (p = o));
                  break;
                case `defaultValue`:
                  (o !== l && (A = !0), (c = o));
                  break;
                case `multiple`:
                  (o !== l && (A = !0), (s = o));
                default:
                  o !== l && $(e, t, a, o, r, l);
              }
          ((t = c),
            (n = s),
            (r = m),
            p == null
              ? !!r != !!n &&
                (t == null ? gn(e, !!n, n ? [] : ``, !1) : gn(e, !!n, t, !0))
              : gn(e, !!n, p, !1));
          return;
        case `textarea`:
          for (c in ((m = p = null), n))
            if (
              ((a = n[c]),
              n.hasOwnProperty(c) && a != null && !r.hasOwnProperty(c))
            )
              switch (c) {
                case `value`:
                  break;
                case `children`:
                  break;
                default:
                  $(e, t, c, null, r, a);
              }
          for (s in r)
            if (
              ((a = r[s]),
              (o = n[s]),
              r.hasOwnProperty(s) && (a != null || o != null))
            )
              switch (s) {
                case `value`:
                  (a !== o && (A = !0), (p = a));
                  break;
                case `defaultValue`:
                  (a !== o && (A = !0), (m = a));
                  break;
                case `children`:
                  break;
                case `dangerouslySetInnerHTML`:
                  if (a != null) throw Error(i(91));
                  break;
                default:
                  a !== o && $(e, t, s, a, r, o);
              }
          _n(e, p, m);
          return;
        case `option`:
          for (var h in n)
            if (
              ((p = n[h]),
              n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h))
            )
              switch (h) {
                case `selected`:
                  e.selected = !1;
                  break;
                default:
                  $(e, t, h, null, r, p);
              }
          for (l in r)
            if (
              ((p = r[l]),
              (m = n[l]),
              r.hasOwnProperty(l) && p !== m && (p != null || m != null))
            )
              switch (l) {
                case `selected`:
                  (p !== m && (A = !0),
                    (e.selected =
                      p && typeof p != `function` && typeof p != `symbol`));
                  break;
                default:
                  $(e, t, l, p, r, m);
              }
          return;
        case `img`:
        case `link`:
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `embed`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `source`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (var g in n)
            ((p = n[g]),
              n.hasOwnProperty(g) &&
                p != null &&
                !r.hasOwnProperty(g) &&
                $(e, t, g, null, r, p));
          for (u in r)
            if (
              ((p = r[u]),
              (m = n[u]),
              r.hasOwnProperty(u) && p !== m && (p != null || m != null))
            )
              switch (u) {
                case `children`:
                case `dangerouslySetInnerHTML`:
                  if (p != null) throw Error(i(137, t));
                  break;
                default:
                  $(e, t, u, p, r, m);
              }
          return;
        default:
          if (Cn(t)) {
            for (var _ in n)
              ((p = n[_]),
                n.hasOwnProperty(_) &&
                  p !== void 0 &&
                  !r.hasOwnProperty(_) &&
                  tp(e, t, _, void 0, r, p));
            for (d in r)
              ((p = r[d]),
                (m = n[d]),
                !r.hasOwnProperty(d) ||
                  p === m ||
                  (p === void 0 && m === void 0) ||
                  tp(e, t, d, p, r, m));
            return;
          }
      }
      for (var v in n)
        ((p = n[v]),
          n.hasOwnProperty(v) &&
            p != null &&
            !r.hasOwnProperty(v) &&
            $(e, t, v, null, r, p));
      for (f in r)
        ((p = r[f]),
          (m = n[f]),
          !r.hasOwnProperty(f) ||
            p === m ||
            (p == null && m == null) ||
            $(e, t, f, p, r, m));
    }
    function ap(e) {
      switch (e) {
        case `css`:
        case `script`:
        case `font`:
        case `img`:
        case `image`:
        case `input`:
        case `link`:
          return !0;
        default:
          return !1;
      }
    }
    function op() {
      if (typeof performance.getEntriesByType == `function`) {
        for (
          var e = 0, t = 0, n = performance.getEntriesByType(`resource`), r = 0;
          r < n.length;
          r++
        ) {
          var i = n[r],
            a = i.transferSize,
            o = i.initiatorType,
            s = i.duration;
          if (a && s && ap(o)) {
            for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
              var c = n[r],
                l = c.startTime;
              if (l > s) break;
              var u = c.transferSize,
                d = c.initiatorType;
              u &&
                ap(d) &&
                ((c = c.responseEnd),
                (o += u * (c < s ? 1 : (s - l) / (c - l))));
            }
            if ((--r, (t += (8 * (a + o)) / (i.duration / 1e3)), e++, 10 < e))
              break;
          }
        }
        if (0 < e) return t / e / 1e6;
      }
      return navigator.connection &&
        ((e = navigator.connection.downlink), typeof e == `number`)
        ? e
        : 5;
    }
    var sp = null,
      cp = null;
    function lp(e) {
      return e.nodeType === 9 ? e : e.ownerDocument;
    }
    function up(e) {
      switch (e) {
        case `http://www.w3.org/2000/svg`:
          return 1;
        case `http://www.w3.org/1998/Math/MathML`:
          return 2;
        default:
          return 0;
      }
    }
    function dp(e, t) {
      if (e === 0)
        switch (t) {
          case `svg`:
            return 1;
          case `math`:
            return 2;
          default:
            return 0;
        }
      return e === 1 && t === `foreignObject` ? 0 : e;
    }
    function fp(e, t, n, r) {
      return (
        (n = lp(n).createElement(e)),
        (n[jt] = r),
        (n[Mt] = t),
        np(n, e, t),
        Gt(n),
        n
      );
    }
    function pp(e, t) {
      return (
        e === `textarea` ||
        e === `noscript` ||
        typeof t.children == `string` ||
        typeof t.children == `number` ||
        typeof t.children == `bigint` ||
        (typeof t.dangerouslySetInnerHTML == `object` &&
          t.dangerouslySetInnerHTML !== null &&
          t.dangerouslySetInnerHTML.__html != null)
      );
    }
    var mp = null;
    function hp() {
      var e = window.event;
      return e && e.type === `popstate`
        ? e !== mp && ((mp = e), !0)
        : ((mp = null), !1);
    }
    var gp = typeof setTimeout == `function` ? setTimeout : void 0,
      _p = typeof clearTimeout == `function` ? clearTimeout : void 0,
      vp = typeof Promise == `function` ? Promise : void 0,
      yp =
        typeof requestAnimationFrame == `function` ? requestAnimationFrame : gp,
      bp =
        typeof queueMicrotask == `function`
          ? queueMicrotask
          : vp === void 0
            ? gp
            : function (e) {
                return vp.resolve(null).then(e).catch(xp);
              };
    function xp(e) {
      setTimeout(function () {
        throw e;
      });
    }
    function Sp(e) {
      return e === `head`;
    }
    function Cp(e, t) {
      var n = t,
        r = 0;
      do {
        var i = n.nextSibling;
        if ((e.removeChild(n), i && i.nodeType === 8)) {
          if (((n = i.data), n === `/$` || n === `/&`)) {
            if (r === 0) {
              (e.removeChild(i), Hh(t));
              return;
            }
            r--;
          } else if (
            n === `$` ||
            n === `$?` ||
            n === `$~` ||
            n === `$!` ||
            n === `&`
          )
            r++;
          else if (n === `html`) _m(e.ownerDocument.documentElement);
          else if (n === `head`) {
            ((n = e.ownerDocument.head), _m(n));
            for (var a = n.firstChild; a;) {
              var o = a.nextSibling,
                s = a.nodeName;
              (a[Rt] ||
                s === `SCRIPT` ||
                s === `STYLE` ||
                (s === `LINK` && a.rel.toLowerCase() === `stylesheet`) ||
                n.removeChild(a),
                (a = o));
            }
          } else n === `body` && _m(e.ownerDocument.body);
        }
        n = i;
      } while (n);
      Hh(t);
    }
    function wp(e, t) {
      var n = e;
      e = 0;
      do {
        var r = n.nextSibling;
        if (
          (n.nodeType === 1
            ? t
              ? ((n._stashedDisplay = n.style.display),
                (n.style.display = `none`))
              : ((n.style.display = n._stashedDisplay || ``),
                n.getAttribute(`style`) === `` && n.removeAttribute(`style`))
            : n.nodeType === 3 &&
              (t
                ? ((n._stashedText = n.nodeValue), (n.nodeValue = ``))
                : (n.nodeValue = n._stashedText || ``)),
          r && r.nodeType === 8)
        ) {
          if (((n = r.data), n === `/$`)) {
            if (e === 0) break;
            e--;
          } else (n !== `$` && n !== `$?` && n !== `$~` && n !== `$!`) || e++;
        }
        n = r;
      } while (n);
    }
    function Tp(e, t, n) {
      if (
        ((t = CSS.escape(t) === t ? t : `r-` + btoa(t).replace(/=/g, ``)),
        (e.style.viewTransitionName = t),
        n != null && (e.style.viewTransitionClass = n),
        (n = getComputedStyle(e)),
        n.display === `inline`)
      ) {
        if (((t = e.getClientRects()), t.length === 1)) var r = 1;
        else
          for (var i = (r = 0); i < t.length; i++) {
            var a = t[i];
            0 < a.width && 0 < a.height && r++;
          }
        r === 1 &&
          ((e = e.style),
          (e.display = t.length === 1 ? `inline-block` : `block`),
          (e.marginTop = `-` + n.paddingTop),
          (e.marginBottom = `-` + n.paddingBottom));
      }
    }
    function Ep(e, t) {
      ((e = e.style), (t = t.style));
      var n =
        t == null
          ? null
          : t.hasOwnProperty(`viewTransitionName`)
            ? t.viewTransitionName
            : t.hasOwnProperty(`view-transition-name`)
              ? t[`view-transition-name`]
              : null;
      ((e.viewTransitionName =
        n == null || typeof n == `boolean` ? `` : (`` + n).trim()),
        (n =
          t == null
            ? null
            : t.hasOwnProperty(`viewTransitionClass`)
              ? t.viewTransitionClass
              : t.hasOwnProperty(`view-transition-class`)
                ? t[`view-transition-class`]
                : null),
        (e.viewTransitionClass =
          n == null || typeof n == `boolean` ? `` : (`` + n).trim()),
        e.display === `inline-block` &&
          (t == null
            ? (e.display = e.margin = ``)
            : ((n = t.display),
              (e.display = n == null || typeof n == `boolean` ? `` : n),
              (n = t.margin),
              n == null
                ? ((n = t.hasOwnProperty(`marginTop`)
                    ? t.marginTop
                    : t[`margin-top`]),
                  (e.marginTop = n == null || typeof n == `boolean` ? `` : n),
                  (t = t.hasOwnProperty(`marginBottom`)
                    ? t.marginBottom
                    : t[`margin-bottom`]),
                  (e.marginBottom =
                    t == null || typeof t == `boolean` ? `` : t))
                : (e.margin = n))));
    }
    function Dp(e, t, n) {
      return (
        (n = n.ownerDocument.defaultView),
        {
          rect: e,
          abs: t.position === `absolute` || t.position === `fixed`,
          clip:
            t.clipPath !== `none` ||
            t.overflow !== `visible` ||
            t.filter !== `none` ||
            t.mask !== `none` ||
            t.mask !== `none` ||
            t.borderRadius !== `0px`,
          view:
            0 <= e.bottom &&
            0 <= e.right &&
            e.top <= n.innerHeight &&
            e.left <= n.innerWidth,
        }
      );
    }
    function Op(e) {
      return Dp(e.getBoundingClientRect(), getComputedStyle(e), e);
    }
    function kp(e) {
      var t = e.getBoundingClientRect();
      t = new DOMRect(t.x + 2e4, t.y + 2e4, t.width, t.height);
      var n = getComputedStyle(e);
      return Dp(t, n, e);
    }
    function Ap(e) {
      return e.documentElement.clientHeight;
    }
    function jp(e) {
      (this.addEventListener(`load`, e), this.addEventListener(`error`, e));
    }
    function Mp(e, t, n, r, i, a, o, s, c) {
      var l = t.nodeType === 9 ? t : t.ownerDocument;
      try {
        var u = l.startViewTransition({
          update: function () {
            var t = l.defaultView,
              n = t.navigation && t.navigation.transition,
              o = l.fonts.status;
            r();
            var s = [];
            if (
              (o === `loaded` &&
                (Ap(l), l.fonts.status === `loading` && s.push(l.fonts.ready)),
              (o = s.length),
              e !== null)
            )
              for (var c = e.suspenseyImages, u = 0, d = 0; d < c.length; d++) {
                var f = c[d];
                if (!f.complete) {
                  var p = f.getBoundingClientRect();
                  if (
                    0 < p.bottom &&
                    0 < p.right &&
                    p.top < t.innerHeight &&
                    p.left < t.innerWidth
                  ) {
                    if (((u += Xm(f)), u > $m)) {
                      s.length = o;
                      break;
                    }
                    ((f = new Promise(jp.bind(f))), s.push(f));
                  }
                }
              }
            if (0 < s.length)
              return (
                (t = Promise.race([
                  Promise.all(s),
                  new Promise(function (e) {
                    return setTimeout(e, 500);
                  }),
                ]).then(i, i)),
                (n ? Promise.allSettled([n.finished, t]) : t).then(a, a)
              );
            if ((i(), n)) return n.finished.then(a, a);
            a();
          },
          types: n,
        });
        l.__reactViewTransition = u;
        var d = [];
        return (
          u.ready.then(
            function () {
              for (
                var e = l.documentElement.getAnimations({
                    subtree: !0,
                  }),
                  t = 0;
                t < e.length;
                t++
              ) {
                var n = e[t],
                  r = n.effect,
                  i = r.pseudoElement;
                if (i != null && i.startsWith(`::view-transition`)) {
                  (d.push(n), (n = r.getKeyframes()));
                  for (var a = (i = void 0), s = !0, c = 0; c < n.length; c++) {
                    var u = n[c],
                      f = u.width;
                    if (i === void 0) i = f;
                    else if (i !== f) {
                      s = !1;
                      break;
                    }
                    if (((f = u.height), a === void 0)) a = f;
                    else if (a !== f) {
                      s = !1;
                      break;
                    }
                    (delete u.width,
                      delete u.height,
                      u.transform === `none` && delete u.transform);
                  }
                  s &&
                    i !== void 0 &&
                    a !== void 0 &&
                    (r.setKeyframes(n),
                    (s = getComputedStyle(r.target, r.pseudoElement)),
                    s.width !== i || s.height !== a) &&
                    ((s = n[0]),
                    (s.width = i),
                    (s.height = a),
                    (s = n[n.length - 1]),
                    (s.width = i),
                    (s.height = a),
                    r.setKeyframes(n));
                }
              }
              o();
            },
            function (e) {
              l.__reactViewTransition === u && (l.__reactViewTransition = null);
              try {
                if (typeof e == `object` && e)
                  switch (e.name) {
                    case `InvalidStateError`:
                      (e.message ===
                        `View transition was skipped because document visibility state is hidden.` ||
                        e.message ===
                          `Skipping view transition because document visibility state has become hidden.` ||
                        e.message ===
                          `Skipping view transition because viewport size changed.` ||
                        e.message ===
                          `Transition was aborted because of invalid state`) &&
                        (e = null);
                  }
                e !== null && c(e);
              } finally {
                (r(), i(), o());
              }
            },
          ),
          u.finished.finally(function () {
            for (var e = 0; e < d.length; e++) d[e].cancel();
            (l.__reactViewTransition === u && (l.__reactViewTransition = null),
              s());
          }),
          u
        );
      } catch {
        return (r(), i(), o(), null);
      }
    }
    function Np(e, t) {
      ((this._scope = document.documentElement),
        (this._selector = `::view-transition-` + e + `(` + t + `)`));
    }
    ((Np.prototype.animate = function (e, t) {
      return (
        (t =
          typeof t == `number`
            ? {
                duration: t,
              }
            : C({}, t)),
        (t.pseudoElement = this._selector),
        this._scope.animate(e, t)
      );
    }),
      (Np.prototype.getAnimations = function () {
        for (
          var e = this._scope,
            t = this._selector,
            n = e.getAnimations({
              subtree: !0,
            }),
            r = [],
            i = 0;
          i < n.length;
          i++
        ) {
          var a = n[i].effect;
          a !== null && a.target === e && a.pseudoElement === t && r.push(n[i]);
        }
        return r;
      }),
      (Np.prototype.getComputedStyle = function () {
        return getComputedStyle(this._scope, this._selector);
      }));
    function Pp(e) {
      return {
        name: e,
        group: new Np(`group`, e),
        imagePair: new Np(`image-pair`, e),
        old: new Np(`old`, e),
        new: new Np(`new`, e),
      };
    }
    function Fp(e) {
      ((this._fragmentFiber = e),
        (this._observers = this._eventListeners = null));
    }
    Fp.prototype.addEventListener = function (e, t, n) {
      var r = null,
        i = null;
      if (!(
        n != null &&
        typeof n != `boolean` &&
        ((r = n.signal || null), r !== null && r.aborted)
      )) {
        this._eventListeners === null && (this._eventListeners = []);
        var a = this._eventListeners;
        if (Bp(a, e, t, n) === -1) {
          var o = this,
            s = t;
          (n != null &&
            typeof n != `boolean` &&
            !0 === n.once &&
            (s = function (r) {
              (o.removeEventListener(e, t, n),
                typeof t == `function` ? t.call(this, r) : t.handleEvent(r));
            }),
            r !== null &&
              ((i = o.removeEventListener.bind(o, e, t, n)),
              r.addEventListener(`abort`, i, {
                once: !0,
              }),
              (i = r.removeEventListener.bind(r, `abort`, i))),
            (r = Rp(n)),
            a.push({
              type: e,
              listener: t,
              optionsOrUseCapture: n,
              attachedListener: s,
              cleanup: i,
            }),
            h(this._fragmentFiber.child, !1, Ip, e, s, r));
        }
        this._eventListeners = a;
      }
    };
    function Ip(e, t, n, r) {
      return (b(e).addEventListener(t, n, r), !1);
    }
    Fp.prototype.removeEventListener = function (e, t, n) {
      var r = this._eventListeners;
      if (r !== null && ((t = Bp(r, e, t, n)), t !== -1)) {
        var i = r[t];
        n = i.attachedListener;
        var a = i.cleanup;
        ((i = Rp(i.optionsOrUseCapture)),
          h(this._fragmentFiber.child, !1, Lp, e, n, i),
          r.splice(t, 1),
          a !== null && a());
      }
    };
    function Lp(e, t, n, r) {
      return (b(e).removeEventListener(t, n, r), !1);
    }
    function Rp(e) {
      return e != null &&
        typeof e != `boolean` &&
        (!0 === e.once || e.signal instanceof AbortSignal)
        ? {
            capture: e.capture,
            passive: e.passive,
          }
        : e;
    }
    function zp(e) {
      return e == null
        ? `c=0`
        : typeof e == `boolean`
          ? `c=` + (e ? `1` : `0`)
          : `c=` + (e.capture ? `1` : `0`);
    }
    function Bp(e, t, n, r) {
      if (e.length === 0) return -1;
      r = zp(r);
      for (var i = 0; i < e.length; i++) {
        var a = e[i];
        if (a.type === t && a.listener === n && zp(a.optionsOrUseCapture) === r)
          return i;
      }
      return -1;
    }
    ((Fp.prototype.dispatchEvent = function (e) {
      var t = g(this._fragmentFiber);
      if (t === null) return !0;
      t = b(t);
      var n = this._eventListeners;
      if ((n !== null && 0 < n.length) || !e.bubbles) {
        var r =
          t.nodeType === 9 ? t.createComment(``) : document.createTextNode(``);
        if (n)
          for (var i = 0; i < n.length; i++) {
            var a = n[i];
            r.addEventListener(
              a.type,
              a.attachedListener,
              Rp(a.optionsOrUseCapture),
            );
          }
        if ((t.appendChild(r), (e = r.dispatchEvent(e)), n))
          for (i = 0; i < n.length; i++)
            ((a = n[i]),
              r.removeEventListener(
                a.type,
                a.attachedListener,
                Rp(a.optionsOrUseCapture),
              ));
        return (t.removeChild(r), e);
      }
      return t.dispatchEvent(e);
    }),
      (Fp.prototype.focus = function (e) {
        h(this._fragmentFiber.child, !0, Vp, e, void 0, void 0);
      }));
    function Vp(e, t) {
      return e.tag !== 6 && ((e = b(e)), pm(e, t));
    }
    Fp.prototype.focusLast = function (e) {
      var t = [];
      h(this._fragmentFiber.child, !0, Hp, t, void 0, void 0);
      for (var n = t.length - 1; 0 <= n && !Vp(t[n], e); n--);
    };
    function Hp(e, t) {
      return (t.push(e), !1);
    }
    Fp.prototype.blur = function () {
      var e = g(this._fragmentFiber);
      e !== null &&
        ((e = b(e)),
        (e = lp(e).activeElement),
        e !== null && h(this._fragmentFiber.child, !1, Up, e, void 0, void 0));
    };
    function Up(e, t) {
      return (
        e.tag !== 6 &&
        ((e = b(e)), e === t || e.contains(t) ? (t.blur(), !0) : !1)
      );
    }
    Fp.prototype.observeUsing = function (e) {
      (this._observers === null && (this._observers = new Set()),
        this._observers.add(e),
        h(this._fragmentFiber.child, !1, Wp, e, void 0, void 0));
    };
    function Wp(e, t) {
      return e.tag !== 6 && ((e = b(e)), t.observe(e), !1);
    }
    Fp.prototype.unobserveUsing = function (e) {
      var t = this._observers;
      if (t !== null && t.has(e)) {
        (t.delete(e), h(this._fragmentFiber.child, !1, Gp, e, void 0, void 0));
        for (var n = (t = 0); n < Kp.length; n++) {
          var r = Kp[n];
          r.fragmentInstance === this && r.observer === e
            ? e.unobserve(r.instance)
            : (Kp[t++] = r);
        }
        Kp.length = t;
      }
    };
    function Gp(e, t) {
      return e.tag !== 6 && ((e = b(e)), t.unobserve(e), !1);
    }
    var Kp = [],
      qp = !1;
    function Jp(e, t, n) {
      (Kp.push({
        fragmentInstance: e,
        observer: t,
        instance: n,
      }),
        qp ||
          ((qp = !0),
          mm(function () {
            qp = !1;
            var e = Kp;
            Kp = [];
            for (var t = 0; t < e.length; t++) {
              var n = e[t];
              n.observer.unobserve(n.instance);
            }
          })));
    }
    Fp.prototype.getClientRects = function () {
      var e = [];
      return (h(this._fragmentFiber.child, !1, Yp, e, void 0, void 0), e);
    };
    function Yp(e, t) {
      if (e.tag === 6) {
        e = e.stateNode;
        var n = e.ownerDocument.createRange();
        (n.selectNodeContents(e), t.push.apply(t, n.getClientRects()));
      } else ((e = b(e)), t.push.apply(t, e.getClientRects()));
      return !1;
    }
    ((Fp.prototype.getRootNode = function (e) {
      var t = g(this._fragmentFiber);
      return t === null ? this : b(t).getRootNode(e);
    }),
      (Fp.prototype.compareDocumentPosition = function (e) {
        var t = g(this._fragmentFiber);
        if (t === null) return Node.DOCUMENT_POSITION_DISCONNECTED;
        var n = [];
        h(this._fragmentFiber.child, !1, Hp, n, void 0, void 0);
        var r = b(t);
        if (n.length === 0) {
          if (((n = r), _(this._fragmentFiber))) {
            a: {
              for (t = this._fragmentFiber.return; t !== null;) {
                if (t.tag === 4) {
                  t = t.stateNode.containerInfo;
                  break a;
                }
                if (t.tag === 3 || t.tag === 5 || t.tag === 27) break;
                t = t.return;
              }
              t = null;
            }
            t != null && (n = t);
          }
          t = this._fragmentFiber;
          var i = (r = n.compareDocumentPosition(e));
          return (
            n === e
              ? (i = Node.DOCUMENT_POSITION_CONTAINS)
              : r & Node.DOCUMENT_POSITION_CONTAINED_BY &&
                ((n = v(t)[1]),
                n === null
                  ? (i = Node.DOCUMENT_POSITION_PRECEDING)
                  : ((e = b(n).compareDocumentPosition(e)),
                    (i =
                      e === 0 || e & Node.DOCUMENT_POSITION_FOLLOWING
                        ? Node.DOCUMENT_POSITION_FOLLOWING
                        : Node.DOCUMENT_POSITION_PRECEDING))),
            (i |= Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC)
          );
        }
        ((t = b(n[0])), (i = b(n[n.length - 1])));
        var a = _(this._fragmentFiber) ? t.parentElement : r;
        if (a == null) return Node.DOCUMENT_POSITION_DISCONNECTED;
        ((r =
          a.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY),
          (a =
            a.compareDocumentPosition(i) &
            Node.DOCUMENT_POSITION_CONTAINED_BY));
        var o = t.compareDocumentPosition(e),
          s = i.compareDocumentPosition(e),
          c =
            o & Node.DOCUMENT_POSITION_CONTAINED_BY ||
            s & Node.DOCUMENT_POSITION_CONTAINED_BY;
        return (
          (s =
            r &&
            a &&
            o & Node.DOCUMENT_POSITION_FOLLOWING &&
            s & Node.DOCUMENT_POSITION_PRECEDING),
          (t =
            (r && t === e) || (a && i === e) || c || s
              ? Node.DOCUMENT_POSITION_CONTAINED_BY
              : (!r && t === e) || (!a && i === e)
                ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
                : o),
          t & Node.DOCUMENT_POSITION_DISCONNECTED ||
          t & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC ||
          Xp(t, this._fragmentFiber, n[0], n[n.length - 1], e)
            ? t
            : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
        );
      }));
    function Xp(e, t, n, r, i) {
      var a = Vt(i);
      if (e & Node.DOCUMENT_POSITION_CONTAINED_BY) {
        if ((n = !!a))
          a: {
            for (; a !== null;) {
              if (a.tag === 7 && (a === t || a.alternate === t)) {
                n = !0;
                break a;
              }
              a = a.return;
            }
            n = !1;
          }
        return n;
      }
      if (e & Node.DOCUMENT_POSITION_CONTAINS) {
        if (a === null)
          return (
            (a = i.ownerDocument),
            i === a || i === a.documentElement || i === a.body
          );
        a: {
          for (a = t, t = g(t); a !== null;) {
            if (!(
              (a.tag !== 5 && a.tag !== 3 && a.tag !== 27) ||
              (a !== t && a.alternate !== t)
            )) {
              a = !0;
              break a;
            }
            a = a.return;
          }
          a = !1;
        }
        return a;
      }
      return e & Node.DOCUMENT_POSITION_PRECEDING
        ? ((t = !!a) &&
            !(t = a === n) &&
            ((t = re(n, a, S)),
            t === null
              ? (t = !1)
              : (h(t, !0, te, a, n), (a = ee), (ee = null), (t = a !== null))),
          t)
        : e & Node.DOCUMENT_POSITION_FOLLOWING
          ? ((t = !!a) &&
              !(t = a === r) &&
              ((t = re(r, a, S)),
              t === null
                ? (t = !1)
                : (h(t, !0, ne, a, r),
                  (a = ee),
                  (x = ee = null),
                  (t = a !== null))),
            t)
          : !1;
    }
    function Zp(e, t) {
      var n = e.ownerDocument.createRange();
      (n.selectNodeContents(e),
        (e = n.getBoundingClientRect()),
        window.scrollTo(
          window.scrollX + e.left,
          t
            ? window.scrollY + e.top
            : window.scrollY + e.bottom - window.innerHeight,
        ));
    }
    Fp.prototype.scrollIntoView = function (e) {
      if (typeof e == `object`) throw Error(i(566));
      var t = [];
      h(this._fragmentFiber.child, !1, Hp, t, void 0, void 0);
      var n = !1 !== e;
      if (t.length === 0) {
        var r = v(this._fragmentFiber);
        if (
          ((r = n ? r[1] || r[0] || g(this._fragmentFiber) : r[0] || r[1]),
          r === null)
        )
          return;
        if (r.tag === 6) {
          ((e = b(r)), Zp(e, n));
          return;
        }
        if (((r = b(r)), r.nodeType !== 9)) {
          if (r.nodeType === 11) {
            ((n = `host` in r ? r.host : null),
              n !== null && n.scrollIntoView(e));
            return;
          }
          r.scrollIntoView(e);
        }
      }
      for (r = n ? t.length - 1 : 0; r !== (n ? -1 : t.length);) {
        var a = t[r];
        (a.tag === 6 ? ((a = b(a)), Zp(a, n)) : b(a).scrollIntoView(e),
          (r += n ? -1 : 1));
      }
    };
    function Qp(e, t) {
      return ((e = b(e)), $p(e, t), !1);
    }
    function $p(e, t) {
      ((e.reactFragments ??= new Set()), e.reactFragments.add(t));
    }
    function em(e, t) {
      var n = t._eventListeners;
      if (n !== null)
        for (var r = 0; r < n.length; r++) {
          var i = n[r];
          e.addEventListener(
            i.type,
            i.attachedListener,
            Rp(i.optionsOrUseCapture),
          );
        }
      e.nodeType !== 3 &&
        ((n = t._observers),
        n !== null &&
          n.forEach(function (n) {
            for (var r = 0, i = 0; i < Kp.length; i++) {
              var a = Kp[i];
              (a.fragmentInstance !== t ||
                a.observer !== n ||
                a.instance !== e) &&
                (Kp[r++] = a);
            }
            ((Kp.length = r), n.observe(e));
          }),
        $p(e, t));
    }
    function tm(e, t) {
      var n = t._eventListeners;
      if (n !== null)
        for (var r = 0; r < n.length; r++) {
          var i = n[r];
          e.removeEventListener(
            i.type,
            i.attachedListener,
            Rp(i.optionsOrUseCapture),
          );
        }
      e.nodeType !== 3 &&
        ((n = t._observers),
        n !== null &&
          n.forEach(function (n) {
            typeof n.rootMargin == `string` ? Jp(t, n, e) : n.unobserve(e);
          }),
        e.reactFragments != null && e.reactFragments.delete(t));
    }
    function nm(e) {
      var t = e.firstChild;
      for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
        var n = t;
        switch (((t = t.nextSibling), n.nodeName)) {
          case `HTML`:
          case `HEAD`:
          case `BODY`:
            (nm(n), Bt(n));
            continue;
          case `SCRIPT`:
          case `STYLE`:
            continue;
          case `LINK`:
            if (n.rel.toLowerCase() === `stylesheet`) continue;
        }
        e.removeChild(n);
      }
    }
    function rm(e, t, n, r) {
      for (; e.nodeType === 1;) {
        var i = n;
        if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
          if (!r && (e.nodeName !== `INPUT` || e.type !== `hidden`)) break;
        } else if (!r) {
          if (t === `input` && e.type === `hidden`) {
            var a = i.name == null ? null : `` + i.name;
            if (i.type === `hidden` && e.getAttribute(`name`) === a) return e;
          } else return e;
        } else if (!e[Rt])
          switch (t) {
            case `meta`:
              if (!e.hasAttribute(`itemprop`)) break;
              return e;
            case `link`:
              if (
                ((a = e.getAttribute(`rel`)),
                (a === `stylesheet` && e.hasAttribute(`data-precedence`)) ||
                  a !== i.rel ||
                  e.getAttribute(`href`) !==
                    (i.href == null || i.href === `` ? null : i.href) ||
                  e.getAttribute(`crossorigin`) !==
                    (i.crossOrigin == null ? null : i.crossOrigin) ||
                  e.getAttribute(`title`) !==
                    (i.title == null ? null : i.title))
              )
                break;
              return e;
            case `style`:
              if (e.hasAttribute(`data-precedence`)) break;
              return e;
            case `script`:
              if (
                ((a = e.getAttribute(`src`)),
                (a !== (i.src == null ? null : i.src) ||
                  e.getAttribute(`type`) !== (i.type == null ? null : i.type) ||
                  e.getAttribute(`crossorigin`) !==
                    (i.crossOrigin == null ? null : i.crossOrigin)) &&
                  a &&
                  e.hasAttribute(`async`) &&
                  !e.hasAttribute(`itemprop`))
              )
                break;
              return e;
            default:
              return e;
          }
        if (((e = lm(e.nextSibling)), e === null)) break;
      }
      return null;
    }
    function im(e, t, n) {
      if (t === ``) return null;
      for (; e.nodeType !== 3;)
        if (
          ((e.nodeType !== 1 ||
            e.nodeName !== `INPUT` ||
            e.type !== `hidden`) &&
            !n) ||
          ((e = lm(e.nextSibling)), e === null)
        )
          return null;
      return e;
    }
    function am(e, t) {
      for (; e.nodeType !== 8;)
        if (
          ((e.nodeType !== 1 ||
            e.nodeName !== `INPUT` ||
            e.type !== `hidden`) &&
            !t) ||
          ((e = lm(e.nextSibling)), e === null)
        )
          return null;
      return e;
    }
    function om(e) {
      return e.data === `$?` || e.data === `$~`;
    }
    function sm(e) {
      return (
        e.data === `$!` ||
        (e.data === `$?` && e.ownerDocument.readyState !== `loading`)
      );
    }
    function cm(e, t) {
      var n = e.ownerDocument;
      if (e.data === `$~`) e._reactRetry = t;
      else if (e.data !== `$?` || n.readyState !== `loading`) t();
      else {
        var r = function () {
          (t(), n.removeEventListener(`DOMContentLoaded`, r));
        };
        (n.addEventListener(`DOMContentLoaded`, r), (e._reactRetry = r));
      }
    }
    function lm(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
          if (
            ((t = e.data),
            t === `$` ||
              t === `$!` ||
              t === `$?` ||
              t === `$~` ||
              t === `&` ||
              t === `F!` ||
              t === `F`)
          )
            break;
          if (t === `/$` || t === `/&`) return null;
        }
      }
      return e;
    }
    var um = null;
    function dm(e) {
      e = e.nextSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === `/$` || n === `/&`) {
            if (t === 0) return lm(e.nextSibling);
            t--;
          } else
            (n !== `$` &&
              n !== `$!` &&
              n !== `$?` &&
              n !== `$~` &&
              n !== `&`) ||
              t++;
        }
        e = e.nextSibling;
      }
      return null;
    }
    function fm(e) {
      e = e.previousSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (
            n === `$` ||
            n === `$!` ||
            n === `$?` ||
            n === `$~` ||
            n === `&`
          ) {
            if (t === 0) return e;
            t--;
          } else (n !== `/$` && n !== `/&`) || t++;
        }
        e = e.previousSibling;
      }
      return null;
    }
    function pm(e, t) {
      function n() {
        r = !0;
      }
      if (e.ownerDocument.activeElement === e) return !0;
      var r = !1;
      try {
        (e.ownerDocument.addEventListener(`focus`, n, !0),
          (e.focus || HTMLElement.prototype.focus).call(e, t));
      } finally {
        e.ownerDocument.removeEventListener(`focus`, n, !0);
      }
      return r;
    }
    function mm(e) {
      yp(function () {
        yp(function (t) {
          return e(t);
        });
      });
    }
    function hm(e, t, n) {
      switch (((t = lp(n)), e)) {
        case `html`:
          if (((e = t.documentElement), !e)) throw Error(i(452));
          return e;
        case `head`:
          if (((e = t.head), !e)) throw Error(i(453));
          return e;
        case `body`:
          if (((e = t.body), !e)) throw Error(i(454));
          return e;
        default:
          throw Error(i(451));
      }
    }
    function gm(e, t, n) {
      for (var r in n) {
        var i = n[r];
        n.hasOwnProperty(r) && i != null && $(e, t, r, null, rp, i);
      }
      (n.dangerouslySetInnerHTML != null && (e.textContent = ``),
        e.onclick === Dn && (e.onclick = null),
        Bt(e));
    }
    function _m(e) {
      for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
      Bt(e);
    }
    var vm = new Map(),
      ym = new Set();
    function bm(e) {
      if (typeof e.getRootNode == `function`) {
        var t = e.getRootNode();
        if (t.nodeType === 9 || t.nodeType === 11) return t;
      }
      return e.nodeType === 9 ? e : e.ownerDocument;
    }
    var xm = O.d;
    O.d = {
      f: Sm,
      r: Cm,
      D: Em,
      C: Dm,
      L: Om,
      m: km,
      X: jm,
      S: Am,
      M: Mm,
    };
    function Sm() {
      var e = xm.f(),
        t = zd();
      return e || t;
    }
    function Cm(e) {
      var t = Ht(e);
      t !== null && t.tag === 5 && t.type === `form` ? ac(t) : xm.r(e);
    }
    var wm = typeof document > `u` ? null : document;
    function Tm(e, t, n) {
      var r = wm;
      if (r && typeof t == `string` && t) {
        var i = fn(t);
        ((i = `link[rel="` + e + `"][href="` + i + `"]`),
          typeof n == `string` && (i += `[crossorigin="` + n + `"]`),
          ym.has(i) ||
            (ym.add(i),
            (e = {
              rel: e,
              crossOrigin: n,
              href: t,
            }),
            r.querySelector(i) === null &&
              ((t = r.createElement(`link`)),
              np(t, `link`, e),
              Gt(t),
              r.head.appendChild(t))));
      }
    }
    function Em(e) {
      (xm.D(e), Tm(`dns-prefetch`, e, null));
    }
    function Dm(e, t) {
      (xm.C(e, t), Tm(`preconnect`, e, t));
    }
    function Om(e, t, n) {
      xm.L(e, t, n);
      var r = wm;
      if (r && e && t) {
        var i = `link[rel="preload"][as="` + fn(t) + `"]`;
        t === `image` && n && n.imageSrcSet
          ? ((i += `[imagesrcset="` + fn(n.imageSrcSet) + `"]`),
            typeof n.imageSizes == `string` &&
              (i += `[imagesizes="` + fn(n.imageSizes) + `"]`))
          : (i += `[href="` + fn(e) + `"]`);
        var a = i;
        switch (t) {
          case `style`:
            a = Pm(e);
            break;
          case `script`:
            a = Rm(e);
        }
        if (!(
          vm.has(a) ||
          ((e = C(
            {
              rel: `preload`,
              href: t === `image` && n && n.imageSrcSet ? void 0 : e,
              as: t,
            },
            n,
          )),
          vm.set(a, e),
          r.querySelector(i) !== null ||
            (t === `style` && r.querySelector(Fm(a))) ||
            (t === `script` && r.querySelector(zm(a))))
        )) {
          var o = r.createElement(`link`);
          (np(o, `link`, e),
            t === `style` &&
              ((o[zt] = !0),
              (o.onload = o.onerror =
                function () {
                  Kt(o);
                })),
            Gt(o),
            r.head.appendChild(o));
        }
      }
    }
    function km(e, t) {
      xm.m(e, t);
      var n = wm;
      if (n && e) {
        var r = t && typeof t.as == `string` ? t.as : `script`,
          i =
            `link[rel="modulepreload"][as="` +
            fn(r) +
            `"][href="` +
            fn(e) +
            `"]`,
          a = i;
        switch (r) {
          case `audioworklet`:
          case `paintworklet`:
          case `serviceworker`:
          case `sharedworker`:
          case `worker`:
          case `script`:
            a = Rm(e);
        }
        if (
          !vm.has(a) &&
          ((e = C(
            {
              rel: `modulepreload`,
              href: e,
            },
            t,
          )),
          vm.set(a, e),
          n.querySelector(i) === null)
        ) {
          switch (r) {
            case `audioworklet`:
            case `paintworklet`:
            case `serviceworker`:
            case `sharedworker`:
            case `worker`:
            case `script`:
              if (n.querySelector(zm(a))) return;
          }
          ((r = n.createElement(`link`)),
            np(r, `link`, e),
            Gt(r),
            n.head.appendChild(r));
        }
      }
    }
    function Am(e, t, n) {
      xm.S(e, t, n);
      var r = wm;
      if (r && e) {
        var i = Wt(r).hoistableStyles,
          a = Pm(e);
        t ||= `default`;
        var o = i.get(a);
        if (!o) {
          var s = {
            loading: 0,
            preload: null,
          };
          if ((o = r.querySelector(Fm(a)))) s.loading = 5;
          else {
            ((e = C(
              {
                rel: `stylesheet`,
                href: e,
                "data-precedence": t,
              },
              n,
            )),
              (n = vm.get(a)) && Hm(e, n));
            var c = (o = r.createElement(`link`));
            (Gt(c),
              np(c, `link`, e),
              (c._p = new Promise(function (e, t) {
                ((c.onload = e), (c.onerror = t));
              })),
              c.addEventListener(`load`, function () {
                s.loading |= 1;
              }),
              c.addEventListener(`error`, function () {
                s.loading |= 2;
              }),
              (s.loading |= 4),
              Vm(o, t, r));
          }
          ((o = {
            type: `stylesheet`,
            instance: o,
            count: 1,
            state: s,
          }),
            i.set(a, o));
        }
      }
    }
    function jm(e, t) {
      xm.X(e, t);
      var n = wm;
      if (n && e) {
        var r = Wt(n).hoistableScripts,
          i = Rm(e),
          a = r.get(i);
        a ||
          ((a = n.querySelector(zm(i))),
          a ||
            ((e = C(
              {
                src: e,
                async: !0,
              },
              t,
            )),
            (t = vm.get(i)) && Um(e, t),
            (a = n.createElement(`script`)),
            Gt(a),
            np(a, `link`, e),
            n.head.appendChild(a)),
          (a = {
            type: `script`,
            instance: a,
            count: 1,
            state: null,
          }),
          r.set(i, a));
      }
    }
    function Mm(e, t) {
      xm.M(e, t);
      var n = wm;
      if (n && e) {
        var r = Wt(n).hoistableScripts,
          i = Rm(e),
          a = r.get(i);
        a ||
          ((a = n.querySelector(zm(i))),
          a ||
            ((e = C(
              {
                src: e,
                async: !0,
                type: `module`,
              },
              t,
            )),
            (t = vm.get(i)) && Um(e, t),
            (a = n.createElement(`script`)),
            Gt(a),
            np(a, `link`, e),
            n.head.appendChild(a)),
          (a = {
            type: `script`,
            instance: a,
            count: 1,
            state: null,
          }),
          r.set(i, a));
      }
    }
    function Nm(e, t, n, r) {
      var a = (a = je.current) ? bm(a) : null;
      if (!a) throw Error(i(446));
      switch (e) {
        case `meta`:
        case `title`:
          return null;
        case `style`:
          return typeof n.precedence == `string` && typeof n.href == `string`
            ? ((n = Pm(n.href)),
              (t = Wt(a).hoistableStyles),
              (r = t.get(n)),
              r ||
                ((r = {
                  type: `style`,
                  instance: null,
                  count: 0,
                  state: null,
                }),
                t.set(n, r)),
              r)
            : {
                type: `void`,
                instance: null,
                count: 0,
                state: null,
              };
        case `link`:
          if (
            n.rel === `stylesheet` &&
            typeof n.href == `string` &&
            typeof n.precedence == `string`
          ) {
            e = Pm(n.href);
            var o = Wt(a).hoistableStyles,
              s = o.get(e);
            if (
              (s ||
                ((a = a.ownerDocument || a),
                (s = {
                  type: `stylesheet`,
                  instance: null,
                  count: 0,
                  state: {
                    loading: 0,
                    preload: null,
                  },
                }),
                o.set(e, s),
                (o = a.querySelector(Fm(e)))
                  ? o._p || ((s.instance = o), (s.state.loading = 5))
                  : ((o = vm.get(e)),
                    o ||
                      ((o = {
                        rel: `preload`,
                        as: `style`,
                        href: n.href,
                        crossOrigin: n.crossOrigin,
                        integrity: n.integrity,
                        media: n.media,
                        hrefLang: n.hrefLang,
                        referrerPolicy: n.referrerPolicy,
                      }),
                      vm.set(e, o)),
                    Lm(a, e, o, s.state))),
              t && r === null)
            )
              throw Error(i(528, ``));
            return s;
          }
          if (t && r !== null) throw Error(i(529, ``));
          return null;
        case `script`:
          return (
            (t = n.async),
            (n = n.src),
            typeof n == `string` &&
            t &&
            typeof t != `function` &&
            typeof t != `symbol`
              ? ((n = Rm(n)),
                (t = Wt(a).hoistableScripts),
                (r = t.get(n)),
                r ||
                  ((r = {
                    type: `script`,
                    instance: null,
                    count: 0,
                    state: null,
                  }),
                  t.set(n, r)),
                r)
              : {
                  type: `void`,
                  instance: null,
                  count: 0,
                  state: null,
                }
          );
        default:
          throw Error(i(444, e));
      }
    }
    function Pm(e) {
      return `href="` + fn(e) + `"`;
    }
    function Fm(e) {
      return `link[rel="stylesheet"][` + e + `]`;
    }
    function Im(e) {
      return C({}, e, {
        "data-precedence": e.precedence,
        precedence: null,
      });
    }
    function Lm(e, t, n, r) {
      if ((t = e.querySelector(`link[rel="preload"][as="style"][` + t + `]`))) {
        if (!0 !== t[zt]) {
          r.loading = 1;
          return;
        }
      } else
        ((t = e.createElement(`link`)),
          (t[zt] = !0),
          (t.onload = t.onerror = Kt.bind(null, t)),
          np(t, `link`, n),
          Gt(t),
          e.head.appendChild(t));
      ((r.preload = t),
        t.addEventListener(`load`, function () {
          return (r.loading |= 1);
        }),
        t.addEventListener(`error`, function () {
          return (r.loading |= 2);
        }));
    }
    function Rm(e) {
      return `[src="` + fn(e) + `"]`;
    }
    function zm(e) {
      return `script[async]` + e;
    }
    function Bm(e, t, n) {
      if ((t.count++, t.instance === null))
        switch (t.type) {
          case `style`:
            var r = e.querySelector(`style[data-href~="` + fn(n.href) + `"]`);
            if (r) return ((t.instance = r), Gt(r), r);
            var a = C({}, n, {
              "data-href": n.href,
              "data-precedence": n.precedence,
              href: null,
              precedence: null,
            });
            return (
              (r = (e.ownerDocument || e).createElement(`style`)),
              Gt(r),
              np(r, `style`, a),
              Vm(r, n.precedence, e),
              (t.instance = r)
            );
          case `stylesheet`:
            a = Pm(n.href);
            var o = e.querySelector(Fm(a));
            if (o) return ((t.state.loading |= 4), (t.instance = o), Gt(o), o);
            ((r = Im(n)),
              (a = vm.get(a)) && Hm(r, a),
              (o = (e.ownerDocument || e).createElement(`link`)),
              Gt(o));
            var s = o;
            return (
              (s._p = new Promise(function (e, t) {
                ((s.onload = e), (s.onerror = t));
              })),
              np(o, `link`, r),
              (t.state.loading |= 4),
              Vm(o, n.precedence, e),
              (t.instance = o)
            );
          case `script`:
            return (
              (o = Rm(n.src)),
              (a = e.querySelector(zm(o)))
                ? ((t.instance = a), Gt(a), a)
                : ((r = n),
                  (a = vm.get(o)) && ((r = C({}, n)), Um(r, a)),
                  (e = e.ownerDocument || e),
                  (a = e.createElement(`script`)),
                  Gt(a),
                  np(a, `link`, r),
                  e.head.appendChild(a),
                  (t.instance = a))
            );
          case `void`:
            return null;
          default:
            throw Error(i(443, t.type));
        }
      else
        t.type === `stylesheet` &&
          !(t.state.loading & 4) &&
          ((r = t.instance), (t.state.loading |= 4), Vm(r, n.precedence, e));
      return t.instance;
    }
    function Vm(e, t, n) {
      for (
        var r = n.querySelectorAll(
            `link[rel="stylesheet"][data-precedence],style[data-precedence]`,
          ),
          i = r.length ? r[r.length - 1] : null,
          a = i,
          o = 0;
        o < r.length;
        o++
      ) {
        var s = r[o];
        if (s.dataset.precedence === t) a = s;
        else if (a !== i) break;
      }
      a
        ? a.parentNode.insertBefore(e, a.nextSibling)
        : ((t = n.nodeType === 9 ? n.head : n),
          t.insertBefore(e, t.firstChild));
    }
    function Hm(e, t) {
      ((e.crossOrigin ??= t.crossOrigin),
        (e.referrerPolicy ??= t.referrerPolicy),
        (e.title ??= t.title));
    }
    function Um(e, t) {
      ((e.crossOrigin ??= t.crossOrigin),
        (e.referrerPolicy ??= t.referrerPolicy),
        (e.integrity ??= t.integrity));
    }
    var Wm = null;
    function Gm(e, t, n) {
      if (Wm === null) {
        var r = new Map(),
          i = (Wm = new Map());
        i.set(n, r);
      } else ((i = Wm), (r = i.get(n)), r || ((r = new Map()), i.set(n, r)));
      if (r.has(e)) return r;
      for (
        r.set(e, null), n = n.getElementsByTagName(e), i = 0;
        i < n.length;
        i++
      ) {
        var a = n[i];
        if (
          !(
            a[Rt] ||
            a[jt] ||
            (e === `link` && a.getAttribute(`rel`) === `stylesheet`)
          ) &&
          a.namespaceURI !== `http://www.w3.org/2000/svg`
        ) {
          var o = a.getAttribute(t) || ``;
          o = e + o;
          var s = r.get(o);
          s ? s.push(a) : r.set(o, [a]);
        }
      }
      return r;
    }
    function Km(e, t, n) {
      ((e = e.ownerDocument || e),
        e.head.insertBefore(
          n,
          t === `title` ? e.querySelector(`head > title`) : null,
        ));
    }
    function qm(e, t, n) {
      if (n === 1 || t.itemProp != null) return !1;
      switch (e) {
        case `meta`:
        case `title`:
          return !0;
        case `style`:
          if (
            typeof t.precedence != `string` ||
            typeof t.href != `string` ||
            t.href === ``
          )
            break;
          return !0;
        case `link`:
          if (
            typeof t.rel != `string` ||
            typeof t.href != `string` ||
            t.href === `` ||
            t.onLoad ||
            t.onError
          )
            break;
          switch (t.rel) {
            case `stylesheet`:
              return (
                (e = t.disabled),
                typeof t.precedence == `string` && e == null
              );
            default:
              return !0;
          }
        case `script`:
          if (
            t.async &&
            typeof t.async != `function` &&
            typeof t.async != `symbol` &&
            !t.onLoad &&
            !t.onError &&
            t.src &&
            typeof t.src == `string`
          )
            return !0;
      }
      return !1;
    }
    function Jm(e, t) {
      return (
        e === `img` &&
        t.src != null &&
        t.src !== `` &&
        t.onLoad == null &&
        t.loading !== `lazy`
      );
    }
    function Ym(e) {
      return !(e.type === `stylesheet` && !(e.state.loading & 3));
    }
    function Xm(e) {
      return (
        (e.width || 100) *
        (e.height || 100) *
        (typeof devicePixelRatio == `number` ? devicePixelRatio : 1) *
        0.25
      );
    }
    function Zm(e, t) {
      typeof t.decode == `function` &&
        (e.imgCount++,
        t.complete || ((e.imgBytes += Xm(t)), e.suspenseyImages.push(t)),
        (e = rh.bind(e)),
        t.decode().then(e, e));
    }
    function Qm(e, t, n, r) {
      if (
        n.type === `stylesheet` &&
        (typeof r.media != `string` || !1 !== matchMedia(r.media).matches) &&
        !(n.state.loading & 4)
      ) {
        if (n.instance === null) {
          var i = Pm(r.href),
            a = t.querySelector(Fm(i));
          if (a) {
            ((t = a._p),
              typeof t == `object` &&
                t &&
                typeof t.then == `function` &&
                (e.count++, (e = nh.bind(e)), t.then(e, e)),
              (n.state.loading |= 4),
              (n.instance = a),
              Gt(a));
            return;
          }
          ((a = t.ownerDocument || t),
            (r = Im(r)),
            (i = vm.get(i)) && Hm(r, i),
            (a = a.createElement(`link`)),
            Gt(a));
          var o = a;
          ((o._p = new Promise(function (e, t) {
            ((o.onload = e), (o.onerror = t));
          })),
            np(a, `link`, r),
            (n.instance = a));
        }
        (e.stylesheets === null && (e.stylesheets = new Map()),
          e.stylesheets.set(n, t),
          (t = n.state.preload) &&
            !(n.state.loading & 3) &&
            (e.count++,
            (n = nh.bind(e)),
            t.addEventListener(`load`, n),
            t.addEventListener(`error`, n)));
      }
    }
    var $m = 0;
    function eh(e, t) {
      return (
        e.stylesheets && e.count === 0 && ah(e, e.stylesheets),
        0 < e.count || 0 < e.imgCount
          ? function (n) {
              var r = setTimeout(function () {
                if ((e.stylesheets && ah(e, e.stylesheets), e.unsuspend)) {
                  var t = e.unsuspend;
                  ((e.unsuspend = null), t());
                }
              }, 6e4 + t);
              0 < e.imgBytes && $m === 0 && ($m = 62500 * op());
              var i = setTimeout(
                function () {
                  if (
                    ((e.waitingForImages = !1),
                    e.count === 0 &&
                      (e.stylesheets && ah(e, e.stylesheets), e.unsuspend))
                  ) {
                    var t = e.unsuspend;
                    ((e.unsuspend = null), t());
                  }
                },
                (e.imgBytes > $m ? 50 : 800) + t,
              );
              return (
                (e.unsuspend = n),
                function () {
                  ((e.unsuspend = null), clearTimeout(r), clearTimeout(i));
                }
              );
            }
          : null
      );
    }
    function th(e) {
      if (e.count === 0 && (e.imgCount === 0 || !e.waitingForImages)) {
        if (e.stylesheets) ah(e, e.stylesheets);
        else if (e.unsuspend) {
          var t = e.unsuspend;
          ((e.unsuspend = null), t());
        }
      }
    }
    function nh() {
      (this.count--, th(this));
    }
    function rh() {
      (this.imgCount--, th(this));
    }
    var ih = null;
    function ah(e, t) {
      ((e.stylesheets = null),
        e.unsuspend !== null &&
          (e.count++,
          (ih = new Map()),
          t.forEach(oh, e),
          (ih = null),
          nh.call(e)));
    }
    function oh(e, t) {
      if (!(t.state.loading & 4)) {
        var n = ih.get(e);
        if (n) var r = n.get(null);
        else {
          ((n = new Map()), ih.set(e, n));
          for (
            var i = e.querySelectorAll(
                `link[data-precedence],style[data-precedence]`,
              ),
              a = 0;
            a < i.length;
            a++
          ) {
            var o = i[a];
            (o.nodeName === `LINK` || o.getAttribute(`media`) !== `not all`) &&
              (n.set(o.dataset.precedence, o), (r = o));
          }
          r && n.set(null, r);
        }
        ((i = t.instance),
          (o = i.getAttribute(`data-precedence`)),
          (a = n.get(o) || r),
          a === r && n.set(null, i),
          n.set(o, i),
          this.count++,
          (r = nh.bind(this)),
          i.addEventListener(`load`, r),
          i.addEventListener(`error`, r),
          a
            ? a.parentNode.insertBefore(i, a.nextSibling)
            : ((e = e.nodeType === 9 ? e.head : e),
              e.insertBefore(i, e.firstChild)),
          (t.state.loading |= 4));
      }
    }
    var sh = {
      $$typeof: E,
      Provider: null,
      Consumer: null,
      _currentValue: we,
      _currentValue2: we,
      _threadCount: 0,
    };
    function ch(e, t, n, r, i, a, o, s, c) {
      ((this.tag = 1),
        (this.containerInfo = e),
        (this.pingCache = this.current = this.pendingChildren = null),
        (this.timeoutHandle = -1),
        (this.callbackNode =
          this.next =
          this.pendingContext =
          this.context =
          this.cancelPendingCommit =
            null),
        (this.callbackPriority = 0),
        (this.expirationTimes = bt(-1)),
        (this.entangledLanes =
          this.shellSuspendCounter =
          this.errorRecoveryDisabledLanes =
          this.expiredLanes =
          this.warmLanes =
          this.pingedLanes =
          this.suspendedLanes =
          this.pendingLanes =
            0),
        (this.entanglements = bt(0)),
        (this.hiddenUpdates = bt(null)),
        (this.identifierPrefix = r),
        (this.onUncaughtError = i),
        (this.onCaughtError = a),
        (this.onRecoverableError = o),
        (this.pooledCache = null),
        (this.pooledCacheLanes = 0),
        (this.formState = c),
        (this.transitionTypes = null),
        (this.incompleteTransitions = new Map()));
    }
    function lh(e, t, n, r, i, a, o, s, c, l, u, d) {
      return (
        (e = new ch(e, t, n, o, c, l, u, d, s)),
        (t = 1),
        !0 === a && (t |= 24),
        (a = Li(3, null, null, t)),
        (e.current = a),
        (a.stateNode = e),
        (t = Ia()),
        t.refCount++,
        (e.pooledCache = t),
        t.refCount++,
        (a.memoizedState = {
          element: r,
          isDehydrated: n,
          cache: t,
        }),
        yo(a),
        e
      );
    }
    function uh(e) {
      return e ? ((e = Fi), e) : Fi;
    }
    function dh(e, t, n, r, i, a) {
      ((i = uh(i)),
        r.context === null ? (r.context = i) : (r.pendingContext = i),
        (r = xo(t)),
        (r.payload = {
          element: n,
        }),
        (a = a === void 0 ? null : a),
        a !== null && (r.callback = a),
        (n = So(e, r, t)),
        n !== null && (Pd(n, e, t), Co(n, e, t)));
    }
    function fh(e, t) {
      if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t;
      }
    }
    function ph(e, t) {
      (fh(e, t), (e = e.alternate) && fh(e, t));
    }
    function mh(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = Mi(e, 67108864);
        (t !== null && Pd(t, e, 67108864), ph(e, 67108864));
      }
    }
    function hh(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = jd();
        t = Et(t);
        var n = Mi(e, t);
        (n !== null && Pd(n, e, t), ph(e, t));
      }
    }
    var gh = !0;
    function _h(e, t, n, r) {
      var i = D.T;
      D.T = null;
      var a = O.p;
      try {
        ((O.p = 2), yh(e, t, n, r));
      } finally {
        ((O.p = a), (D.T = i));
      }
    }
    function vh(e, t, n, r) {
      var i = D.T;
      D.T = null;
      var a = O.p;
      try {
        ((O.p = 8), yh(e, t, n, r));
      } finally {
        ((O.p = a), (D.T = i));
      }
    }
    function yh(e, t, n, r) {
      if (gh) {
        var i = bh(r);
        if (i === null) (Kf(e, t, r, xh, n), Mh(e, r));
        else if (Ph(i, e, t, n, r)) r.stopPropagation();
        else if ((Mh(e, r), t & 4 && -1 < jh.indexOf(e))) {
          for (; i !== null;) {
            var a = Ht(i);
            if (a !== null)
              switch (a.tag) {
                case 3:
                  if (
                    ((a = a.stateNode), a.current.memoizedState.isDehydrated)
                  ) {
                    var o = mt(a.pendingLanes);
                    if (o !== 0) {
                      var s = a;
                      for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
                        var c = 1 << (31 - st(o));
                        ((s.entanglements[1] |= c), (o &= ~c));
                      }
                      (Ef(a), !(W & 6) && ((_d = Ye() + 500), Df(0, !1)));
                    }
                  }
                  break;
                case 31:
                case 13:
                  ((s = Mi(a, 2)), s !== null && Pd(s, a, 2), zd(), ph(a, 2));
              }
            if (((a = bh(r)), a === null && Kf(e, t, r, xh, n), a === i)) break;
            i = a;
          }
          i !== null && r.stopPropagation();
        } else Kf(e, t, r, null, n);
      }
    }
    function bh(e) {
      return ((e = kn(e)), Sh(e));
    }
    var xh = null;
    function Sh(e) {
      if (((xh = null), (e = Vt(e)), e !== null)) {
        var t = o(e);
        if (t === null) e = null;
        else {
          var n = t.tag;
          if (n === 13) {
            if (((e = s(t)), e !== null)) return e;
            e = null;
          } else if (n === 31) {
            if (((e = c(t)), e !== null)) return e;
            e = null;
          } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated)
              return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null;
          } else t !== e && (e = null);
        }
      }
      return ((xh = e), null);
    }
    function Ch(e) {
      switch (e) {
        case `beforetoggle`:
        case `cancel`:
        case `click`:
        case `close`:
        case `contextmenu`:
        case `copy`:
        case `cut`:
        case `auxclick`:
        case `dblclick`:
        case `dragend`:
        case `dragstart`:
        case `drop`:
        case `focusin`:
        case `focusout`:
        case `input`:
        case `invalid`:
        case `keydown`:
        case `keypress`:
        case `keyup`:
        case `mousedown`:
        case `mouseup`:
        case `paste`:
        case `pause`:
        case `play`:
        case `pointercancel`:
        case `pointerdown`:
        case `pointerup`:
        case `ratechange`:
        case `reset`:
        case `seeked`:
        case `submit`:
        case `toggle`:
        case `touchcancel`:
        case `touchend`:
        case `touchstart`:
        case `volumechange`:
        case `change`:
        case `selectionchange`:
        case `textInput`:
        case `compositionstart`:
        case `compositionend`:
        case `compositionupdate`:
        case `beforeblur`:
        case `afterblur`:
        case `beforeinput`:
        case `blur`:
        case `fullscreenchange`:
        case `fullscreenerror`:
        case `focus`:
        case `hashchange`:
        case `popstate`:
        case `select`:
        case `selectstart`:
          return 2;
        case `drag`:
        case `dragenter`:
        case `dragexit`:
        case `dragleave`:
        case `dragover`:
        case `mousemove`:
        case `mouseout`:
        case `mouseover`:
        case `pointermove`:
        case `pointerout`:
        case `pointerover`:
        case `resize`:
        case `scroll`:
        case `touchmove`:
        case `wheel`:
        case `mouseenter`:
        case `mouseleave`:
        case `pointerenter`:
        case `pointerleave`:
          return 8;
        case `message`:
          switch (Xe()) {
            case Ze:
              return 2;
            case Qe:
              return 8;
            case $e:
            case et:
              return 32;
            case tt:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var wh = !1,
      Th = null,
      Eh = null,
      Dh = null,
      Oh = new Map(),
      kh = new Map(),
      Ah = [],
      jh =
        `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(
          ` `,
        );
    function Mh(e, t) {
      switch (e) {
        case `focusin`:
        case `focusout`:
          Th = null;
          break;
        case `dragenter`:
        case `dragleave`:
          Eh = null;
          break;
        case `mouseover`:
        case `mouseout`:
          Dh = null;
          break;
        case `pointerover`:
        case `pointerout`:
          Oh.delete(t.pointerId);
          break;
        case `gotpointercapture`:
        case `lostpointercapture`:
          kh.delete(t.pointerId);
      }
    }
    function Nh(e, t, n, r, i, a) {
      return e === null || e.nativeEvent !== a
        ? ((e = {
            blockedOn: t,
            domEventName: n,
            eventSystemFlags: r,
            nativeEvent: a,
            targetContainers: [i],
          }),
          t !== null && ((t = Ht(t)), t !== null && mh(t)),
          e)
        : ((e.eventSystemFlags |= r),
          (t = e.targetContainers),
          i !== null && t.indexOf(i) === -1 && t.push(i),
          e);
    }
    function Ph(e, t, n, r, i) {
      switch (t) {
        case `focusin`:
          return ((Th = Nh(Th, e, t, n, r, i)), !0);
        case `dragenter`:
          return ((Eh = Nh(Eh, e, t, n, r, i)), !0);
        case `mouseover`:
          return ((Dh = Nh(Dh, e, t, n, r, i)), !0);
        case `pointerover`:
          var a = i.pointerId;
          return (Oh.set(a, Nh(Oh.get(a) || null, e, t, n, r, i)), !0);
        case `gotpointercapture`:
          return (
            (a = i.pointerId),
            kh.set(a, Nh(kh.get(a) || null, e, t, n, r, i)),
            !0
          );
      }
      return !1;
    }
    function Fh(e) {
      var t = Vt(e.target);
      if (t !== null) {
        var n = o(t);
        if (n !== null) {
          if (((t = n.tag), t === 13)) {
            if (((t = s(n)), t !== null)) {
              ((e.blockedOn = t),
                kt(e.priority, function () {
                  hh(n);
                }));
              return;
            }
          } else if (t === 31) {
            if (((t = c(n)), t !== null)) {
              ((e.blockedOn = t),
                kt(e.priority, function () {
                  hh(n);
                }));
              return;
            }
          } else if (
            t === 3 &&
            n.stateNode.current.memoizedState.isDehydrated
          ) {
            e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
            return;
          }
        }
      }
      e.blockedOn = null;
    }
    function Ih(e) {
      if (e.blockedOn !== null) return !1;
      for (var t = e.targetContainers; 0 < t.length;) {
        var n = bh(e.nativeEvent);
        if (n === null) {
          n = e.nativeEvent;
          var r = new n.constructor(n.type, n);
          ((On = r), n.target.dispatchEvent(r), (On = null));
        } else return ((t = Ht(n)), t !== null && mh(t), (e.blockedOn = n), !1);
        t.shift();
      }
      return !0;
    }
    function Lh(e, t, n) {
      Ih(e) && n.delete(t);
    }
    function Rh() {
      ((wh = !1),
        Th !== null && Ih(Th) && (Th = null),
        Eh !== null && Ih(Eh) && (Eh = null),
        Dh !== null && Ih(Dh) && (Dh = null),
        Oh.forEach(Lh),
        kh.forEach(Lh));
    }
    function zh(e, n) {
      e.blockedOn === n &&
        ((e.blockedOn = null),
        wh ||
          ((wh = !0),
          t.unstable_scheduleCallback(t.unstable_NormalPriority, Rh)));
    }
    var Bh = null;
    function Vh(e) {
      Bh !== e &&
        ((Bh = e),
        t.unstable_scheduleCallback(t.unstable_NormalPriority, function () {
          Bh === e && (Bh = null);
          for (var t = 0; t < e.length; t += 3) {
            var n = e[t],
              r = e[t + 1],
              i = e[t + 2];
            if (typeof r != `function`) {
              if (Sh(r || n) === null) continue;
              break;
            }
            var a = Ht(n);
            a !== null &&
              (e.splice(t, 3),
              (t -= 3),
              rc(
                a,
                {
                  pending: !0,
                  data: i,
                  method: n.method,
                  action: r,
                },
                r,
                i,
              ));
          }
        }));
    }
    function Hh(e) {
      function t(t) {
        return zh(t, e);
      }
      (Th !== null && zh(Th, e),
        Eh !== null && zh(Eh, e),
        Dh !== null && zh(Dh, e),
        Oh.forEach(t),
        kh.forEach(t));
      for (var n = 0; n < Ah.length; n++) {
        var r = Ah[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
      for (; 0 < Ah.length && ((n = Ah[0]), n.blockedOn === null);)
        (Fh(n), n.blockedOn === null && Ah.shift());
      if (((n = (e.ownerDocument || e).$$reactFormReplay), n != null))
        for (r = 0; r < n.length; r += 3) {
          var i = n[r],
            a = n[r + 1],
            o = i[Mt] || null;
          if (typeof a == `function`) o || Vh(n);
          else if (o) {
            var s = null;
            if (a && a.hasAttribute(`formAction`)) {
              if (((i = a), (o = a[Mt] || null))) s = o.formAction;
              else if (Sh(i) !== null) continue;
            } else s = o.action;
            (typeof s == `function`
              ? (n[r + 1] = s)
              : (n.splice(r, 3), (r -= 3)),
              Vh(n));
          }
        }
    }
    function Uh() {
      function e(e) {
        e.canIntercept &&
          e.info === `react-transition` &&
          e.intercept({
            handler: function () {
              return new Promise(function (e) {
                return (i = e);
              });
            },
            focusReset: `manual`,
            scroll: `manual`,
          });
      }
      function t() {
        (i !== null && (i(), (i = null)), r || setTimeout(n, 20));
      }
      function n() {
        if (!r && !navigation.transition) {
          var e = navigation.currentEntry;
          e &&
            e.url != null &&
            navigation.navigate(e.url, {
              state: e.getState(),
              info: `react-transition`,
              history: `replace`,
            });
        }
      }
      if (typeof navigation == `object`) {
        var r = !1,
          i = null;
        return (
          navigation.addEventListener(`navigate`, e),
          navigation.addEventListener(`navigatesuccess`, t),
          navigation.addEventListener(`navigateerror`, t),
          setTimeout(n, 100),
          function () {
            ((r = !0),
              navigation.removeEventListener(`navigate`, e),
              navigation.removeEventListener(`navigatesuccess`, t),
              navigation.removeEventListener(`navigateerror`, t),
              i !== null && (i(), (i = null)));
          }
        );
      }
    }
    function Wh(e) {
      this._internalRoot = e;
    }
    ((Gh.prototype.render = Wh.prototype.render =
      function (e) {
        var t = this._internalRoot;
        if (t === null) throw Error(i(409));
        var n = t.current;
        dh(n, jd(), e, t, null, null);
      }),
      (Gh.prototype.unmount = Wh.prototype.unmount =
        function () {
          var e = this._internalRoot;
          if (e !== null) {
            this._internalRoot = null;
            var t = e.containerInfo;
            (dh(e.current, 2, null, e, null, null), zd(), (t[Nt] = null));
          }
        }));
    function Gh(e) {
      this._internalRoot = e;
    }
    Gh.prototype.unstable_scheduleHydration = function (e) {
      if (e) {
        var t = Ot();
        e = {
          blockedOn: null,
          target: e,
          priority: t,
        };
        for (var n = 0; n < Ah.length && t !== 0 && t < Ah[n].priority; n++);
        (Ah.splice(n, 0, e), n === 0 && Fh(e));
      }
    };
    var Kh = n.version;
    if (Kh !== `19.3.0`) throw Error(i(527, Kh, `19.3.0`));
    O.findDOMNode = function (e) {
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == `function`
          ? Error(i(188))
          : ((e = Object.keys(e).join(`,`)), Error(i(268, e)));
      return (
        (e = d(t)),
        (e = e === null ? null : p(e)),
        (e = e === null ? null : e.stateNode),
        e
      );
    };
    var qh = {
      bundleType: 0,
      version: `19.3.0`,
      rendererPackageName: `react-dom`,
      currentDispatcherRef: D,
      reconcilerVersion: `19.3.0`,
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
      var Jh = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!Jh.isDisabled && Jh.supportsFiber)
        try {
          ((it = Jh.inject(qh)), (at = Jh));
        } catch {}
    }
    e.createRoot = function (e, t) {
      if (!a(e)) throw Error(i(299));
      var n = !1,
        r = ``,
        o = Ec,
        s = Dc,
        c = Oc;
      return (
        t != null &&
          (!0 === t.unstable_strictMode && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onUncaughtError !== void 0 && (o = t.onUncaughtError),
          t.onCaughtError !== void 0 && (s = t.onCaughtError),
          t.onRecoverableError !== void 0 && (c = t.onRecoverableError)),
        (t = lh(e, 1, !1, null, null, n, r, null, o, s, c, Uh)),
        (e[Nt] = t.current),
        Wf(e),
        new Wh(t)
      );
    };
  }),
  g = o((e, t) => {
    function n() {
      if (
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u` &&
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == `function`
      )
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
        } catch (e) {
          console.error(e);
        }
    }
    (n(), (t.exports = h()));
  }),
  _ = `modulepreload`,
  v = function (e, t) {
    return new URL(e, t).href;
  },
  y = {},
  b = function (e) {
    return e.pathname.endsWith(`.css`);
  },
  ee = function (e, t, n) {
    let r = Promise.resolve();
    if (t && t.length > 0) {
      let e,
        i = document.querySelector(`meta[property=csp-nonce]`),
        a = i?.nonce || i?.getAttribute(`nonce`);
      function o(e) {
        return Promise.all(
          e.map((e) =>
            Promise.resolve(e).then(
              (e) => ({
                status: `fulfilled`,
                value: e,
              }),
              (e) => ({
                status: `rejected`,
                reason: e,
              }),
            ),
          ),
        );
      }
      function s(e) {
        return undefined ? new URL(undefined(e)) : new URL(e, document.baseURI);
      }
      r = o(
        t
          .map((t) => {
            t = v(t, n);
            let r = s(t);
            if (r.href in y) return;
            y[r.href] = !0;
            let i = b(r);
            if (e === void 0) {
              e = {
                all: new Set(),
                styles: new Set(),
              };
              let t = document.getElementsByTagName(`link`);
              for (let n = t.length - 1; n >= 0; n--) {
                let r = t[n];
                (e.all.add(r.href),
                  r.rel === `stylesheet` && e.styles.add(r.href));
              }
            }
            if ((i ? e.styles : e.all).has(r.href)) return;
            let o = document.createElement(`link`);
            if (
              ((o.rel = i ? `stylesheet` : _),
              i || (o.as = `script`),
              (o.crossOrigin = ``),
              (o.href = r.href),
              a && o.setAttribute(`nonce`, a),
              document.head.appendChild(o),
              i)
            )
              return new Promise((e, t) => {
                (o.addEventListener(`load`, e),
                  o.addEventListener(`error`, () =>
                    t(Error(`Unable to preload CSS for ${r}`)),
                  ));
              });
          })
          .filter((e) => e !== void 0),
      );
    }
    function i(e) {
      let t = new Event(`vite:preloadError`, {
        cancelable: !0,
      });
      if (((t.payload = e), window.dispatchEvent(t), !t.defaultPrevented))
        throw e;
    }
    return r.then((t) => {
      for (let e of t || []) e.status === `rejected` && i(e.reason);
      return e().catch(i);
    });
  },
  x = c(u(), 1),
  te = /^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,
  ne = /^[\\/]{2}/;
function S(e, t) {
  return t + e.replace(/\\/g, `/`);
}
var re = `popstate`;
function C(e) {
  return (
    typeof e == `object` &&
    !!e &&
    `pathname` in e &&
    `search` in e &&
    `hash` in e &&
    `state` in e &&
    `key` in e
  );
}
function ie(e = {}) {
  function t(e, t) {
    let {
      pathname: n = `/`,
      search: r = ``,
      hash: i = ``,
    } = E(e.location.hash.substring(1));
    return (
      !n.startsWith(`/`) && !n.startsWith(`.`) && (n = `/` + n),
      se(
        ``,
        {
          pathname: n,
          search: r,
          hash: i,
        },
        (t.state && t.state.usr) || null,
        (t.state && t.state.key) || `default`,
      )
    );
  }
  function n(e, t) {
    let n = e.document.querySelector(`base`),
      r = ``;
    if (n && n.getAttribute(`href`)) {
      let t = e.location.href,
        n = t.indexOf(`#`);
      r = n === -1 ? t : t.slice(0, n);
    }
    return r + `#` + (typeof t == `string` ? t : ce(t));
  }
  function r(e, t) {
    T(
      e.pathname.charAt(0) === `/`,
      `relative pathnames are not supported in hash history.push(${JSON.stringify(t)})`,
    );
  }
  return le(t, n, r, e);
}
function w(e, t) {
  if (e === !1 || e == null) throw Error(t);
}
function T(e, t) {
  if (!e) {
    typeof console < `u` && console.warn(t);
    try {
      throw Error(t);
    } catch {}
  }
}
function ae() {
  return Math.random().toString(36).substring(2, 10);
}
function oe(e, t) {
  return {
    usr: e.state,
    key: e.key,
    idx: t,
    masked: e.mask
      ? {
          pathname: e.pathname,
          search: e.search,
          hash: e.hash,
        }
      : void 0,
  };
}
function se(e, t, n = null, r, i) {
  return {
    pathname: typeof e == `string` ? e : e.pathname,
    search: ``,
    hash: ``,
    ...(typeof t == `string` ? E(t) : t),
    state: n,
    key: (t && t.key) || r || ae(),
    mask: i,
  };
}
function ce({ pathname: e = `/`, search: t = ``, hash: n = `` }) {
  return (
    t && t !== `?` && (e += t.charAt(0) === `?` ? t : `?` + t),
    n && n !== `#` && (e += n.charAt(0) === `#` ? n : `#` + n),
    e
  );
}
function E(e) {
  let t = {};
  if (e) {
    let n = e.indexOf(`#`);
    n >= 0 && ((t.hash = e.substring(n)), (e = e.substring(0, n)));
    let r = e.indexOf(`?`);
    (r >= 0 && ((t.search = e.substring(r)), (e = e.substring(0, r))),
      e && (t.pathname = e));
  }
  return t;
}
function le(e, t, n, r = {}) {
  let { window: i = document.defaultView, v5Compat: a = !1 } = r,
    o = i.history,
    s = `POP`,
    c = null,
    l = u();
  l ??
    ((l = 0),
    o.replaceState(
      {
        ...o.state,
        idx: l,
      },
      ``,
    ));
  function u() {
    return (
      o.state || {
        idx: null,
      }
    ).idx;
  }
  function d() {
    s = `POP`;
    let e = u(),
      t = e == null ? null : e - l;
    ((l = e),
      c &&
        c({
          action: s,
          location: h.location,
          delta: t,
        }));
  }
  function f(e, t) {
    s = `PUSH`;
    let r = C(e) ? e : se(h.location, e, t);
    (n && n(r, e), (l = u() + 1));
    let d = oe(r, l),
      f = h.createHref(r.mask || r);
    try {
      o.pushState(d, ``, f);
    } catch (e) {
      if (e instanceof DOMException && e.name === `DataCloneError`) throw e;
      i.location.assign(f);
    }
    a &&
      c &&
      c({
        action: s,
        location: h.location,
        delta: 1,
      });
  }
  function p(e, t) {
    s = `REPLACE`;
    let r = C(e) ? e : se(h.location, e, t);
    (n && n(r, e), (l = u()));
    let i = oe(r, l),
      d = h.createHref(r.mask || r);
    (o.replaceState(i, ``, d),
      a &&
        c &&
        c({
          action: s,
          location: h.location,
          delta: 0,
        }));
  }
  function m(e) {
    return ue(i, e);
  }
  let h = {
    get action() {
      return s;
    },
    get location() {
      return e(i, o);
    },
    listen(e) {
      if (c) throw Error(`A history only accepts one active listener`);
      return (
        i.addEventListener(re, d),
        (c = e),
        () => {
          (i.removeEventListener(re, d), (c = null));
        }
      );
    },
    createHref(e) {
      return t(i, e);
    },
    createURL: m,
    encodeLocation(e) {
      let t = m(e);
      return {
        pathname: t.pathname,
        search: t.search,
        hash: t.hash,
      };
    },
    push: f,
    replace: p,
    go(e) {
      return o.go(e);
    },
  };
  return h;
}
function ue(e, t, n = !1) {
  let r = `http://localhost`;
  (e &&
    (r = e.location.origin === `null` ? e.location.href : e.location.origin),
    w(r, `No window.location.(origin|href) available to create URL`));
  let i = typeof t == `string` ? t : ce(t);
  return (
    (i = i.replace(/ $/, `%20`)),
    !n && ne.test(i) && (i = r + i),
    new URL(i, r)
  );
}
function de(e, t, n = `/`) {
  return fe(e, t, n, !1);
}
function fe(e, t, n, r, i) {
  let a = k((typeof t == `string` ? E(t) : t).pathname || `/`, n);
  if (a == null) return null;
  let o = i ?? pe(e),
    s = null,
    c = Oe(a);
  for (let e = 0; s == null && e < o.length; ++e) s = we(o[e], c, r);
  return s;
}
function pe(e) {
  let t = me(e);
  return (ge(t), t);
}
function me(e, t = [], n = [], r = ``, i = !1) {
  let a = (e, a, o = i, s) => {
    let c = {
      relativePath: s === void 0 ? e.path || `` : s,
      caseSensitive: e.caseSensitive === !0,
      childrenIndex: a,
      route: e,
    };
    if (c.relativePath.startsWith(`/`)) {
      if (!c.relativePath.startsWith(r) && o) return;
      (w(
        c.relativePath.startsWith(r),
        `Absolute route path "${c.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`,
      ),
        (c.relativePath = c.relativePath.slice(r.length)));
    }
    let l = Ie([r, c.relativePath]),
      u = n.concat(c);
    (e.children &&
      e.children.length > 0 &&
      (w(
        e.index !== !0,
        `Index routes must not have child routes. Please remove all child routes from route path "${l}".`,
      ),
      me(e.children, t, u, l, o)),
      (e.path != null || e.index) &&
        t.push({
          path: l,
          score: D(l, e.index),
          routesMeta: u.map((e, t) => {
            let [n, r] = De(
              e.relativePath,
              e.caseSensitive,
              t === u.length - 1,
            );
            return {
              ...e,
              matcher: n,
              compiledParams: r,
            };
          }),
        }));
  };
  return (
    e.forEach((e, t) => {
      if (e.path === `` || !e.path?.includes(`?`)) a(e, t);
      else for (let n of he(e.path)) a(e, t, !0, n);
    }),
    t
  );
}
function he(e) {
  let t = e.split(`/`);
  if (t.length === 0) return [];
  let [n, ...r] = t,
    i = n.endsWith(`?`),
    a = n.replace(/\?$/, ``);
  if (r.length === 0) return i ? [a, ``] : [a];
  let o = he(r.join(`/`)),
    s = [];
  return (
    s.push(...o.map((e) => (e === `` ? a : [a, e].join(`/`)))),
    i && s.push(...o),
    s.map((t) => (e.startsWith(`/`) && t === `` ? `/` : t))
  );
}
function ge(e) {
  e.sort((e, t) =>
    e.score === t.score
      ? O(
          e.routesMeta.map((e) => e.childrenIndex),
          t.routesMeta.map((e) => e.childrenIndex),
        )
      : t.score - e.score,
  );
}
var _e = /^:[\w-]+$/,
  ve = 3,
  ye = 2,
  be = 1,
  xe = 10,
  Se = -2,
  Ce = (e) => e === `*`;
function D(e, t) {
  let n = e.split(`/`),
    r = n.length;
  return (
    n.some(Ce) && (r += Se),
    t && (r += ye),
    n
      .filter((e) => !Ce(e))
      .reduce((e, t) => e + (_e.test(t) ? ve : t === `` ? be : xe), r)
  );
}
function O(e, t) {
  return e.length === t.length && e.slice(0, -1).every((e, n) => e === t[n])
    ? e[e.length - 1] - t[t.length - 1]
    : 0;
}
function we(e, t, n = !1) {
  let { routesMeta: r } = e,
    i = {},
    a = `/`,
    o = [];
  for (let e = 0; e < r.length; ++e) {
    let s = r[e],
      c = e === r.length - 1,
      l = a === `/` ? t : t.slice(a.length) || `/`,
      u = {
        path: s.relativePath,
        caseSensitive: s.caseSensitive,
        end: c,
      },
      d =
        s.matcher && s.compiledParams
          ? Ee(u, l, s.matcher, s.compiledParams)
          : Te(u, l),
      f = s.route;
    if (
      (!d &&
        c &&
        n &&
        !r[r.length - 1].route.index &&
        (d = Te(
          {
            path: s.relativePath,
            caseSensitive: s.caseSensitive,
            end: !1,
          },
          l,
        )),
      !d)
    )
      return null;
    (Object.assign(i, d.params),
      o.push({
        params: i,
        pathname: Ie([a, d.pathname]),
        pathnameBase: Re(Ie([a, d.pathnameBase])),
        route: f,
      }),
      d.pathnameBase !== `/` && (a = Ie([a, d.pathnameBase])));
  }
  return o;
}
function Te(e, t) {
  typeof e == `string` &&
    (e = {
      path: e,
      caseSensitive: !1,
      end: !0,
    });
  let [n, r] = De(e.path, e.caseSensitive, e.end);
  return Ee(e, t, n, r);
}
function Ee(e, t, n, r) {
  let i = t.match(n);
  if (!i) return null;
  let a = i[0],
    o = Le(a, 1),
    s = i.slice(1);
  return {
    params: r.reduce((e, { paramName: t, isOptional: n }, r) => {
      if (t === `*`) {
        let e = s[r] || ``;
        o = Le(a.slice(0, a.length - e.length), 1);
      }
      let i = s[r];
      return ((e[t] = n && !i ? void 0 : (i || ``).replace(/%2F/g, `/`)), e);
    }, {}),
    pathname: a,
    pathnameBase: o,
    pattern: e,
  };
}
function De(e, t = !1, n = !0) {
  T(
    e === `*` || !e.endsWith(`*`) || e.endsWith(`/*`),
    `Route path "${e}" will be treated as if it were "${e.replace(/\*$/, `/*`)}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/, `/*`)}".`,
  );
  let r = [],
    i =
      `^` +
      e
        .replace(/\/*\*?$/, ``)
        .replace(/^\/*/, `/`)
        .replace(/[\\.*+^${}|()[\]]/g, `\\$&`)
        .replace(/\/:([\w-]+)(\?)?/g, (e, t, n, i, a) => {
          if (
            (r.push({
              paramName: t,
              isOptional: n != null,
            }),
            n)
          ) {
            let t = a.charAt(i + e.length);
            return t && t !== `/` ? `/([^\\/]*)` : `(?:/([^\\/]*))?`;
          }
          return `/([^\\/]+)`;
        })
        .replace(/\/([\w-]+)\?(\/|$)/g, `(/$1)?$2`);
  return (
    e.endsWith(`*`)
      ? (r.push({
          paramName: `*`,
        }),
        (i += e === `*` || e === `/*` ? `(.*)$` : `(?:\\/(.+)|\\/*)$`))
      : n
        ? (i += `\\/*$`)
        : e !== `` && e !== `/` && (i += `(?:(?=\\/|$))`),
    [new RegExp(i, t ? void 0 : `i`), r]
  );
}
function Oe(e) {
  try {
    return e
      .split(`/`)
      .map((e) => decodeURIComponent(e).replace(/\//g, `%2F`))
      .join(`/`);
  } catch (t) {
    return (
      T(
        !1,
        `The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`,
      ),
      e
    );
  }
}
function k(e, t) {
  if (t === `/`) return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith(`/`) ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== `/` ? null : e.slice(n) || `/`;
}
function ke(e, t = `/`) {
  let {
      pathname: n,
      search: r = ``,
      hash: i = ``,
    } = typeof e == `string` ? E(e) : e,
    a;
  return (
    n
      ? ((n = Fe(n)),
        (a =
          n.startsWith(`/`) || n.startsWith(`\\`)
            ? Ae(n.substring(1), `/`)
            : Ae(n, t)))
      : (a = t),
    {
      pathname: a,
      search: ze(r),
      hash: Be(i),
    }
  );
}
function Ae(e, t) {
  let n = Le(t).split(`/`);
  return (
    e.split(`/`).forEach((e) => {
      e === `..` ? n.length > 1 && n.pop() : e !== `.` && n.push(e);
    }),
    n.length > 1 ? n.join(`/`) : `/`
  );
}
function je(e, t, n, r) {
  return `Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
}
function Me(e) {
  return e.filter(
    (e, t) => t === 0 || (e.route.path && e.route.path.length > 0),
  );
}
function Ne(e) {
  let t = Me(e);
  return t.map((e, n) => (n === t.length - 1 ? e.pathname : e.pathnameBase));
}
function Pe(e, t, n, r = !1) {
  let i;
  typeof e == `string`
    ? (i = E(e))
    : ((i = {
        ...e,
      }),
      w(
        !i.pathname || !i.pathname.includes(`?`),
        je(`?`, `pathname`, `search`, i),
      ),
      w(
        !i.pathname || !i.pathname.includes(`#`),
        je(`#`, `pathname`, `hash`, i),
      ),
      w(!i.search || !i.search.includes(`#`), je(`#`, `search`, `hash`, i)));
  let a = e === `` || i.pathname === ``,
    o = a ? `/` : i.pathname,
    s;
  if (o == null) s = n;
  else {
    let e = t.length - 1;
    if (!r && o.startsWith(`..`)) {
      let t = o.split(`/`);
      for (; t[0] === `..`;) (t.shift(), --e);
      i.pathname = t.join(`/`);
    }
    s = e >= 0 ? t[e] : `/`;
  }
  let c = ke(i, s),
    l = o && o !== `/` && o.endsWith(`/`),
    u = (a || o === `.`) && n.endsWith(`/`);
  return (!c.pathname.endsWith(`/`) && (l || u) && (c.pathname += `/`), c);
}
var Fe = (e) => e.replace(/[\\/]{2,}/g, `/`),
  Ie = (e) => Fe(e.join(`/`));
function Le(e, t = 0) {
  let n = e.length;
  for (; n > t && e.charCodeAt(n - 1) === 47;) n--;
  return n === e.length ? e : e.slice(0, n);
}
var Re = (e) => Le(e).replace(/^\/*/, `/`),
  ze = (e) => (!e || e === `?` ? `` : e.startsWith(`?`) ? e : `?` + e),
  Be = (e) => (!e || e === `#` ? `` : e.startsWith(`#`) ? e : `#` + e),
  Ve = class {
    constructor(e, t, n, r = !1) {
      ((this.status = e),
        (this.statusText = t || ``),
        (this.internal = r),
        n instanceof Error
          ? ((this.data = n.toString()), (this.error = n))
          : (this.data = n));
    }
  };
function He(e) {
  return (
    e != null &&
    typeof e.status == `number` &&
    typeof e.statusText == `string` &&
    typeof e.internal == `boolean` &&
    `data` in e
  );
}
function Ue(e) {
  return Ie(e.map((e) => e.route.path).filter(Boolean)) || `/`;
}
var We =
  typeof window < `u` &&
  window.document !== void 0 &&
  window.document.createElement !== void 0;
function Ge(e, t) {
  let n = e;
  if (typeof n != `string` || !te.test(n))
    return {
      absoluteURL: void 0,
      isExternal: !1,
      to: n,
    };
  let r = n,
    i = !1;
  if (We)
    try {
      let e = new URL(window.location.href),
        r = ne.test(n) ? new URL(S(n, e.protocol)) : new URL(n),
        a = k(r.pathname, t);
      r.origin === e.origin && a != null
        ? (n = a + r.search + r.hash)
        : (i = !0);
    } catch {
      T(
        !1,
        `<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`,
      );
    }
  return {
    absoluteURL: r,
    isExternal: i,
    to: n,
  };
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
var Ke = new URL(`http://localhost`);
function qe(e) {
  if (e.createURL) return e.createURL(`/`);
  try {
    return new URL(e.createHref(`/`), Ke);
  } catch {
    return Ke;
  }
}
function Je(e, t) {
  return (
    e.origin === t.origin &&
    (e.origin !== `null` || (e.protocol === t.protocol && e.host === t.host))
  );
}
function Ye(e, t) {
  if (e.startsWith(`//`)) return !0;
  let n = t.protocol.toLowerCase();
  return e.toLowerCase().startsWith(n)
    ? t.host === `` || e.slice(n.length).startsWith(`//`)
    : !1;
}
function Xe(e, t, n, r) {
  let i = null;
  try {
    i = e == null ? null : new URL(e, n);
  } catch {}
  let a = new URL(t, n),
    o = i != null && !Je(i, n),
    s = !Je(a, n);
  if (r === `reject`) {
    if (o || s) throw Error(`External navigation is not allowed`);
  } else if (s && (i == null || !Ye(e, i) || !Je(i, a)))
    throw Error(`External navigation is not allowed`);
}
var Ze = [`POST`, `PUT`, `PATCH`, `DELETE`];
new Set(Ze);
var Qe = [`GET`, ...Ze];
new Set(Qe);
var $e = [
  `about:`,
  `blob:`,
  `chrome:`,
  `chrome-untrusted:`,
  `content:`,
  `data:`,
  `devtools:`,
  `file:`,
  `filesystem:`,
  `javascript:`,
];
function et(e) {
  try {
    return $e.includes(new URL(e).protocol);
  } catch {
    return !1;
  }
}
var tt = x.createContext(null);
tt.displayName = `DataRouter`;
var nt = x.createContext(null);
nt.displayName = `DataRouterState`;
var rt = x.createContext(!1);
function it() {
  return x.useContext(rt);
}
var at = x.createContext({
  isTransitioning: !1,
});
at.displayName = `ViewTransition`;
var ot = x.createContext(new Map());
ot.displayName = `Fetchers`;
var st = x.createContext(null);
st.displayName = `Await`;
var ct = x.createContext(null);
ct.displayName = `Navigation`;
var lt = x.createContext(null);
lt.displayName = `Location`;
var ut = x.createContext({
  outlet: null,
  matches: [],
  isDataRoute: !1,
});
ut.displayName = `Route`;
var dt = x.createContext(null);
dt.displayName = `RouteError`;
var ft = `REACT_ROUTER_ERROR`,
  pt = `REDIRECT`,
  mt = `ROUTE_ERROR_RESPONSE`;
function ht(e) {
  if (e.startsWith(`${ft}:${pt}:{`))
    try {
      let t = JSON.parse(e.slice(28));
      if (
        typeof t == `object` &&
        t &&
        typeof t.status == `number` &&
        typeof t.statusText == `string` &&
        typeof t.location == `string` &&
        typeof t.reloadDocument == `boolean` &&
        typeof t.replace == `boolean`
      )
        return t;
    } catch {}
}
function gt(e) {
  if (e.startsWith(`${ft}:${mt}:{`))
    try {
      let t = JSON.parse(e.slice(40));
      if (
        typeof t == `object` &&
        t &&
        typeof t.status == `number` &&
        typeof t.statusText == `string`
      )
        return new Ve(t.status, t.statusText, t.data);
    } catch {}
}
function _t(e, { relative: t } = {}) {
  w(vt(), `useHref() may be used only in the context of a <Router> component.`);
  let { basename: n, navigator: r } = x.useContext(ct),
    {
      hash: i,
      pathname: a,
      search: o,
    } = Et(e, {
      relative: t,
    }),
    s = a;
  return (
    n !== `/` && (s = a === `/` ? n : Ie([n, a])),
    r.createHref({
      pathname: s,
      search: o,
      hash: i,
    })
  );
}
function vt() {
  return x.useContext(lt) != null;
}
function yt() {
  return (
    w(
      vt(),
      `useLocation() may be used only in the context of a <Router> component.`,
    ),
    x.useContext(lt).location
  );
}
var bt = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;
function xt(e) {
  x.useContext(ct).static || x.useLayoutEffect(e);
}
function St() {
  let { isDataRoute: e } = x.useContext(ut);
  return e ? Ut() : Ct();
}
function Ct() {
  w(
    vt(),
    `useNavigate() may be used only in the context of a <Router> component.`,
  );
  let e = x.useContext(tt),
    { basename: t, navigator: n } = x.useContext(ct),
    { matches: r } = x.useContext(ut),
    { pathname: i } = yt(),
    a = JSON.stringify(Ne(r)),
    o = x.useRef(!1);
  return (
    xt(() => {
      o.current = !0;
    }),
    x.useCallback(
      (r, s = {}) => {
        if ((T(o.current, bt), !o.current)) return;
        if (typeof r == `number`) {
          n.go(r);
          return;
        }
        let c = Pe(r, JSON.parse(a), i, s.relative === `path`);
        (e == null &&
          t !== `/` &&
          (c.pathname = c.pathname === `/` ? t : Ie([t, c.pathname])),
          Xe(
            typeof r == `string` ? r : ce(r),
            n.createHref(c),
            qe(n),
            `reject`,
          ),
          (s.replace ? n.replace : n.push)(c, s.state, s));
      },
      [t, n, a, i, e],
    )
  );
}
var wt = x.createContext(null);
function Tt(e) {
  let t = x.useContext(ut).outlet;
  return x.useMemo(
    () =>
      t &&
      x.createElement(
        wt.Provider,
        {
          value: e,
        },
        t,
      ),
    [t, e],
  );
}
function Et(e, { relative: t } = {}) {
  let { matches: n } = x.useContext(ut),
    { pathname: r } = yt(),
    i = JSON.stringify(Ne(n));
  return x.useMemo(() => Pe(e, JSON.parse(i), r, t === `path`), [e, i, r, t]);
}
function Dt(e, t) {
  return Ot(e, t);
}
function Ot(e, t, n) {
  w(
    vt(),
    `useRoutes() may be used only in the context of a <Router> component.`,
  );
  let { navigator: r } = x.useContext(ct),
    { matches: i } = x.useContext(ut),
    a = i[i.length - 1],
    o = a ? a.params : {},
    s = a ? a.pathname : `/`,
    c = a ? a.pathnameBase : `/`,
    l = a && a.route;
  {
    let e = (l && l.path) || ``;
    Gt(
      s,
      !l || e.endsWith(`*`) || e.endsWith(`*?`),
      `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${s}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.
    Please change the parent <Route path="${e}"> to <Route path="${
      e === `/`
        ? `*`
        : `$ {
      e
    }
    /*`
    }">.`,
    );
  }
  let u = yt(),
    d;
  if (t) {
    let e = typeof t == `string` ? E(t) : t;
    (w(
      c === `/` || e.pathname?.startsWith(c),
      `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${c}" but pathname "${e.pathname}" was given in the \`location\` prop.`,
    ),
      (d = e));
  } else d = u;
  let f = d.pathname || `/`,
    p = f;
  if (c !== `/`) {
    let e = c.replace(/^\//, ``).split(`/`);
    p = `/` + f.replace(/^\//, ``).split(`/`).slice(e.length).join(`/`);
  }
  let m =
    n && n.state.matches.length
      ? n.state.matches.map((e) =>
          Object.assign(e, { route: n.manifest[e.route.id] || e.route }),
        )
      : de(e, { pathname: p });
  (T(
    l || m != null,
    `No routes matched location "${d.pathname}${d.search}${d.hash}" `,
  ),
    T(
      m == null ||
        m[m.length - 1].route.element !== void 0 ||
        m[m.length - 1].route.Component !== void 0 ||
        m[m.length - 1].route.lazy !== void 0,
      `Matched leaf route at location "${d.pathname}${d.search}${d.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`,
    ));
  let h = Ft(
    m &&
      m.map((e) =>
        Object.assign({}, e, {
          params: Object.assign({}, o, e.params),
          pathname: Ie([
            c,
            r.encodeLocation
              ? r.encodeLocation(
                  e.pathname
                    .replace(/%/g, `%25`)
                    .replace(/\?/g, `%3F`)
                    .replace(/#/g, `%23`),
                ).pathname
              : e.pathname,
          ]),
          pathnameBase:
            e.pathnameBase === `/`
              ? c
              : Ie([
                  c,
                  r.encodeLocation
                    ? r.encodeLocation(
                        e.pathnameBase
                          .replace(/%/g, `%25`)
                          .replace(/\?/g, `%3F`)
                          .replace(/#/g, `%23`),
                      ).pathname
                    : e.pathnameBase,
                ]),
        }),
      ),
    i,
    n,
  );
  return t && h
    ? x.createElement(
        lt.Provider,
        {
          value: {
            location: {
              pathname: `/`,
              search: ``,
              hash: ``,
              state: null,
              key: `default`,
              mask: void 0,
              ...d,
            },
            navigationType: `POP`,
          },
        },
        h,
      )
    : h;
}
function kt() {
  let e = Ht(),
    t = He(e)
      ? `${e.status} ${e.statusText}`
      : e instanceof Error
        ? e.message
        : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null,
    r = `rgba(200,200,200, 0.5)`,
    i = { padding: `0.5rem`, backgroundColor: r },
    a = { padding: `2px 4px`, backgroundColor: r },
    o = null;
  return (
    console.error(`Error handled by React Router default ErrorBoundary:`, e),
    (o = x.createElement(
      x.Fragment,
      null,
      x.createElement(`p`, null, `💿 Hey developer 👋`),
      x.createElement(
        `p`,
        null,
        `You can provide a way better UX than this when your app throws errors by providing your own `,
        x.createElement(`code`, { style: a }, `ErrorBoundary`),
        ` or`,
        ` `,
        x.createElement(`code`, { style: a }, `errorElement`),
        ` prop on your route.`,
      ),
    )),
    x.createElement(
      x.Fragment,
      null,
      x.createElement(`h2`, null, `Unexpected Application Error!`),
      x.createElement(`h3`, { style: { fontStyle: `italic` } }, t),
      n ? x.createElement(`pre`, { style: i }, n) : null,
      o,
    )
  );
}
var At = x.createElement(kt, null),
  jt = class extends x.Component {
    constructor(e) {
      (super(e),
        (this.state = {
          location: e.location,
          revalidation: e.revalidation,
          error: e.error,
        }));
    }
    static getDerivedStateFromError(e) {
      return { error: e };
    }
    static getDerivedStateFromProps(e, t) {
      return t.location !== e.location ||
        (t.revalidation !== `idle` && e.revalidation === `idle`)
        ? { error: e.error, location: e.location, revalidation: e.revalidation }
        : {
            error: e.error === void 0 ? t.error : e.error,
            location: t.location,
            revalidation: e.revalidation || t.revalidation,
          };
    }
    componentDidCatch(e, t) {
      this.props.onError
        ? this.props.onError(e, t)
        : console.error(
            `React Router caught the following error during render`,
            e,
          );
    }
    render() {
      let e = this.state.error;
      if (
        this.context &&
        typeof e == `object` &&
        e &&
        `digest` in e &&
        typeof e.digest == `string`
      ) {
        let t = gt(e.digest);
        t && (e = t);
      }
      let t =
        e === void 0
          ? this.props.children
          : x.createElement(
              ut.Provider,
              { value: this.props.routeContext },
              x.createElement(dt.Provider, {
                value: e,
                children: this.props.component,
              }),
            );
      return this.context ? x.createElement(Nt, { error: e }, t) : t;
    }
  };
jt.contextType = rt;
var Mt = new WeakMap();
function Nt({ children: e, error: t }) {
  let { basename: n, navigator: r } = x.useContext(ct);
  if (
    typeof t == `object` &&
    t &&
    `digest` in t &&
    typeof t.digest == `string`
  ) {
    let e = ht(t.digest);
    if (e) {
      let i = Mt.get(t);
      if (i) throw i;
      let a = Ge(e.location, n),
        o = a.absoluteURL || a.to;
      if ((Xe(e.location, o, qe(r), `allow-explicit`), et(o)))
        throw Error(`Invalid redirect location`);
      if (We && !Mt.get(t)) {
        if (a.isExternal || e.reloadDocument) window.location.href = o;
        else {
          let n = Promise.resolve().then(() =>
            window.__reactRouterDataRouter.navigate(a.to, {
              replace: e.replace,
            }),
          );
          throw (Mt.set(t, n), n);
        }
      }
      return x.createElement(`meta`, {
        httpEquiv: `refresh`,
        content: `0;url=${o}`,
      });
    }
  }
  return e;
}
function Pt({ routeContext: e, match: t, children: n }) {
  let r = x.useContext(tt);
  return (
    r &&
      r.static &&
      r.staticContext &&
      (t.route.errorElement || t.route.ErrorBoundary) &&
      (r.staticContext._deepestRenderedBoundaryId = t.route.id),
    x.createElement(ut.Provider, { value: e }, n)
  );
}
function Ft(e, t = [], n) {
  let r = n?.state;
  if (e == null) {
    if (!r) return null;
    if (r.errors) e = r.matches;
    else if (t.length === 0 && !r.initialized && r.matches.length > 0)
      e = r.matches;
    else return null;
  }
  let i = e,
    a = r?.errors;
  if (a != null) {
    let e = i.findIndex((e) => e.route.id && a?.[e.route.id] !== void 0);
    (w(
      e >= 0,
      `Could not find a matching route for errors on route IDs: ${Object.keys(a).join(`,`)}`,
    ),
      (i = i.slice(0, Math.min(i.length, e + 1))));
  }
  let o = !1,
    s = -1;
  if (n && r) {
    o = r.renderFallback;
    for (let e = 0; e < i.length; e++) {
      let t = i[e];
      if (
        ((t.route.HydrateFallback || t.route.hydrateFallbackElement) && (s = e),
        t.route.id)
      ) {
        let { loaderData: e, errors: a } = r,
          c =
            t.route.loader &&
            !e.hasOwnProperty(t.route.id) &&
            (!a || a[t.route.id] === void 0);
        if (t.route.lazy || c) {
          (n.isStatic && (o = !0), (i = s >= 0 ? i.slice(0, s + 1) : [i[0]]));
          break;
        }
      }
    }
  }
  let c = n?.onError,
    l =
      r && c
        ? (e, t) => {
            c(e, {
              location: r.location,
              params: r.matches?.[0]?.params ?? {},
              pattern: Ue(r.matches),
              errorInfo: t,
            });
          }
        : void 0;
  return i.reduceRight((e, n, c) => {
    let u,
      d = !1,
      f = null,
      p = null;
    r &&
      ((u = a && n.route.id ? a[n.route.id] : void 0),
      (f = n.route.errorElement || At),
      o &&
        (s < 0 && c === 0
          ? (Gt(
              `route-fallback`,
              !1,
              "No `HydrateFallback` element provided to render during initial hydration",
            ),
            (d = !0),
            (p = null))
          : s === c &&
            ((d = !0), (p = n.route.hydrateFallbackElement || null))));
    let m = t.concat(i.slice(0, c + 1)),
      h = () => {
        let t;
        return (
          (t = u
            ? f
            : d
              ? p
              : n.route.Component
                ? x.createElement(n.route.Component, null)
                : n.route.element
                  ? n.route.element
                  : e),
          x.createElement(Pt, {
            match: n,
            routeContext: { outlet: e, matches: m, isDataRoute: r != null },
            children: t,
          })
        );
      };
    return r && (n.route.ErrorBoundary || n.route.errorElement || c === 0)
      ? x.createElement(jt, {
          location: r.location,
          revalidation: r.revalidation,
          component: f,
          error: u,
          children: h(),
          routeContext: { outlet: null, matches: m, isDataRoute: !0 },
          onError: l,
        })
      : h();
  }, null);
}
function It(e) {
  return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function Lt(e) {
  let t = x.useContext(tt);
  return (w(t, It(e)), t);
}
function Rt(e) {
  let t = x.useContext(nt);
  return (w(t, It(e)), t);
}
function zt(e) {
  let t = x.useContext(ut);
  return (w(t, It(e)), t);
}
function Bt(e) {
  let t = zt(e),
    n = t.matches[t.matches.length - 1];
  return (
    w(n.route.id, `${e} can only be used on routes that contain a unique "id"`),
    n.route.id
  );
}
function Vt() {
  return Bt(`useRouteId`);
}
function Ht() {
  let e = x.useContext(dt),
    t = Rt(`useRouteError`),
    n = Bt(`useRouteError`);
  return e === void 0 ? t.errors?.[n] : e;
}
function Ut() {
  let { router: e } = Lt(`useNavigate`),
    t = Bt(`useNavigate`),
    n = x.useRef(!1);
  return (
    xt(() => {
      n.current = !0;
    }),
    x.useCallback(
      async (r, i = {}) => {
        (T(n.current, bt),
          n.current &&
            (typeof r == `number`
              ? await e.navigate(r)
              : await e.navigate(r, { fromRouteId: t, ...i })));
      },
      [e, t],
    )
  );
}
var Wt = {};
function Gt(e, t, n) {
  !t && !Wt[e] && ((Wt[e] = !0), T(!1, n));
}
x.memo(Kt);
function Kt({
  routes: e,
  manifest: t,
  future: n,
  state: r,
  isStatic: i,
  onError: a,
}) {
  return Ot(e, void 0, {
    manifest: t,
    state: r,
    isStatic: i,
    onError: a,
    future: n,
  });
}
function qt(e) {
  return Tt(e.context);
}
function Jt(e) {
  w(
    !1,
    `A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`,
  );
}
function Yt({
  basename: e = `/`,
  children: t = null,
  location: n,
  navigationType: r = `POP`,
  navigator: i,
  static: a = !1,
  useTransitions: o,
}) {
  w(
    !vt(),
    `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`,
  );
  let s = e.replace(/^\/*/, `/`),
    c = x.useMemo(
      () => ({
        basename: s,
        navigator: i,
        static: a,
        useTransitions: o,
        future: {},
      }),
      [s, i, a, o],
    );
  typeof n == `string` && (n = E(n));
  let {
      pathname: l = `/`,
      search: u = ``,
      hash: d = ``,
      state: f = null,
      key: p = `default`,
      mask: m,
    } = n,
    h = x.useMemo(() => {
      let e = k(l, s);
      return e == null
        ? null
        : {
            location: {
              pathname: e,
              search: u,
              hash: d,
              state: f,
              key: p,
              mask: m,
            },
            navigationType: r,
          };
    }, [s, l, u, d, f, p, r, m]);
  return (
    T(
      h != null,
      `<Router basename="${s}"> is not able to match the URL "${l}${u}${d}" because it does not start with the basename, so the <Router> won't render anything.`,
    ),
    h == null
      ? null
      : x.createElement(
          ct.Provider,
          {
            value: c,
          },
          x.createElement(lt.Provider, {
            children: t,
            value: h,
          }),
        )
  );
}
function Xt({ children: e, location: t }) {
  return Dt(Zt(e), t);
}
x.Component;
function Zt(e, t = []) {
  let n = [];
  return (
    x.Children.forEach(e, (e, r) => {
      if (!x.isValidElement(e)) return;
      let i = [...t, r];
      if (e.type === x.Fragment) {
        n.push.apply(n, Zt(e.props.children, i));
        return;
      }
      (w(
        e.type === Jt,
        `[${typeof e.type == `string` ? e.type : e.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`,
      ),
        w(
          !e.props.index || !e.props.children,
          `An index route cannot have child routes.`,
        ));
      let a = {
        id: e.props.id || i.join(`-`),
        caseSensitive: e.props.caseSensitive,
        element: e.props.element,
        Component: e.props.Component,
        index: e.props.index,
        path: e.props.path,
        middleware: e.props.middleware,
        loader: e.props.loader,
        action: e.props.action,
        hydrateFallbackElement: e.props.hydrateFallbackElement,
        HydrateFallback: e.props.HydrateFallback,
        errorElement: e.props.errorElement,
        ErrorBoundary: e.props.ErrorBoundary,
        hasErrorBoundary:
          e.props.hasErrorBoundary === !0 ||
          e.props.ErrorBoundary != null ||
          e.props.errorElement != null,
        shouldRevalidate: e.props.shouldRevalidate,
        handle: e.props.handle,
        lazy: e.props.lazy,
      };
      (e.props.children && (a.children = Zt(e.props.children, i)), n.push(a));
    }),
    n
  );
}
var Qt = `get`,
  $t = `application/x-www-form-urlencoded`;
function en(e) {
  return typeof HTMLElement < `u` && e instanceof HTMLElement;
}
function A(e) {
  return en(e) && e.tagName.toLowerCase() === `button`;
}
function tn(e) {
  return en(e) && e.tagName.toLowerCase() === `form`;
}
function nn(e) {
  return en(e) && e.tagName.toLowerCase() === `input`;
}
function rn(e) {
  return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
}
function an(e, t) {
  return e.button === 0 && (!t || t === `_self`) && !rn(e);
}
function on(e = ``) {
  return new URLSearchParams(
    typeof e == `string` || Array.isArray(e) || e instanceof URLSearchParams
      ? e
      : Object.keys(e).reduce((t, n) => {
          let r = e[n];
          return t.concat(Array.isArray(r) ? r.map((e) => [n, e]) : [[n, r]]);
        }, []),
  );
}
function sn(e, t) {
  let n = on(e);
  return (
    t &&
      t.forEach((e, r) => {
        n.has(r) ||
          t.getAll(r).forEach((e) => {
            n.append(r, e);
          });
      }),
    n
  );
}
var cn = null;
function ln() {
  if (cn === null)
    try {
      (new FormData(document.createElement(`form`), 0), (cn = !1));
    } catch {
      cn = !0;
    }
  return cn;
}
var un = new Set([
  `application/x-www-form-urlencoded`,
  `multipart/form-data`,
  `text/plain`,
]);
function dn(e) {
  return e != null && !un.has(e)
    ? (T(
        !1,
        `"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${$t}"`,
      ),
      null)
    : e;
}
function fn(e, t) {
  let n, r, i, a, o;
  if (tn(e)) {
    let o = e.getAttribute(`action`);
    ((r = o ? k(o, t) : null),
      (n = e.getAttribute(`method`) || Qt),
      (i = dn(e.getAttribute(`enctype`)) || $t),
      (a = new FormData(e)));
  } else if (A(e) || (nn(e) && (e.type === `submit` || e.type === `image`))) {
    let o = e.form;
    if (o == null)
      throw Error(
        `Cannot submit a <button> or <input type="submit"> without a <form>`,
      );
    let s = e.getAttribute(`formaction`) || o.getAttribute(`action`);
    if (
      ((r = s ? k(s, t) : null),
      (n = e.getAttribute(`formmethod`) || o.getAttribute(`method`) || Qt),
      (i =
        dn(e.getAttribute(`formenctype`)) ||
        dn(o.getAttribute(`enctype`)) ||
        $t),
      (a = new FormData(o, e)),
      !ln())
    ) {
      let { name: t, type: n, value: r } = e;
      if (n === `image`) {
        let e = t ? `${t}.` : ``;
        (a.append(`${e}x`, `0`), a.append(`${e}y`, `0`));
      } else t && a.append(t, r);
    }
  } else if (en(e))
    throw Error(
      `Cannot submit element that is not <form>, <button>, or <input type="submit|image">`,
    );
  else ((n = Qt), (r = null), (i = $t), (o = e));
  return (
    a && i === `text/plain` && ((o = a), (a = void 0)),
    {
      action: r,
      method: n.toLowerCase(),
      encType: i,
      formData: a,
      body: o,
    }
  );
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
function pn(e, t) {
  if (e === !1 || e == null) throw Error(t);
}
function mn(e, t, n, r) {
  let i =
    typeof e == `string`
      ? new URL(
          e,
          typeof window > `u`
            ? `server://singlefetch/`
            : window.location.origin,
        )
      : e;
  return (
    (i.pathname = n
      ? i.pathname.endsWith(`/`)
        ? `${i.pathname}_.${r}`
        : `${i.pathname}.${r}`
      : i.pathname === `/`
        ? `_root.${r}`
        : t && k(i.pathname, t) === `/`
          ? `${Le(t)}/_root.${r}`
          : `${Le(i.pathname)}.${r}`),
    i
  );
}
async function hn(e, t) {
  if (e.id in t) return t[e.id];
  try {
    let n = await ee(() => import(e.module), [], document.baseURI);
    return ((t[e.id] = n), n);
  } catch (t) {
    return (
      console.error(
        `Error loading route module \`${e.module}\`, reloading page...`,
      ),
      console.error(t),
      window.__reactRouterContext && window.__reactRouterContext.isSpaMode,
      window.location.reload(),
      new Promise(() => {})
    );
  }
}
function gn(e) {
  return e != null && typeof e.page == `string`;
}
function _n(e) {
  return e == null
    ? !1
    : e.href == null
      ? e.rel === `preload` &&
        typeof e.imageSrcSet == `string` &&
        typeof e.imageSizes == `string`
      : typeof e.rel == `string` && typeof e.href == `string`;
}
async function vn(e, t, n) {
  return Cn(
    (
      await Promise.all(
        e.map(async (e) => {
          let r = t.routes[e.route.id];
          if (r) {
            let e = await hn(r, n);
            return e.links ? e.links() : [];
          }
          return [];
        }),
      )
    )
      .flat(1)
      .filter(_n)
      .filter((e) => e.rel === `stylesheet` || e.rel === `preload`)
      .map((e) =>
        e.rel === `stylesheet`
          ? {
              ...e,
              rel: `prefetch`,
              as: `style`,
            }
          : {
              ...e,
              rel: `prefetch`,
            },
      ),
  );
}
function yn(e, t, n, r, i, a) {
  let o = (e, t) => !n[t] || e.route.id !== n[t].route.id,
    s = (e, t) =>
      n[t].pathname !== e.pathname ||
      (n[t].route.path?.endsWith(`*`) && n[t].params[`*`] !== e.params[`*`]);
  return a === `assets`
    ? t.filter((e, t) => o(e, t) || s(e, t))
    : a === `data`
      ? t.filter((t, a) => {
          let c = r.routes[t.route.id];
          if (!c || !c.hasLoader) return !1;
          if (o(t, a) || s(t, a)) return !0;
          if (t.route.shouldRevalidate) {
            let r = t.route.shouldRevalidate({
              currentUrl: new URL(
                i.pathname + i.search + i.hash,
                window.origin,
              ),
              currentParams: n[0]?.params || {},
              nextUrl: new URL(e, window.origin),
              nextParams: t.params,
              defaultShouldRevalidate: !0,
            });
            if (typeof r == `boolean`) return r;
          }
          return !0;
        })
      : [];
}
function bn(e, t, { includeHydrateFallback: n } = {}) {
  return xn(
    e
      .map((e) => {
        let r = t.routes[e.route.id];
        if (!r) return [];
        let i = [r.module];
        return (
          r.clientActionModule && (i = i.concat(r.clientActionModule)),
          r.clientLoaderModule && (i = i.concat(r.clientLoaderModule)),
          n &&
            r.hydrateFallbackModule &&
            (i = i.concat(r.hydrateFallbackModule)),
          r.imports && (i = i.concat(r.imports)),
          i
        );
      })
      .flat(1),
  );
}
function xn(e) {
  return [...new Set(e)];
}
function Sn(e) {
  let t = {},
    n = Object.keys(e).sort();
  for (let r of n) t[r] = e[r];
  return t;
}
function Cn(e, t) {
  let n = new Set(),
    r = new Set(t);
  return e.reduce((e, i) => {
    if (t && !gn(i) && i.as === `script` && i.href && r.has(i.href)) return e;
    let a = JSON.stringify(Sn(i));
    return (
      n.has(a) ||
        (n.add(a),
        e.push({
          key: a,
          link: i,
        })),
      e
    );
  }, []);
}
function wn() {
  let e = x.useContext(tt);
  return (
    pn(
      e,
      `You must render this element inside a <DataRouterContext.Provider> element`,
    ),
    e
  );
}
function Tn() {
  let e = x.useContext(nt);
  return (
    pn(
      e,
      `You must render this element inside a <DataRouterStateContext.Provider> element`,
    ),
    e
  );
}
var En = x.createContext(void 0);
En.displayName = `FrameworkContext`;
function Dn() {
  let e = x.useContext(En);
  return (
    pn(e, `You must render this element inside a <HydratedRouter> element`),
    e
  );
}
function On(e, t) {
  let n = x.useContext(En),
    [r, i] = x.useState(!1),
    [a, o] = x.useState(!1),
    {
      onFocus: s,
      onBlur: c,
      onMouseEnter: l,
      onMouseLeave: u,
      onTouchStart: d,
    } = t,
    f = x.useRef(null);
  (x.useEffect(() => {
    if ((e === `render` && o(!0), e === `viewport`)) {
      let e = new IntersectionObserver(
        (e) => {
          e.forEach((e) => {
            o(e.isIntersecting);
          });
        },
        {
          threshold: 0.5,
        },
      );
      return (
        f.current && e.observe(f.current),
        () => {
          e.disconnect();
        }
      );
    }
  }, [e]),
    x.useEffect(() => {
      if (r) {
        let e = setTimeout(() => {
          o(!0);
        }, 100);
        return () => {
          clearTimeout(e);
        };
      }
    }, [r]));
  let p = () => {
      i(!0);
    },
    m = () => {
      (i(!1), o(!1));
    };
  return n
    ? e === `intent`
      ? [
          a,
          f,
          {
            onFocus: kn(s, p),
            onBlur: kn(c, m),
            onMouseEnter: kn(l, p),
            onMouseLeave: kn(u, m),
            onTouchStart: kn(d, p),
          },
        ]
      : [a, f, {}]
    : [!1, f, {}];
}
function kn(e, t) {
  return (n) => {
    (e && e(n), n.defaultPrevented || t(n));
  };
}
function An({ page: e, ...t }) {
  let n = it(),
    { nonce: r } = Dn(),
    { router: i } = wn(),
    a = x.useMemo(() => de(i.routes, e, i.basename), [i.routes, e, i.basename]);
  return a
    ? (t.nonce == null &&
        r &&
        (t = {
          ...t,
          nonce: r,
        }),
      n
        ? x.createElement(Mn, {
            page: e,
            matches: a,
            ...t,
          })
        : x.createElement(Nn, {
            page: e,
            matches: a,
            ...t,
          }))
    : null;
}
function jn(e) {
  let { manifest: t, routeModules: n } = Dn(),
    [r, i] = x.useState([]);
  return (
    x.useEffect(() => {
      let r = !1;
      return (
        vn(e, t, n).then((e) => {
          r || i(e);
        }),
        () => {
          r = !0;
        }
      );
    }, [e, t, n]),
    r
  );
}
function Mn({ page: e, matches: t, ...n }) {
  let r = yt(),
    { future: i } = Dn(),
    { basename: a } = wn(),
    o = x.useMemo(() => {
      if (e === r.pathname + r.search + r.hash) return [];
      let n = mn(e, a, i.v8_trailingSlashAwareDataRequests, `rsc`),
        o = !1,
        s = [];
      for (let e of t)
        typeof e.route.shouldRevalidate == `function`
          ? (o = !0)
          : s.push(e.route.id);
      return (
        o && s.length > 0 && n.searchParams.set(`_routes`, s.join(`,`)),
        [n.pathname + n.search]
      );
    }, [a, i.v8_trailingSlashAwareDataRequests, e, r, t]);
  return x.createElement(
    x.Fragment,
    null,
    o.map((e) =>
      x.createElement(`link`, {
        key: e,
        rel: `prefetch`,
        as: `fetch`,
        href: e,
        ...n,
      }),
    ),
  );
}
function Nn({ page: e, matches: t, ...n }) {
  let r = yt(),
    { future: i, manifest: a, routeModules: o } = Dn(),
    { basename: s } = wn(),
    { loaderData: c, matches: l } = Tn(),
    u = x.useMemo(() => yn(e, t, l, a, r, `data`), [e, t, l, a, r]),
    d = x.useMemo(() => yn(e, t, l, a, r, `assets`), [e, t, l, a, r]),
    f = x.useMemo(() => {
      if (e === r.pathname + r.search + r.hash) return [];
      let n = new Set(),
        l = !1;
      if (
        (t.forEach((e) => {
          let t = a.routes[e.route.id];
          t &&
            t.hasLoader &&
            ((!u.some((t) => t.route.id === e.route.id) &&
              e.route.id in c &&
              o[e.route.id]?.shouldRevalidate) ||
            t.hasClientLoader
              ? (l = !0)
              : n.add(e.route.id));
        }),
        n.size === 0)
      )
        return [];
      let d = mn(e, s, i.v8_trailingSlashAwareDataRequests, `data`);
      return (
        l &&
          n.size > 0 &&
          d.searchParams.set(
            `_routes`,
            t
              .filter((e) => n.has(e.route.id))
              .map((e) => e.route.id)
              .join(`,`),
          ),
        [d.pathname + d.search]
      );
    }, [s, i.v8_trailingSlashAwareDataRequests, c, r, a, u, t, e, o]),
    p = x.useMemo(() => bn(d, a), [d, a]),
    m = jn(d);
  return x.createElement(
    x.Fragment,
    null,
    f.map((e) =>
      x.createElement(`link`, {
        key: e,
        rel: `prefetch`,
        as: `fetch`,
        href: e,
        ...n,
      }),
    ),
    p.map((e) =>
      x.createElement(`link`, {
        key: e,
        rel: `modulepreload`,
        href: e,
        ...n,
      }),
    ),
    m.map(({ key: e, link: t }) =>
      x.createElement(`link`, {
        key: e,
        nonce: n.nonce,
        ...t,
        crossOrigin: t.crossOrigin ?? n.crossOrigin,
      }),
    ),
  );
}
function Pn(...e) {
  return (t) => {
    e.forEach((e) => {
      typeof e == `function` ? e(t) : e != null && (e.current = t);
    });
  };
}
x.Component;
var Fn =
  typeof window < `u` &&
  window.document !== void 0 &&
  window.document.createElement !== void 0;
try {
  Fn && (window.__reactRouterVersion = `7.18.4`);
} catch {}
function In({ basename: e, children: t, useTransitions: n, window: r }) {
  let i = x.useRef();
  i.current ??= ie({
    window: r,
    v5Compat: !0,
  });
  let a = i.current,
    [o, s] = x.useState({
      action: a.action,
      location: a.location,
    }),
    c = x.useCallback(
      (e) => {
        n === !1 ? s(e) : x.startTransition(() => s(e));
      },
      [n],
    );
  return (
    x.useLayoutEffect(() => a.listen(c), [a, c]),
    x.createElement(Yt, {
      basename: e,
      children: t,
      location: o.location,
      navigationType: o.action,
      navigator: a,
      useTransitions: n,
    })
  );
}
var j = x.forwardRef(function (
  {
    onClick: e,
    discover: t = `render`,
    prefetch: n = `none`,
    relative: r,
    reloadDocument: i,
    replace: a,
    mask: o,
    state: s,
    target: c,
    to: l,
    preventScrollReset: u,
    viewTransition: d,
    defaultShouldRevalidate: f,
    ...p
  },
  m,
) {
  let { basename: h, navigator: g, useTransitions: _ } = x.useContext(ct),
    v = typeof l == `string` && te.test(l),
    y = Ge(l, h);
  l = y.to;
  let b = _t(l, {
      relative: r,
    }),
    ee = yt(),
    ne = null;
  if (o) {
    let e = Pe(o, [], ee.mask ? ee.mask.pathname : `/`, !0);
    (h !== `/` && (e.pathname = e.pathname === `/` ? h : Ie([h, e.pathname])),
      (ne = g.createHref(e)));
  }
  let [S, re, C] = On(n, p),
    ie = Vn(l, {
      replace: a,
      mask: o,
      state: s,
      target: c,
      preventScrollReset: u,
      relative: r,
      viewTransition: d,
      defaultShouldRevalidate: f,
      useTransitions: _,
    });
  function w(t) {
    (e && e(t), t.defaultPrevented || ie(t));
  }
  let T = !(y.isExternal || i),
    ae = x.createElement(`a`, {
      ...p,
      ...C,
      href: (T ? ne : void 0) || y.absoluteURL || b,
      onClick: T ? w : e,
      ref: Pn(m, re),
      target: c,
      "data-discover": !v && t === `render` ? `true` : void 0,
    });
  return S && !v
    ? x.createElement(
        x.Fragment,
        null,
        ae,
        x.createElement(An, {
          page: b,
        }),
      )
    : ae;
});
j.displayName = `Link`;
var Ln = x.forwardRef(function (
  {
    "aria-current": e = `page`,
    caseSensitive: t = !1,
    className: n = ``,
    end: r = !1,
    style: i,
    to: a,
    viewTransition: o,
    children: s,
    ...c
  },
  l,
) {
  let u = Et(a, {
      relative: c.relative,
    }),
    d = yt(),
    f = x.useContext(nt),
    { navigator: p, basename: m } = x.useContext(ct),
    h = f != null && qn(u) && o === !0,
    g = p.encodeLocation ? p.encodeLocation(u).pathname : u.pathname,
    _ = d.pathname,
    v =
      f && f.navigation && f.navigation.location
        ? f.navigation.location.pathname
        : null;
  (t ||
    ((_ = _.toLowerCase()),
    (v = v ? v.toLowerCase() : null),
    (g = g.toLowerCase())),
    v && m && (v = k(v, m) || v));
  let y = g !== `/` && g.endsWith(`/`) ? g.length - 1 : g.length,
    b = _ === g || (!r && _.startsWith(g) && _.charAt(y) === `/`),
    ee =
      v != null &&
      (v === g || (!r && v.startsWith(g) && v.charAt(g.length) === `/`)),
    te = {
      isActive: b,
      isPending: ee,
      isTransitioning: h,
    },
    ne = b ? e : void 0,
    S;
  S =
    typeof n == `function`
      ? n(te)
      : [
          n,
          b ? `active` : null,
          ee ? `pending` : null,
          h ? `transitioning` : null,
        ]
          .filter(Boolean)
          .join(` `);
  let re = typeof i == `function` ? i(te) : i;
  return x.createElement(
    j,
    {
      ...c,
      "aria-current": ne,
      className: S,
      ref: l,
      style: re,
      to: a,
      viewTransition: o,
    },
    typeof s == `function` ? s(te) : s,
  );
});
Ln.displayName = `NavLink`;
var Rn = x.forwardRef(
  (
    {
      discover: e = `render`,
      fetcherKey: t,
      navigate: n,
      reloadDocument: r,
      replace: i,
      state: a,
      method: o = Qt,
      action: s,
      onSubmit: c,
      relative: l,
      preventScrollReset: u,
      viewTransition: d,
      defaultShouldRevalidate: f,
      ...p
    },
    m,
  ) => {
    let { useTransitions: h } = x.useContext(ct),
      g = Gn(),
      _ = Kn(s, {
        relative: l,
      }),
      v = o.toLowerCase() === `get` ? `get` : `post`,
      y = typeof s == `string` && te.test(s);
    return x.createElement(`form`, {
      ref: m,
      method: v,
      action: _,
      onSubmit: r
        ? c
        : (e) => {
            if ((c && c(e), e.defaultPrevented)) return;
            e.preventDefault();
            let r = e.nativeEvent.submitter,
              s = r?.getAttribute(`formmethod`) || o,
              p = () =>
                g(r || e.currentTarget, {
                  fetcherKey: t,
                  method: s,
                  navigate: n,
                  replace: i,
                  state: a,
                  relative: l,
                  preventScrollReset: u,
                  viewTransition: d,
                  defaultShouldRevalidate: f,
                });
            h && n !== !1 ? x.startTransition(() => p()) : p();
          },
      ...p,
      "data-discover": !y && e === `render` ? `true` : void 0,
    });
  },
);
Rn.displayName = `Form`;
function zn(e) {
  return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function Bn(e) {
  let t = x.useContext(tt);
  return (w(t, zn(e)), t);
}
function Vn(
  e,
  {
    target: t,
    replace: n,
    mask: r,
    state: i,
    preventScrollReset: a,
    relative: o,
    viewTransition: s,
    defaultShouldRevalidate: c,
    useTransitions: l,
  } = {},
) {
  let u = St(),
    d = yt(),
    f = Et(e, {
      relative: o,
    });
  return x.useCallback(
    (p) => {
      if (an(p, t)) {
        p.preventDefault();
        let t = n === void 0 ? ce(d) === ce(f) : n,
          m = () =>
            u(e, {
              replace: t,
              mask: r,
              state: i,
              preventScrollReset: a,
              relative: o,
              viewTransition: s,
              defaultShouldRevalidate: c,
            });
        l ? x.startTransition(() => m()) : m();
      }
    },
    [d, u, f, n, r, i, t, e, a, o, s, c, l],
  );
}
function Hn(e) {
  T(
    typeof URLSearchParams < `u`,
    "You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.",
  );
  let t = x.useRef(on(e)),
    n = x.useRef(!1),
    r = yt(),
    i = x.useMemo(() => sn(r.search, n.current ? null : t.current), [r.search]),
    a = St();
  return [
    i,
    x.useCallback(
      (e, t) => {
        let r = on(typeof e == `function` ? e(new URLSearchParams(i)) : e);
        ((n.current = !0), a(`?` + r, t));
      },
      [a, i],
    ),
  ];
}
var Un = 0,
  Wn = () => `__${String(++Un)}__`;
function Gn() {
  let { router: e } = Bn(`useSubmit`),
    { basename: t } = x.useContext(ct),
    n = Vt(),
    r = e.fetch,
    i = e.navigate;
  return x.useCallback(
    async (e, a = {}) => {
      let { action: o, method: s, encType: c, formData: l, body: u } = fn(e, t);
      if (a.navigate === !1) {
        let e = a.fetcherKey || Wn();
        await r(e, n, a.action || o, {
          defaultShouldRevalidate: a.defaultShouldRevalidate,
          preventScrollReset: a.preventScrollReset,
          formData: l,
          body: u,
          formMethod: a.method || s,
          formEncType: a.encType || c,
          flushSync: a.flushSync,
        });
      } else
        await i(a.action || o, {
          defaultShouldRevalidate: a.defaultShouldRevalidate,
          preventScrollReset: a.preventScrollReset,
          formData: l,
          body: u,
          formMethod: a.method || s,
          formEncType: a.encType || c,
          replace: a.replace,
          state: a.state,
          fromRouteId: n,
          flushSync: a.flushSync,
          viewTransition: a.viewTransition,
        });
    },
    [r, i, t, n],
  );
}
function Kn(e, { relative: t } = {}) {
  let { basename: n } = x.useContext(ct),
    r = x.useContext(ut);
  w(r, `useFormAction must be used inside a RouteContext`);
  let [i] = r.matches.slice(-1),
    a = {
      ...Et(e || `.`, {
        relative: t,
      }),
    },
    o = yt();
  if (e == null) {
    a.search = o.search;
    let e = new URLSearchParams(a.search),
      t = e.getAll(`index`);
    if (t.some((e) => e === ``)) {
      (e.delete(`index`),
        t.filter((e) => e).forEach((t) => e.append(`index`, t)));
      let n = e.toString();
      a.search = n ? `?${n}` : ``;
    }
  }
  return (
    (!e || e === `.`) &&
      i.route.index &&
      (a.search = a.search ? a.search.replace(/^\?/, `?index&`) : `?index`),
    n !== `/` && (a.pathname = a.pathname === `/` ? n : Ie([n, a.pathname])),
    ce(a)
  );
}
function qn(e, { relative: t } = {}) {
  let n = x.useContext(at);
  w(
    n != null,
    "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?",
  );
  let { basename: r } = Bn(`useViewTransitionState`),
    i = Et(e, {
      relative: t,
    });
  if (!n.isTransitioning) return !1;
  let a = k(n.currentLocation.pathname, r) || n.currentLocation.pathname,
    o = k(n.nextLocation.pathname, r) || n.nextLocation.pathname;
  return Te(i.pathname, o) != null || Te(i.pathname, a) != null;
}
var Jn = g(),
  Yn = o((e) => {
    var t = Symbol.for(`react.transitional.element`),
      n = Symbol.for(`react.fragment`);
    function r(e, n, r) {
      var i = null;
      if (
        (r !== void 0 && (i = `` + r),
        n.key !== void 0 && (i = `` + n.key),
        `key` in n)
      )
        for (var a in ((r = {}), n)) a !== `key` && (r[a] = n[a]);
      else r = n;
      return (
        (n = r.ref),
        {
          $$typeof: t,
          type: e,
          key: i,
          ref: n === void 0 ? null : n,
          props: r,
        }
      );
    }
    ((e.Fragment = n), (e.jsx = r), (e.jsxs = r));
  }),
  M = o((e, t) => {
    t.exports = Yn();
  })(),
  Xn = {
    arrow: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M5 12h14`,
        }),
        (0, M.jsx)(`path`, {
          d: `m13 6 6 6-6 6`,
        }),
      ],
    }),
    arrowUpRight: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M7 17 17 7`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 7h9v9`,
        }),
      ],
    }),
    arrowUp: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M12 19V5`,
        }),
        (0, M.jsx)(`path`, {
          d: `m6 11 6-6 6 6`,
        }),
      ],
    }),
    chevronLeft: (0, M.jsx)(`path`, {
      d: `m15 18-6-6 6-6`,
    }),
    chevronRight: (0, M.jsx)(`path`, {
      d: `m9 18 6-6-6-6`,
    }),
    chevronDown: (0, M.jsx)(`path`, {
      d: `m6 9 6 6 6-6`,
    }),
    plus: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M12 5v14`,
        }),
        (0, M.jsx)(`path`, {
          d: `M5 12h14`,
        }),
      ],
    }),
    heart: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27`,
        }),
      ],
    }),
    chart: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M3 3v18h18`,
        }),
        (0, M.jsx)(`path`, {
          d: `M18 17V9`,
        }),
        (0, M.jsx)(`path`, {
          d: `M13 17V5`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 17v-3`,
        }),
      ],
    }),
    book: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z`,
        }),
      ],
    }),
    fileSearch: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h5`,
        }),
        (0, M.jsx)(`path`, {
          d: `M14 2v6h6v3`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 13h3`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 9h2`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `16.5`,
          cy: `16.5`,
          r: `3`,
        }),
        (0, M.jsx)(`path`, {
          d: `m21 21-2.3-2.3`,
        }),
      ],
    }),
    sprout: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M7 20h10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M10 20c5.5-2.5.8-6.4 3-10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z`,
        }),
      ],
    }),
    users: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `9`,
          cy: `7`,
          r: `4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M22 21v-2a4 4 0 0 0-3-3.87`,
        }),
        (0, M.jsx)(`path`, {
          d: `M16 3.13a4 4 0 0 1 0 7.75`,
        }),
      ],
    }),
    user: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `7`,
          r: `4`,
        }),
      ],
    }),
    shield: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,
        }),
        (0, M.jsx)(`path`, {
          d: `m9 12 2 2 4-4`,
        }),
      ],
    }),
    file: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M14 2v4a2 2 0 0 0 2 2h4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M10 9H8`,
        }),
        (0, M.jsx)(`path`, {
          d: `M16 13H8`,
        }),
        (0, M.jsx)(`path`, {
          d: `M16 17H8`,
        }),
      ],
    }),
    pin: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `10`,
          r: `3`,
        }),
      ],
    }),
    calendar: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`rect`, {
          x: `3`,
          y: `4`,
          width: `18`,
          height: `18`,
          rx: `2`,
        }),
        (0, M.jsx)(`path`, {
          d: `M16 2v4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 2v4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3 10h18`,
        }),
      ],
    }),
    mail: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`rect`, {
          x: `2`,
          y: `4`,
          width: `20`,
          height: `16`,
          rx: `2`,
        }),
        (0, M.jsx)(`path`, {
          d: `m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7`,
        }),
      ],
    }),
    phone: (0, M.jsx)(`path`, {
      d: `M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z`,
    }),
    globe: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20`,
        }),
        (0, M.jsx)(`path`, {
          d: `M2 12h20`,
        }),
      ],
    }),
    target: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `6`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `2`,
        }),
      ],
    }),
    eye: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,
        }),
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `3`,
        }),
      ],
    }),
    scale: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z`,
        }),
        (0, M.jsx)(`path`, {
          d: `m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M7 21h10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 3v18`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2`,
        }),
      ],
    }),
    refresh: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8`,
        }),
        (0, M.jsx)(`path`, {
          d: `M21 3v5h-5`,
        }),
        (0, M.jsx)(`path`, {
          d: `M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 16H3v5`,
        }),
      ],
    }),
    handshake: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `m11 17 2 2a1 1 0 1 0 3-3`,
        }),
        (0, M.jsx)(`path`, {
          d: `m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4`,
        }),
        (0, M.jsx)(`path`, {
          d: `m21 3 1 11h-2`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3 4h8`,
        }),
      ],
    }),
    mountain: (0, M.jsx)(`path`, {
      d: `m8 3 4 8 5-5 5 15H2L8 3z`,
    }),
    briefcase: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16`,
        }),
        (0, M.jsx)(`rect`, {
          x: `2`,
          y: `6`,
          width: `20`,
          height: `14`,
          rx: `2`,
        }),
      ],
    }),
    send: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z`,
        }),
        (0, M.jsx)(`path`, {
          d: `m21.854 2.147-10.94 10.939`,
        }),
      ],
    }),
    info: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 16v-4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 8h.01`,
        }),
      ],
    }),
    download: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,
        }),
        (0, M.jsx)(`path`, {
          d: `m7 10 5 5 5-5`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 15V3`,
        }),
      ],
    }),
    message: (0, M.jsx)(`path`, {
      d: `M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z`,
    }),
    check: (0, M.jsx)(`path`, {
      d: `M20 6 9 17l-5-5`,
    }),
    checkCircle: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`path`, {
          d: `m9 12 2 2 4-4`,
        }),
      ],
    }),
    coins: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `8`,
          cy: `8`,
          r: `6`,
        }),
        (0, M.jsx)(`path`, {
          d: `M18.09 10.37A6 6 0 1 1 10.34 18`,
        }),
        (0, M.jsx)(`path`, {
          d: `M7 6h1v4`,
        }),
        (0, M.jsx)(`path`, {
          d: `m16.71 13.88.7.71-2.82 2.82`,
        }),
      ],
    }),
    search: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `11`,
          cy: `11`,
          r: `8`,
        }),
        (0, M.jsx)(`path`, {
          d: `m21 21-4.3-4.3`,
        }),
      ],
    }),
    clock: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`path`, {
          d: `M12 6v6l4 2`,
        }),
      ],
    }),
    layers: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z`,
        }),
        (0, M.jsx)(`path`, {
          d: `m2 12 9.17 4.17a2 2 0 0 0 1.66 0L22 12`,
        }),
        (0, M.jsx)(`path`, {
          d: `m2 17 9.17 4.17a2 2 0 0 0 1.66 0L22 17`,
        }),
      ],
    }),
    building: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`rect`, {
          x: `4`,
          y: `2`,
          width: `16`,
          height: `20`,
          rx: `2`,
        }),
        (0, M.jsx)(`path`, {
          d: `M9 22v-4h6v4`,
        }),
        (0, M.jsx)(`path`, {
          d: `M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01`,
        }),
      ],
    }),
    expand: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M15 3h6v6`,
        }),
        (0, M.jsx)(`path`, {
          d: `M9 21H3v-6`,
        }),
        (0, M.jsx)(`path`, {
          d: `M21 3l-7 7`,
        }),
        (0, M.jsx)(`path`, {
          d: `M3 21l7-7`,
        }),
      ],
    }),
    inbox: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M22 12h-6l-2 3h-4l-2-3H2`,
        }),
        (0, M.jsx)(`path`, {
          d: `M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z`,
        }),
      ],
    }),
    quote: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z`,
        }),
        (0, M.jsx)(`path`, {
          d: `M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z`,
        }),
      ],
    }),
    newspaper: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M15 18h-5`,
        }),
        (0, M.jsx)(`path`, {
          d: `M18 14h-8`,
        }),
        (0, M.jsx)(`path`, {
          d: `M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2`,
        }),
        (0, M.jsx)(`rect`, {
          x: `10`,
          y: `6`,
          width: `8`,
          height: `4`,
          rx: `1`,
        }),
      ],
    }),
    pause: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`rect`, {
          x: `6`,
          y: `4`,
          width: `4`,
          height: `16`,
          rx: `1`,
        }),
        (0, M.jsx)(`rect`, {
          x: `14`,
          y: `4`,
          width: `4`,
          height: `16`,
          rx: `1`,
        }),
      ],
    }),
    play: (0, M.jsx)(`path`, {
      d: `M7 4.5v15a1 1 0 0 0 1.5.86l12-7.5a1 1 0 0 0 0-1.72l-12-7.5A1 1 0 0 0 7 4.5Z`,
    }),
    compass: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`circle`, {
          cx: `12`,
          cy: `12`,
          r: `10`,
        }),
        (0, M.jsx)(`path`, {
          d: `m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z`,
        }),
      ],
    }),
    menu: (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`path`, {
          d: `M4 7h16`,
        }),
        (0, M.jsx)(`path`, {
          d: `M4 12h16`,
        }),
        (0, M.jsx)(`path`, {
          d: `M4 17h16`,
        }),
      ],
    }),
    close: (0, M.jsx)(`path`, {
      d: `M18 6 6 18M6 6l12 12`,
    }),
  };
function N({
  name: e,
  size: t = 24,
  className: n = ``,
  strokeWidth: r = 1.75,
}) {
  return (0, M.jsx)(`svg`, {
    className: `icon ${n}`,
    width: t,
    height: t,
    viewBox: `0 0 24 24`,
    fill: `none`,
    stroke: `currentColor`,
    strokeWidth: r,
    strokeLinecap: `round`,
    strokeLinejoin: `round`,
    "aria-hidden": `true`,
    children: Xn[e],
  });
}
var P = {
    name: `Poor Women Support Organization`,
    short: `PWSO`,
    established: `2017`,
    registration: `4203`,
    registrar: `Ministry of Economy`,
    email: `Info.pwso2017@gmail.com`,
    phone: `+93 795 666 304`,
    website: `pwsongo.org`,
    tagline: `Afghan-led. Community-focused. Since 2017.`,
    profileUrl: `/docs/PWSO-Organization-Profile-2026.pdf`,
  },
  Zn = {
    name: ``,
    role: `Director, Poor Women Support Organization`,
    photo: ``,
    message: [
      `PWSO was founded in 2017 to support Afghan women and vulnerable communities through practical programs shaped by the people they serve.`,
      `From our offices in Kabul and Badakhshan, we work alongside women and families in health, education, economic empowerment, research and agriculture, so that communities can become resilient and self-reliant.`,
      `Thank you to the communities, partners and supporters who make this work possible. We invite you to learn about our work and to work with us.`,
    ],
  },
  Qn = [
    {
      city: `Kabul`,
      role: `Main office`,
      dari: `کابل`,
      img: `./assets/img/kabul.jpg`,
      text: `Kabul Province, Afghanistan`,
    },
    {
      city: `Badakhshan`,
      role: `Sub-office`,
      dari: `بدخشان`,
      img: `./assets/img/badakhshan.jpg`,
      text: `Badakhshan Province, northeastern Afghanistan`,
    },
  ],
  $n = [
    {
      id: `health`,
      color: `var(--prog-health)`,
      tagline: `Healthier women, families and communities`,
      icon: `heart`,
      title: `Health`,
      short: `Access to essential health services and community health awareness.`,
      text: `We support access to essential healthcare and run community health awareness so that women and their families can make informed decisions about their wellbeing.`,
      points: [
        `Community health awareness`,
        `Health education sessions`,
        `Support for access to essential health services`,
      ],
      img: `./assets/img/prog-health.jpg`,
    },
    {
      id: `economic`,
      color: `var(--prog-economic)`,
      tagline: `Skills, enterprise and sustainable livelihoods`,
      icon: `chart`,
      title: `Economic Empowerment`,
      short: `Vocational skills, entrepreneurship and sustainable livelihoods.`,
      text: `We help women build vocational and business skills, start small enterprises and reach markets, creating income that strengthens whole households.`,
      points: [
        `Vocational and life skills development`,
        `Entrepreneurship and small business skills`,
        `Livelihood opportunities and market linkages`,
      ],
      img: `./assets/img/prog-econ.jpg`,
    },
    {
      id: `education`,
      color: `var(--prog-education)`,
      tagline: `Literacy and learning for brighter futures`,
      icon: `book`,
      title: `Education`,
      short: `Literacy, learning and community education.`,
      text: `We support literacy, life skills and community education so that women and girls can learn, participate and build brighter futures.`,
      points: [
        `Literacy and basic education support`,
        `Life skills and community education`,
        `Learning opportunities for stronger communities`,
      ],
      img: `./assets/img/prog-edu.jpg`,
    },
    {
      id: `research`,
      color: `var(--prog-research)`,
      tagline: `Evidence, accountability and learning`,
      icon: `fileSearch`,
      title: `Research & MEAL`,
      short: `Monitoring, evaluation, accountability and learning.`,
      text: `We use monitoring, evaluation, accountability and learning to understand what works, listen to communities and make every program more effective.`,
      points: [
        `Monitoring and evaluation support`,
        `Learning and evidence generation`,
        `Accountability and knowledge sharing`,
      ],
      img: `./assets/img/prog-research.jpg`,
    },
    {
      id: `agriculture`,
      color: `var(--prog-agriculture)`,
      tagline: `Climate-resilient farming and rural livelihoods`,
      icon: `sprout`,
      title: `Agriculture & Climate`,
      short: `Sustainable farming and climate-resilient livelihoods.`,
      text: `We promote sustainable farming practices and climate adaptation so rural communities can protect their livelihoods against a changing environment.`,
      points: [
        `Sustainable agricultural practices`,
        `Climate change awareness and adaptation`,
        `Resilient livelihoods for rural communities`,
      ],
      img: `./assets/img/prog-agri.jpg`,
    },
  ],
  er = [
    {
      label: `About`,
      intro: `An Afghan-led non-profit supporting women and vulnerable communities since 2017.`,
      children: [
        {
          to: `/about`,
          label: `Who we are`,
          text: `Our story, mission and values`,
        },
        {
          to: `/about/leadership`,
          label: `Leadership`,
          text: `Our leadership structure and governance`,
        },
        {
          to: `/about#governance`,
          label: `Governance`,
          text: `How we are organized`,
        },
        {
          to: `/about#presence`,
          label: `Where we work`,
          text: `Kabul and Badakhshan`,
        },
        {
          to: `/priorities`,
          label: `Our priorities`,
          text: `What guides where we focus`,
        },
      ],
    },
    {
      label: `Our Work`,
      intro: `Five program areas that turn our priorities into practical, community-based action.`,
      children: [
        {
          to: `/programs`,
          label: `Programs`,
          text: `Health, education, livelihoods and more`,
        },
        {
          to: `/projects`,
          label: `Projects`,
          text: `Documented initiatives`,
        },
        {
          to: `/news`,
          label: `News & stories`,
          text: `Updates from the field`,
        },
        {
          to: `/news#gallery`,
          label: `Photo gallery`,
          text: `Life, learning and local action`,
        },
      ],
    },
    {
      label: `Get Involved`,
      intro: `Partner with us, join our team or work with us as a supplier.`,
      children: [
        {
          to: `/partnerships`,
          label: `Partner with us`,
          text: `Ways to collaborate`,
        },
        {
          to: `/careers`,
          label: `Jobs`,
          text: `Current vacancies`,
        },
        {
          to: `/careers?tab=procurement`,
          label: `Procurement`,
          text: `Tender notices`,
        },
      ],
    },
    {
      label: `Resources`,
      intro: `Our organization profile, reports and policies, and how to share feedback.`,
      children: [
        {
          to: `/resources`,
          label: `Organization profile`,
          text: `Download our 2026 profile`,
        },
        {
          to: `/resources#library`,
          label: `Reports & policies`,
          text: `Key documents`,
        },
        {
          to: `/resources#feedback`,
          label: `Feedback & safeguarding`,
          text: `Raise a concern`,
        },
      ],
    },
  ],
  tr = {
    Organization: [
      {
        to: `/about`,
        label: `Who we are`,
      },
      {
        to: `/priorities`,
        label: `Our priorities`,
      },
      {
        to: `/about#governance`,
        label: `Governance`,
      },
      {
        to: `/resources`,
        label: `Organization profile`,
      },
    ],
    "Our work": [
      {
        to: `/programs`,
        label: `Programs`,
      },
      {
        to: `/projects`,
        label: `Projects`,
      },
      {
        to: `/news`,
        label: `News & stories`,
      },
      {
        to: `/news#gallery`,
        label: `Photo gallery`,
      },
    ],
    "Get involved": [
      {
        to: `/partnerships`,
        label: `Partner with us`,
      },
      {
        to: `/careers`,
        label: `Jobs`,
      },
      {
        to: `/careers?tab=procurement`,
        label: `Procurement`,
      },
      {
        to: `/contact?category=Feedback`,
        label: `Share feedback`,
      },
    ],
  },
  nr = [
    {
      id: `food-processing`,
      category: `Livelihoods`,
      title: `Food processing & marketing training`,
      location: `Badakhshan`,
      year: `2018`,
      reach: `100 women`,
      funder: `PWSO Core Fund`,
      duration: `7 days`,
      img: `./assets/img/projects-card-food.jpg`,
      summary: `Women in Badakhshan were trained in food processing and marketing, with a focus on preparing pickles to a saleable standard and taking them to local markets.`,
      focus: `Pickle preparation and marketing`,
      investment: `$1,500`,
    },
    {
      id: `harmful-practices`,
      category: `Community Awareness`,
      title: `Awareness of harmful traditional practices`,
      location: `Badakhshan`,
      year: `2019`,
      reach: `150 men and women`,
      funder: `AKF`,
      duration: `One month`,
      img: `./assets/img/projects-card-awareness.jpg`,
    },
    {
      id: `capacity`,
      category: `Capacity Strengthening`,
      title: `Organizational capacity strengthening`,
      location: `Kabul`,
      scope: `Policy, systems and strategy development`,
      funder: `medica mondiale`,
      img: `./assets/img/projects-card-capacity.jpg`,
    },
  ],
  rr = [
    {
      name: `medica mondiale`,
      text: `Organizational capacity strengthening`,
    },
    {
      name: `AKF`,
      text: `Community awareness, Badakhshan`,
    },
    {
      name: `PWSO Core Fund`,
      text: `Livelihood skills training`,
    },
  ],
  ir = [
    {
      img: `./assets/img/news-story-skills.jpg`,
      topic: `Livelihoods`,
      title: `Practical skills that open doors`,
      text: `How vocational training helps women turn their skills into income for their families.`,
    },
    {
      img: `./assets/img/news-story-learning.jpg`,
      topic: `Education`,
      title: `Safe spaces to learn and grow`,
      text: `Community learning circles give women room to read, share and build confidence together.`,
    },
    {
      img: `./assets/img/news-story-rural.jpg`,
      topic: `Agriculture`,
      title: `Farming for a changing climate`,
      text: `Working with rural households on practices that protect harvests and livelihoods.`,
    },
  ],
  ar = [
    {
      key: `2017`,
      label: `Founded`,
      year: `2017`,
      kicker: `Building the foundation`,
      title: `An Afghan organization, founded for women.`,
      text: [
        `PWSO was established in 2017 as an Afghan non-profit organization and registered with the Ministry of Economy under registration number 4203.`,
        `From the start, our focus has been on women and vulnerable communities: supporting them through education, health and sustainable livelihoods.`,
      ],
      img: `./assets/img/about-who.jpg`,
      place: `Afghanistan`,
      stats: [
        {
          value: `4203`,
          label: `Registration number, Ministry of Economy`,
        },
        {
          value: `Afghan-led`,
          label: `Founded and run locally`,
        },
      ],
    },
    {
      key: `2018`,
      label: `First projects`,
      year: `2018`,
      kicker: `Skills for livelihoods`,
      title: `Practical skills in Badakhshan.`,
      text: [
        `In 2018, PWSO trained 100 women in Badakhshan in food processing and marketing, with a focus on preparing pickles and taking them to market.`,
        `The seven-day training was supported by the PWSO Core Fund with an investment of $1,500.`,
      ],
      img: `./assets/img/projects-featured.jpg`,
      place: `Badakhshan`,
      stats: [
        {
          value: `100`,
          label: `Women trained`,
        },
        {
          value: `7 days`,
          label: `Of hands-on training`,
        },
        {
          value: `$1,500`,
          label: `Invested by the PWSO Core Fund`,
        },
      ],
    },
    {
      key: `2019`,
      label: `Community awareness`,
      year: `2019`,
      kicker: `Working with communities`,
      title: `Talking openly about harmful practices.`,
      text: [
        `In 2019, with support from AKF, PWSO ran a month-long awareness project on harmful traditional practices in Badakhshan.`,
        `The project reached 150 men and women, working with whole communities rather than women alone.`,
      ],
      img: `./assets/img/projects-card-awareness.jpg`,
      place: `Badakhshan`,
      stats: [
        {
          value: `150`,
          label: `Men and women reached`,
        },
        {
          value: `1 month`,
          label: `Awareness project`,
        },
        {
          value: `AKF`,
          label: `Supporting partner`,
        },
      ],
    },
    {
      key: `today`,
      label: `Growing stronger`,
      year: `Today`,
      kicker: `Stronger systems, wider reach`,
      title: `An organization built to last.`,
      text: [
        `With support from medica mondiale, PWSO has strengthened its organizational capacity through policy, systems and strategy development.`,
        `Today we work across five program areas from our main office in Kabul and our sub-office in Badakhshan.`,
      ],
      img: `./assets/img/projects-card-capacity.jpg`,
      place: `Kabul & Badakhshan`,
      stats: [
        {
          value: `5`,
          label: `Program areas`,
        },
        {
          value: `2`,
          label: `Offices, in Kabul and Badakhshan`,
        },
      ],
    },
  ],
  or = [
    {
      kind: `Page`,
      icon: `users`,
      title: `Who we are`,
      text: `Mission, vision, values, governance and offices`,
      to: `/about`,
    },
    {
      kind: `Page`,
      icon: `target`,
      title: `Our priorities`,
      text: `Women's empowerment, learning, livelihoods and accountability`,
      to: `/priorities`,
    },
    {
      kind: `Page`,
      icon: `layers`,
      title: `Programs`,
      text: `Health, economic empowerment, education, research and agriculture`,
      to: `/programs`,
    },
    {
      kind: `Page`,
      icon: `briefcase`,
      title: `Projects`,
      text: `Documented initiatives from our organization profile`,
      to: `/projects`,
    },
    {
      kind: `Page`,
      icon: `file`,
      title: `Resources`,
      text: `Organization profile, reports and policies`,
      to: `/resources`,
    },
    {
      kind: `Page`,
      icon: `message`,
      title: `News & stories`,
      text: `Stories from the field and photo gallery`,
      to: `/news`,
    },
    {
      kind: `Page`,
      icon: `briefcase`,
      title: `Jobs & procurement`,
      text: `Vacancies, tender notices and how to apply`,
      to: `/careers`,
    },
    {
      kind: `Page`,
      icon: `handshake`,
      title: `Partnerships`,
      text: `Ways to collaborate with PWSO`,
      to: `/partnerships`,
    },
    {
      kind: `Page`,
      icon: `mail`,
      title: `Contact`,
      text: `Email, phone, offices and frequently asked questions`,
      to: `/contact`,
    },
    {
      kind: `Document`,
      icon: `download`,
      title: `Organization Profile 2026`,
      text: `Download our official profile (PDF)`,
      to: `/resources`,
    },
    {
      kind: `Document`,
      icon: `file`,
      title: `Reports & policies`,
      text: `Annual, financial and audit reports; policies and procedures`,
      to: `/resources#library`,
    },
    {
      kind: `Page`,
      icon: `shield`,
      title: `Feedback & safeguarding`,
      text: `Share feedback or raise a concern`,
      to: `/contact?category=Feedback`,
    },
    ...$n.map((e) => ({
      kind: `Program`,
      icon: e.icon,
      title: e.title,
      text: e.short,
      to: `/programs#${e.id}`,
    })),
    ...nr.map((e) => ({
      kind: `Project`,
      icon: `pin`,
      title: e.title,
      text: [e.location, e.year, e.funder].filter(Boolean).join(` · `),
      to: `/projects`,
    })),
    ...ir.map((e) => ({
      kind: `Story`,
      icon: `message`,
      title: e.title,
      text: e.text,
      to: `/news`,
    })),
    ...Qn.map((e) => ({
      kind: `Office`,
      icon: `pin`,
      title: `${e.city} ${e.role.toLowerCase()}`,
      text: e.text,
      to: `/contact`,
    })),
  ],
  sr = or.filter((e) =>
    [
      `Programs`,
      `Projects`,
      `Organization Profile 2026`,
      `Jobs & procurement`,
      `Contact`,
    ].includes(e.title),
  );
function cr({ onClose: e }) {
  let [t, n] = (0, x.useState)(``),
    r = (0, x.useRef)(null);
  (0, x.useEffect)(() => {
    r.current?.focus();
    let t = (t) => {
      t.key === `Escape` && e();
    };
    return (
      window.addEventListener(`keydown`, t),
      document.body.classList.add(`no-scroll`),
      () => {
        (window.removeEventListener(`keydown`, t),
          document.body.classList.remove(`no-scroll`));
      }
    );
  }, [e]);
  let i = (0, x.useMemo)(() => {
    let e = t.trim().toLowerCase().split(/\s+/).filter(Boolean);
    return e.length
      ? or.filter((t) => {
          let n = `${t.title} ${t.text} ${t.kind}`.toLowerCase();
          return e.every((e) => n.includes(e));
        })
      : sr;
  }, [t]);
  return (0, M.jsx)(`div`, {
    className: `search-overlay`,
    onClick: e,
    role: `dialog`,
    "aria-modal": `true`,
    "aria-label": `Search the site`,
    children: (0, M.jsxs)(`div`, {
      className: `search-panel`,
      onClick: (e) => e.stopPropagation(),
      children: [
        (0, M.jsxs)(`div`, {
          className: `search-input-row`,
          children: [
            (0, M.jsx)(N, {
              name: `search`,
              size: 20,
              strokeWidth: 2,
            }),
            (0, M.jsx)(`input`, {
              ref: r,
              type: `search`,
              placeholder: `Search programs, projects, documents…`,
              value: t,
              onChange: (e) => n(e.target.value),
              "aria-label": `Search`,
            }),
            (0, M.jsx)(`button`, {
              className: `icon-btn`,
              onClick: e,
              "aria-label": `Close search`,
              children: (0, M.jsx)(N, {
                name: `close`,
                size: 20,
                strokeWidth: 2,
              }),
            }),
          ],
        }),
        (0, M.jsx)(`div`, {
          className: `search-results`,
          children: i.length
            ? i.map((t) =>
                (0, M.jsxs)(
                  j,
                  {
                    to: t.to,
                    className: `search-result`,
                    onClick: e,
                    children: [
                      (0, M.jsx)(`span`, {
                        className: `icon-tile icon-tile-sm icon-tile-brand`,
                        children: (0, M.jsx)(N, {
                          name: t.icon,
                          size: 18,
                          strokeWidth: 1.9,
                        }),
                      }),
                      (0, M.jsxs)(`div`, {
                        children: [
                          (0, M.jsx)(`strong`, {
                            children: t.title,
                          }),
                          (0, M.jsx)(`span`, {
                            children: t.text,
                          }),
                        ],
                      }),
                      (0, M.jsx)(`span`, {
                        className: `search-kind`,
                        children: t.kind,
                      }),
                    ],
                  },
                  t.kind + t.title,
                ),
              )
            : (0, M.jsxs)(`p`, {
                className: `search-empty`,
                children: [
                  `No results for “`,
                  t,
                  `”. Try another word, or `,
                  (0, M.jsx)(j, {
                    to: `/contact`,
                    onClick: e,
                    style: {
                      color: `var(--brand)`,
                      fontWeight: 700,
                    },
                    children: `contact us`,
                  }),
                  `.`,
                ],
              }),
        }),
        (0, M.jsxs)(`p`, {
          className: `search-hint`,
          children: [
            t ? `${i.length} result${i.length === 1 ? `` : `s`}` : `Suggested`,
            ` · Press Esc to close`,
          ],
        }),
      ],
    }),
  });
}
function lr(e, t) {
  let n = Object.entries(t).map(([e, t]) => `${e}: ${t}`).join(`
    `);
  window.location.href = `mailto:${P.email}?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(n)}`;
}
var ur = [
    `main .section-head`,
    `main .grid > *`,
    `main .split > *`,
    `main .stats > *`,
    `main .rv`,
  ].join(`,`),
  dr = () =>
    navigator.webdriver ||
    window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;
function fr(e = 8) {
  let [t, n] = (0, x.useState)(!1);
  return (
    (0, x.useEffect)(() => {
      let t = () => n(window.scrollY > e);
      return (
        t(),
        window.addEventListener(`scroll`, t, {
          passive: !0,
        }),
        () => window.removeEventListener(`scroll`, t)
      );
    }, [e]),
    t
  );
}
function pr(e) {
  (0, x.useEffect)(() => {
    if (dr() || !(`IntersectionObserver` in window)) return;
    let e = new IntersectionObserver(
        (t) => {
          for (let n of t)
            n.isIntersecting &&
              (n.target.classList.add(`is-visible`), e.unobserve(n.target));
        },
        {
          rootMargin: `0px 0px -6% 0px`,
          threshold: 0.06,
        },
      ),
      t = requestAnimationFrame(() => {
        document.querySelectorAll(ur).forEach((t) => {
          if (t.classList.contains(`reveal`)) return;
          let n = [...t.parentElement.children].indexOf(t);
          ((t.style.transitionDelay = `${(n % 4) * 80}ms`),
            t.classList.add(`reveal`),
            e.observe(t));
        });
      });
    return () => {
      (cancelAnimationFrame(t), e.disconnect());
    };
  }, [e]);
}
var mr = new Date().getFullYear(),
  hr = `tel:${P.phone.replace(/\s/g, ``)}`,
  gr = (e) => e.split(/[?#]/)[0],
  _r = `/news`;
function vr(e, t, n) {
  (0, x.useEffect)(() => {
    if (!t) return;
    let r = (t) => {
        e.current?.contains(t.target) || n();
      },
      i = (e) => {
        e.key === `Escape` && n();
      };
    return (
      document.addEventListener(`pointerdown`, r),
      document.addEventListener(`keydown`, i),
      () => {
        (document.removeEventListener(`pointerdown`, r),
          document.removeEventListener(`keydown`, i));
      }
    );
  }, [e, t, n]);
}
function yr() {
  let [e, t] = (0, x.useState)(!1),
    n = (0, x.useRef)(null);
  return (
    vr(
      n,
      e,
      (0, x.useCallback)(() => t(!1), []),
    ),
    (0, M.jsxs)(`div`, {
      className: `lang`,
      ref: n,
      children: [
        (0, M.jsxs)(`button`, {
          className: `lang-btn`,
          "aria-haspopup": `menu`,
          "aria-expanded": e,
          "aria-label": `Language: English`,
          onClick: () => t(!e),
          children: [
            `EN `,
            (0, M.jsx)(N, {
              name: `chevronDown`,
              size: 14,
              strokeWidth: 2,
            }),
          ],
        }),
        e &&
          (0, M.jsxs)(`div`, {
            className: `lang-menu`,
            role: `menu`,
            children: [
              (0, M.jsx)(`button`, {
                role: `menuitemradio`,
                "aria-checked": `true`,
                onClick: () => t(!1),
                children: `English`,
              }),
              (0, M.jsxs)(`button`, {
                role: `menuitemradio`,
                "aria-checked": `false`,
                disabled: !0,
                children: [
                  (0, M.jsx)(`span`, {
                    lang: `fa`,
                    children: `دری`,
                  }),
                  (0, M.jsx)(`small`, {
                    children: `Coming soon`,
                  }),
                ],
              }),
              (0, M.jsxs)(`button`, {
                role: `menuitemradio`,
                "aria-checked": `false`,
                disabled: !0,
                children: [
                  (0, M.jsx)(`span`, {
                    lang: `ps`,
                    children: `پښتو`,
                  }),
                  (0, M.jsx)(`small`, {
                    children: `Coming soon`,
                  }),
                ],
              }),
            ],
          }),
      ],
    })
  );
}
function br() {
  return (0, M.jsxs)(j, {
    to: `/`,
    className: `brand`,
    "aria-label": `${P.name} — home`,
    children: [
      (0, M.jsx)(`span`, {
        className: `brand-mark`,
        children: (0, M.jsx)(`img`, {
          src: `./assets/img/logo.png`,
          alt: ``,
          width: `112`,
          height: `54`,
        }),
      }),
      (0, M.jsxs)(`span`, {
        className: `brand-name`,
        children: [
          `Poor Women`,
          (0, M.jsx)(`br`, {}),
          `Support Organization`,
          (0, M.jsxs)(`small`, {
            children: [`Afghan-led · Since `, P.established],
          }),
        ],
      }),
    ],
  });
}
function xr({ onSearch: e }) {
  let [t, n] = (0, x.useState)(!1),
    [r, i] = (0, x.useState)(null),
    a = fr(4),
    { pathname: o, search: s, hash: c } = yt(),
    l = (0, x.useRef)(null),
    u = o + s + c,
    [d, f] = (0, x.useState)(u);
  return (
    d !== u && (f(u), n(!1), i(null)),
    (0, x.useEffect)(() => {
      l.current?.contains(document.activeElement) &&
        document.activeElement.blur();
    }, [u]),
    (0, x.useEffect)(() => {
      document.body.classList.toggle(`no-scroll`, t);
    }, [t]),
    vr(
      l,
      r !== null && !t,
      (0, x.useCallback)(() => i(null), []),
    ),
    (0, M.jsxs)(`header`, {
      ref: l,
      className: `header ${a ? `is-scrolled` : ``}`,
      children: [
        (0, M.jsx)(`div`, {
          className: `spectrum`,
          "aria-hidden": `true`,
        }),
        (0, M.jsxs)(`div`, {
          className: `container header-inner`,
          children: [
            (0, M.jsx)(br, {}),
            (0, M.jsxs)(`nav`, {
              id: `main-nav`,
              className: `nav ${t ? `is-open` : ``}`,
              "aria-label": `Main`,
              children: [
                (0, M.jsxs)(`ul`, {
                  className: `nav-list`,
                  children: [
                    er.map((e) =>
                      (0, M.jsxs)(
                        `li`,
                        {
                          className: `nav-item has-menu ${r === e.label ? `is-open` : ``}`,
                          children: [
                            (0, M.jsxs)(`button`, {
                              className: `nav-link ${o !== _r && e.children.some((e) => gr(e.to) === o) ? `active` : ``}`,
                              "aria-expanded": r === e.label,
                              onClick: () =>
                                i((t) => (t === e.label ? null : e.label)),
                              children: [
                                e.label,
                                ` `,
                                (0, M.jsx)(N, {
                                  name: `chevronDown`,
                                  size: 16,
                                  strokeWidth: 2,
                                }),
                              ],
                            }),
                            (0, M.jsx)(`div`, {
                              className: `menu`,
                              children: (0, M.jsxs)(`div`, {
                                className: `container menu-inner`,
                                children: [
                                  (0, M.jsxs)(`div`, {
                                    className: `menu-intro`,
                                    children: [
                                      (0, M.jsx)(`strong`, {
                                        children: e.label,
                                      }),
                                      e.intro,
                                    ],
                                  }),
                                  (0, M.jsx)(`div`, {
                                    className: `menu-links`,
                                    children: e.children.map((e) =>
                                      (0, M.jsxs)(
                                        j,
                                        {
                                          to: e.to,
                                          className: `menu-link ${e.to === u ? `is-current` : ``}`,
                                          children: [
                                            (0, M.jsx)(`strong`, {
                                              children: e.label,
                                            }),
                                            (0, M.jsx)(`span`, {
                                              children: e.text,
                                            }),
                                          ],
                                        },
                                        e.to,
                                      ),
                                    ),
                                  }),
                                ],
                              }),
                            }),
                          ],
                        },
                        e.label,
                      ),
                    ),
                    (0, M.jsx)(`li`, {
                      className: `nav-item`,
                      children: (0, M.jsx)(j, {
                        to: _r,
                        className: `nav-link ${o === _r ? `active` : ``}`,
                        children: `News`,
                      }),
                    }),
                  ],
                }),
                (0, M.jsxs)(`div`, {
                  className: `nav-mobile-extra`,
                  children: [
                    (0, M.jsx)(j, {
                      to: `/contact`,
                      className: `btn btn-primary`,
                      children: `Contact us`,
                    }),
                    (0, M.jsxs)(`a`, {
                      href: `mailto:${P.email}`,
                      children: [
                        (0, M.jsx)(N, {
                          name: `mail`,
                          size: 18,
                        }),
                        P.email,
                      ],
                    }),
                    (0, M.jsxs)(`a`, {
                      href: hr,
                      children: [
                        (0, M.jsx)(N, {
                          name: `phone`,
                          size: 18,
                        }),
                        P.phone,
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, M.jsxs)(`div`, {
              className: `header-tools`,
              children: [
                (0, M.jsx)(`button`, {
                  className: `icon-btn`,
                  onClick: e,
                  "aria-label": `Search the site`,
                  children: (0, M.jsx)(N, {
                    name: `search`,
                    size: 21,
                    strokeWidth: 2,
                  }),
                }),
                (0, M.jsx)(yr, {}),
                (0, M.jsx)(Ln, {
                  to: `/contact`,
                  className: `btn btn-primary header-cta`,
                  children: `Contact us`,
                }),
                (0, M.jsx)(`button`, {
                  className: `icon-btn nav-toggle`,
                  onClick: () => n(!t),
                  "aria-label": t ? `Close menu` : `Open menu`,
                  "aria-expanded": t,
                  "aria-controls": `main-nav`,
                  children: (0, M.jsx)(N, {
                    name: t ? `close` : `menu`,
                    size: 24,
                  }),
                }),
              ],
            }),
          ],
        }),
      ],
    })
  );
}
function Sr() {
  let [e, t] = (0, x.useState)(``),
    [n, r] = (0, x.useState)(!1);
  return (0, M.jsxs)(`div`, {
    className: `subscribe-wrap`,
    children: [
      (0, M.jsxs)(`form`, {
        className: `subscribe`,
        onSubmit: (t) => {
          (t.preventDefault(),
            lr(`Please add me to PWSO updates`, {
              Email: e,
              Request: `Please send me news and updates about PWSO programs and opportunities.`,
            }),
            r(!0));
        },
        children: [
          (0, M.jsx)(`input`, {
            type: `email`,
            required: !0,
            placeholder: `Your email address`,
            "aria-label": `Your email address`,
            value: e,
            onChange: (e) => t(e.target.value),
          }),
          (0, M.jsx)(`button`, {
            className: `btn btn-light`,
            children: `Subscribe`,
          }),
        ],
      }),
      (0, M.jsx)(`p`, {
        className: `footer-note`,
        role: `status`,
        children: n
          ? `Thank you. Your email app should open to send the request.`
          : `Opens your email app to send the request.`,
      }),
    ],
  });
}
function Cr() {
  return (0, M.jsxs)(`footer`, {
    className: `footer`,
    children: [
      (0, M.jsx)(`span`, {
        className: `wheel wheel-spin footer-wheel`,
        "aria-hidden": `true`,
      }),
      (0, M.jsxs)(`div`, {
        className: `container footer-top`,
        children: [
          (0, M.jsxs)(`div`, {
            className: `footer-about`,
            children: [
              (0, M.jsx)(j, {
                to: `/`,
                className: `brand brand-light`,
                "aria-label": `${P.name} — home`,
                children: (0, M.jsx)(`span`, {
                  className: `brand-mark`,
                  children: (0, M.jsx)(`img`, {
                    src: `./assets/img/logo.png`,
                    alt: ``,
                    width: `112`,
                    height: `54`,
                  }),
                }),
              }),
              (0, M.jsxs)(`p`, {
                children: [
                  `An Afghan-led non-profit supporting women and vulnerable communities since `,
                  P.established,
                  `.`,
                ],
              }),
              (0, M.jsxs)(`div`, {
                className: `footer-sub`,
                children: [
                  (0, M.jsxs)(`h2`, {
                    className: `footer-sub-title`,
                    children: [
                      `Stay close to `,
                      (0, M.jsx)(`em`, {
                        children: `our work.`,
                      }),
                    ],
                  }),
                  (0, M.jsx)(Sr, {}),
                ],
              }),
            ],
          }),
          Object.entries(tr).map(([e, t]) =>
            (0, M.jsxs)(
              `div`,
              {
                children: [
                  (0, M.jsx)(`h2`, {
                    className: `footer-title`,
                    children: e,
                  }),
                  (0, M.jsx)(`ul`, {
                    className: `footer-links`,
                    children: t.map((e) =>
                      (0, M.jsx)(
                        `li`,
                        {
                          children: (0, M.jsx)(j, {
                            to: e.to,
                            children: e.label,
                          }),
                        },
                        e.label,
                      ),
                    ),
                  }),
                ],
              },
              e,
            ),
          ),
          (0, M.jsxs)(`div`, {
            children: [
              (0, M.jsx)(`h2`, {
                className: `footer-title`,
                children: `Contact`,
              }),
              (0, M.jsxs)(`ul`, {
                className: `footer-contact`,
                children: [
                  (0, M.jsxs)(`li`, {
                    children: [
                      (0, M.jsx)(N, {
                        name: `pin`,
                        size: 18,
                      }),
                      (0, M.jsxs)(`span`, {
                        children: [
                          Qn.map((e) => e.city).join(` · `),
                          `, Afghanistan`,
                        ],
                      }),
                    ],
                  }),
                  (0, M.jsxs)(`li`, {
                    children: [
                      (0, M.jsx)(N, {
                        name: `phone`,
                        size: 18,
                      }),
                      (0, M.jsx)(`a`, {
                        href: hr,
                        children: P.phone,
                      }),
                    ],
                  }),
                  (0, M.jsxs)(`li`, {
                    children: [
                      (0, M.jsx)(N, {
                        name: `mail`,
                        size: 18,
                      }),
                      (0, M.jsx)(`a`, {
                        href: `mailto:${P.email}`,
                        children: P.email,
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `container footer-bottom`,
        children: [
          (0, M.jsxs)(`p`, {
            children: [
              `© `,
              mr,
              ` `,
              P.name,
              `. Registered with the `,
              P.registrar,
              `, No. `,
              P.registration,
              `.`,
            ],
          }),
          (0, M.jsx)(`p`, {
            children: `Photography shown is illustrative.`,
          }),
        ],
      }),
      (0, M.jsx)(`div`, {
        className: `spectrum`,
        "aria-hidden": `true`,
      }),
    ],
  });
}
function wr() {
  let e = fr(900);
  return (0, M.jsx)(`button`, {
    className: `to-top ${e ? `is-visible` : ``}`,
    onClick: () =>
      window.scrollTo({
        top: 0,
        behavior: `smooth`,
      }),
    "aria-label": `Back to top`,
    tabIndex: e ? 0 : -1,
    children: (0, M.jsx)(N, {
      name: `arrowUp`,
      size: 20,
      strokeWidth: 2,
    }),
  });
}
function Tr() {
  let { pathname: e, hash: t } = yt(),
    [n, r] = (0, x.useState)(!1),
    i = (0, x.useCallback)(() => r(!1), []);
  return (
    (0, x.useEffect)(() => {
      let e = t && document.getElementById(t.slice(1));
      e
        ? e.scrollIntoView({
            behavior: `smooth`,
          })
        : window.scrollTo(0, 0);
    }, [e, t]),
    pr(e),
    (0, M.jsxs)(M.Fragment, {
      children: [
        (0, M.jsx)(`a`, {
          href: `#main`,
          className: `skip-link`,
          children: `Skip to content`,
        }),
        (0, M.jsx)(xr, {
          onSearch: () => r(!0),
        }),
        (0, M.jsx)(`main`, {
          id: `main`,
          children: (0, M.jsx)(qt, {}),
        }),
        (0, M.jsx)(Cr, {}),
        (0, M.jsx)(wr, {}),
        n &&
          (0, M.jsx)(cr, {
            onClose: i,
          }),
      ],
    })
  );
}
var Er = {
    width: 600,
    height: 471,
  },
  Dr = [
    {
      name: `Kandahar`,
      d: `M174,427L174,442L178,441L191,441L196,442L216,436L221,436L244,428L247,426L247,421L245,421L244,418L244,412L247,408L246,389L250,376L254,374L261,365L271,359L278,363L282,364L288,364L303,358L303,355L298,354L295,350L292,348L285,348L283,338L279,340L271,339L266,334L262,333L260,333L246,341L241,338L241,333L247,327L248,322L247,316L249,314L249,311L242,305L238,305L236,303L222,304L221,302L219,302L212,309L203,313L200,318L197,327L193,332L189,334L186,345L184,368L181,376L178,403L174,427Z`,
      c: [239, 360],
    },
    {
      name: `Zabul`,
      d: `M295,350L303,348L306,345L314,341L315,339L311,335L312,331L315,328L315,325L312,324L308,324L305,320L299,320L295,323L292,323L290,323L286,320L286,316L288,315L293,304L298,300L298,298L293,297L291,296L291,295L288,294L290,290L289,289L288,278L275,276L272,275L272,272L270,272L268,273L267,282L260,290L258,291L258,293L256,292L255,290L254,291L246,298L243,306L249,311L249,314L247,316L248,322L247,327L241,333L241,338L246,341L260,333L262,333L266,334L271,339L279,340L283,338L285,348L292,348L295,350Z`,
      c: [281, 314],
    },
    {
      name: `Uruzgan`,
      d: `M243,306L246,298L250,294L255,290L256,292L258,293L258,291L260,290L263,287L267,282L268,273L275,268L275,267L272,264L255,269L252,266L248,265L241,268L241,272L239,274L234,274L234,272L234,270L229,270L222,276L216,272L213,272L212,274L206,274L202,281L201,286L204,297L206,299L203,313L212,309L219,302L221,302L222,304L236,303L238,305L241,305L243,306Z`,
      c: [237, 284],
    },
    {
      name: `Daykundi`,
      d: `M262,267L262,263L267,258L269,258L269,251L271,249L282,245L288,240L287,236L284,236L279,229L268,233L258,233L256,228L255,212L238,213L231,216L213,217L213,221L211,222L213,229L214,234L213,234L212,236L209,236L209,239L212,244L212,254L204,261L204,263L207,268L207,269L206,270L206,274L212,274L213,272L216,272L222,276L229,270L231,270L234,270L234,274L236,275L239,274L241,272L241,268L245,266L249,265L255,269L262,267Z`,
      c: [239, 247],
    },
    {
      name: `Ghanzi`,
      d: `M313,324L313,305L312,300L308,300L307,298L306,292L310,290L314,292L318,291L322,287L327,282L327,280L329,279L330,274L336,268L336,263L340,259L341,248L337,245L335,245L333,247L329,246L328,243L331,236L329,234L323,234L323,236L322,238L318,236L315,233L316,227L314,224L302,225L295,220L281,228L279,229L283,234L284,236L287,236L288,240L282,245L271,249L269,251L269,258L267,258L262,263L262,267L272,264L273,264L275,268L271,270L271,272L272,272L272,275L288,279L289,289L290,290L288,294L291,295L291,296L293,297L298,298L298,300L293,304L288,315L286,316L286,320L290,323L292,323L295,323L299,320L305,320L308,324L313,324Z`,
      c: [302, 268],
    },
    {
      name: `Paktika`,
      d: `M315,339L318,336L325,338L331,337L338,338L340,340L342,346L344,346L350,345L351,343L355,342L357,340L359,336L361,335L361,332L364,330L364,328L362,312L360,305L363,300L366,297L367,295L366,293L366,290L369,287L370,284L370,278L365,277L363,274L366,269L368,267L368,265L366,265L359,266L351,270L348,271L347,259L338,260L336,263L336,268L330,274L329,279L327,280L327,282L321,289L316,292L314,292L310,290L306,292L307,298L308,300L312,300L313,305L313,324L315,325L315,328L312,331L311,335L315,339Z`,
      c: [341, 301],
    },
    {
      name: `Khost`,
      d: `M370,278L376,275L385,275L390,271L394,270L400,266L401,260L398,256L397,251L392,246L387,245L385,249L382,250L377,249L373,251L370,263L368,265L365,271L363,273L365,277L370,278Z`,
      c: [381, 263],
    },
    {
      name: `Paktia`,
      d: `M340,259L347,259L347,269L348,271L350,271L359,266L368,264L372,257L373,251L377,249L382,250L385,249L387,245L389,245L390,245L390,243L386,237L384,236L384,233L378,232L367,232L365,234L362,239L356,241L354,243L350,250L341,250L340,259Z`,
      c: [367, 250],
    },
    {
      name: `Logar`,
      d: `M341,250L350,250L354,243L356,241L362,239L365,234L367,232L378,232L384,233L385,227L381,220L379,219L374,221L366,220L360,216L356,218L354,218L352,216L348,215L341,222L341,227L343,228L344,232L339,238L337,245L341,250Z`,
      c: [359, 230],
    },
    {
      name: `Wardak`,
      d: `M337,245L339,238L344,232L343,228L341,227L341,222L348,215L348,212L343,208L343,201L338,201L337,199L331,198L324,201L319,194L313,201L311,202L307,203L297,201L296,205L291,208L283,211L283,213L295,218L296,219L295,220L302,225L314,224L316,227L315,233L318,236L322,238L323,236L323,234L329,234L331,236L328,243L329,246L333,247L335,245L337,245Z`,
      c: [320, 219],
    },
    {
      name: `Kabul`,
      d: `M370,221L370,218L379,212L381,210L382,200L384,197L386,197L386,193L381,194L378,200L371,202L366,200L364,198L363,195L360,193L358,190L351,189L347,190L343,198L343,208L348,212L348,215L352,216L354,218L356,218L360,216L366,220L370,221Z`,
      c: [365, 205],
    },
    {
      name: `Nangarhar`,
      d: `M385,230L396,232L399,233L410,234L420,232L426,232L432,228L433,217L427,205L424,204L419,205L416,203L413,194L408,194L406,197L404,198L404,201L406,206L405,208L401,210L395,210L393,212L390,212L385,211L384,210L381,210L379,212L370,218L370,221L374,221L377,219L381,220L385,227L385,230Z`,
      c: [402, 215],
    },
    {
      name: `Laghman`,
      d: `M381,210L384,210L385,211L390,212L393,212L395,210L401,210L405,208L406,206L404,201L404,198L408,194L413,194L412,189L409,188L402,189L395,184L395,182L394,180L390,180L388,174L380,179L383,184L385,184L387,188L386,197L384,197L382,200L381,210Z`,
      c: [393, 193],
    },
    {
      name: `Kapisa`,
      d: `M386,193L387,188L385,184L383,184L380,181L379,172L362,171L361,176L360,178L360,181L365,183L369,185L374,196L377,200L381,194L386,193Z`,
      c: [374, 184],
    },
    {
      name: `Parwan`,
      d: `M343,201L345,193L347,190L351,189L358,190L360,193L363,195L364,198L369,202L377,200L374,196L369,185L359,180L362,172L362,171L357,170L360,164L354,165L351,169L351,171L348,172L341,171L333,179L329,181L317,181L317,184L320,190L320,194L319,194L324,201L331,198L337,199L338,201L343,201Z`,
      c: [348, 185],
    },
    {
      name: `Panjshir`,
      d: `M386,174L386,168L387,166L394,161L396,156L398,154L397,143L395,142L393,143L382,150L379,152L377,160L368,162L365,164L360,164L357,170L379,172L380,179L386,174Z`,
      c: [382, 162],
    },
    {
      name: `Kunar`,
      d: `M428,208L434,195L439,192L441,189L447,187L449,183L450,179L453,176L450,170L451,161L449,161L442,166L437,167L434,168L432,178L431,179L423,180L423,181L420,179L415,180L411,183L410,188L412,189L413,194L414,196L414,201L419,205L422,204L427,205L428,208Z`,
      c: [432, 185],
    },
    {
      name: `Nuristan`,
      d: `M410,188L411,183L415,180L420,179L423,181L423,180L431,179L432,178L434,168L442,166L451,160L446,155L443,144L434,136L431,138L430,142L427,144L426,148L426,152L420,153L420,162L419,162L414,159L412,159L410,162L408,162L408,157L406,154L403,152L398,153L394,160L394,161L389,164L386,168L386,174L388,175L390,180L394,180L395,184L402,189L410,188Z`,
      c: [415, 165],
    },
    {
      name: `Baghlan`,
      d: `M360,164L365,164L368,162L377,160L379,152L387,147L387,143L380,137L380,130L378,126L375,126L375,124L370,126L362,127L359,125L355,124L349,121L348,119L346,119L339,114L322,112L320,114L320,120L321,124L325,127L328,127L328,132L327,135L324,135L323,137L321,141L321,146L319,147L316,152L317,157L315,157L315,159L312,160L310,162L314,167L312,170L313,175L314,176L316,181L329,181L333,179L341,171L348,172L351,171L351,169L354,165L360,164Z`,
      c: [344, 148],
    },
    {
      name: `Bamyan`,
      d: `M279,229L292,223L296,219L283,213L283,211L294,207L296,205L297,201L307,203L313,201L316,197L320,194L320,190L317,184L317,181L316,181L314,176L313,175L312,170L314,167L310,162L304,161L301,163L295,162L290,162L289,163L288,164L282,163L275,166L266,165L263,166L259,174L252,177L252,184L249,186L249,188L255,194L255,198L258,201L261,201L262,203L260,204L261,208L258,212L255,212L256,228L258,233L268,233L274,232L276,230L279,229Z`,
      c: [282, 192],
    },
    {
      name: `Samangan`,
      d: `M322,112L316,111L312,112L307,111L302,112L300,113L299,123L297,126L290,123L287,122L284,124L284,128L282,130L278,130L276,132L273,132L272,135L272,136L275,137L275,139L277,139L276,143L274,144L274,148L276,151L276,156L269,161L268,165L275,166L282,163L288,164L290,162L301,163L307,161L310,162L312,160L315,159L315,157L317,157L316,152L319,147L321,146L321,141L323,137L324,135L327,135L328,132L328,127L325,127L321,124L320,120L320,114L322,112Z`,
      c: [297, 140],
    },
    {
      name: `Kunduz`,
      d: `M357,125L354,117L355,116L358,116L360,111L357,103L358,100L361,98L363,89L363,84L361,86L358,85L348,76L341,79L337,81L335,80L330,82L323,84L320,87L319,90L313,95L313,98L315,102L316,106L317,108L317,111L339,114L346,119L348,119L349,121L357,125Z`,
      c: [343, 101],
    },
    {
      name: `Takhar`,
      d: `M397,144L402,141L402,136L406,131L406,123L397,122L392,118L392,111L390,107L389,98L393,89L395,86L396,86L396,84L392,84L390,82L391,78L389,76L389,62L387,62L376,62L371,64L367,67L365,71L366,81L363,84L363,89L361,98L358,100L357,103L360,111L358,116L355,116L354,117L357,125L359,125L362,127L364,127L370,126L375,124L375,126L378,126L379,127L380,137L387,143L387,147L395,142L397,144Z`,
      c: [378, 110],
    },
    {
      name: `Balkh`,
      d: `M317,111L317,108L316,106L315,102L313,98L313,95L303,88L301,82L294,77L292,78L288,81L282,82L269,73L250,74L253,84L251,90L251,95L253,98L253,101L250,106L254,112L252,121L250,125L253,130L256,141L256,144L252,153L250,154L250,155L252,157L255,157L258,153L263,150L267,150L272,146L274,145L277,142L277,139L275,139L275,137L272,136L272,135L273,132L276,132L278,130L282,130L284,128L284,124L287,122L290,123L297,126L299,123L300,113L302,112L307,111L314,112L317,111Z`,
      c: [276, 118],
    },
    {
      name: `Sar-e Pol`,
      d: `M268,165L269,161L276,156L276,151L274,145L272,146L267,150L263,150L258,153L255,157L252,157L250,155L250,154L253,151L256,144L256,139L253,130L250,125L252,121L254,112L233,114L231,117L231,120L230,121L213,125L211,133L210,134L211,139L221,140L225,147L218,148L216,153L210,156L209,161L206,165L206,167L210,172L219,173L228,181L232,182L234,180L237,180L236,190L249,188L249,186L252,184L252,177L259,174L263,166L268,165Z`,
      c: [241, 152],
    },
    {
      name: `Jowzjan`,
      d: `M250,74L239,74L224,67L218,67L217,69L216,76L213,79L212,86L209,87L207,93L207,96L209,105L209,112L212,119L210,120L205,121L199,126L200,137L198,137L197,140L202,142L206,142L211,142L214,140L213,138L211,139L210,136L213,125L230,121L231,120L231,117L233,114L254,112L250,106L253,101L253,98L251,95L251,90L253,84L250,74Z`,
      c: [222, 109],
    },
    {
      name: `Faryab`,
      d: `M214,140L211,142L202,142L197,140L198,137L200,137L199,126L205,121L210,120L212,119L209,112L209,105L207,96L208,90L212,86L213,79L198,80L184,87L185,95L184,98L177,108L176,119L173,125L165,129L161,129L156,132L156,135L154,136L149,136L149,138L151,139L151,150L153,154L156,162L156,163L162,163L165,168L168,167L170,163L170,164L171,165L172,174L174,176L183,176L184,174L191,174L197,172L200,173L202,176L208,175L210,172L210,171L209,171L206,165L209,161L210,156L216,153L218,148L225,147L221,140L214,140Z`,
      c: [191, 140],
    },
    {
      name: `Badghis`,
      d: `M149,137L148,137L146,140L136,141L135,143L132,144L120,145L121,155L117,160L118,165L110,168L107,170L108,178L102,182L101,186L103,193L109,195L111,198L116,199L118,202L126,203L131,203L135,204L137,207L144,208L151,207L152,206L157,206L158,204L160,203L170,203L172,202L172,200L179,197L188,197L196,194L194,186L189,180L184,178L184,176L173,175L170,164L170,163L168,167L165,168L162,163L156,163L156,162L153,154L151,150L151,139L149,138L149,137Z`,
      c: [148, 179],
    },
    {
      name: `Ghor`,
      d: `M255,212L258,212L261,208L260,204L262,203L261,201L258,201L255,198L255,194L249,188L236,190L237,180L234,180L232,182L228,181L219,173L210,172L207,176L202,176L200,173L197,172L191,174L184,174L184,176L184,178L189,180L192,184L196,195L188,197L179,197L172,200L172,208L169,209L163,209L163,220L135,219L135,223L130,228L130,229L134,233L132,239L134,241L135,248L129,249L122,252L118,253L121,260L121,265L130,266L132,264L137,265L139,261L148,261L152,256L154,256L162,266L162,270L173,270L173,267L175,265L178,266L197,265L200,262L204,262L204,261L207,259L208,256L211,255L212,254L212,244L209,239L209,236L212,236L213,234L214,234L214,230L211,224L213,217L231,216L238,213L255,212Z`,
      c: [188, 221],
    },
    {
      name: `Herat`,
      d: `M107,170L102,173L98,173L95,172L88,178L87,172L77,164L65,166L60,163L58,160L53,156L49,156L48,157L45,169L42,172L43,184L39,198L37,202L27,206L32,212L32,215L28,216L27,218L20,224L20,235L22,238L21,247L24,251L41,257L53,257L59,255L61,254L66,254L68,266L69,268L69,276L71,284L72,289L80,290L88,288L91,285L92,280L98,275L106,275L107,273L116,272L119,267L121,265L121,260L118,253L122,252L129,249L135,248L134,241L132,239L134,233L130,229L130,228L135,223L135,219L163,220L163,209L169,209L172,208L172,202L168,204L160,203L157,206L152,206L151,207L144,208L137,207L135,204L131,203L126,203L118,202L116,199L111,198L109,195L103,193L101,184L104,180L108,178L107,170Z`,
      c: [91, 216],
    },
    {
      name: `Farah`,
      d: `M121,265L119,267L116,272L107,273L106,275L98,275L92,280L91,285L88,288L80,290L76,290L72,289L71,284L69,276L69,268L68,266L66,254L61,254L59,255L53,257L45,257L41,257L34,254L34,257L30,264L22,271L24,274L25,283L28,291L28,296L33,312L33,315L31,320L33,348L35,350L38,351L60,356L65,356L64,345L71,341L74,331L75,327L79,324L97,324L102,321L107,321L111,324L115,324L118,321L122,316L125,315L131,315L135,317L139,316L162,302L166,296L167,288L171,287L176,282L177,277L180,274L180,266L178,266L175,265L173,267L173,270L162,270L162,266L154,256L152,256L148,261L139,261L137,265L132,264L130,266L121,265Z`,
      c: [98, 289],
    },
    {
      name: `Nimruz`,
      d: `M65,355L69,369L67,382L65,383L56,395L44,412L32,427L40,432L48,434L67,442L76,445L78,447L83,448L88,451L94,451L98,449L99,423L102,419L102,416L107,406L120,384L125,364L128,357L128,339L132,329L135,316L131,315L125,315L122,316L118,321L115,324L111,324L107,321L102,321L97,324L79,324L75,327L74,331L71,341L64,345L65,355Z`,
      c: [91, 381],
    },
    {
      name: `Helmand`,
      d: `M203,313L206,299L204,297L201,286L202,281L206,274L206,270L207,269L207,267L205,265L204,262L200,262L197,265L187,265L186,267L180,266L180,274L178,275L177,277L175,283L171,287L167,288L166,296L162,302L139,316L135,316L132,329L128,339L128,352L128,357L125,364L120,384L102,416L102,419L99,423L98,449L106,450L108,448L130,446L148,446L156,448L160,448L164,444L174,442L174,427L178,403L181,376L184,368L187,342L189,334L193,332L197,327L200,318L203,313Z`,
      c: [162, 344],
    },
    {
      name: `Badakhshan`,
      d: `M398,153L403,152L406,154L408,157L408,162L410,162L412,159L416,160L418,162L420,162L420,153L426,152L426,148L427,144L430,142L431,138L433,136L435,136L436,133L443,128L444,126L454,118L460,122L461,115L473,110L478,105L487,104L491,101L496,99L510,97L524,97L528,98L540,98L545,101L550,96L554,96L559,93L567,93L567,91L563,88L561,82L568,80L573,79L578,81L580,80L574,74L555,69L548,75L544,78L533,80L532,77L534,74L534,70L528,69L520,69L500,77L496,79L491,88L480,91L462,105L457,106L453,104L449,95L446,82L451,58L450,46L447,46L441,48L442,33L438,31L438,29L428,21L426,20L416,24L404,40L398,47L395,48L395,49L399,54L400,58L394,64L391,64L389,62L389,68L389,76L391,78L390,82L392,84L396,84L396,86L395,86L393,89L389,98L390,107L392,111L392,118L397,122L406,123L406,131L402,136L402,141L397,144L398,153Z`,
      c: [458, 90],
    },
  ],
  Or = {
    Badakhshan: {
      dari: `بدخشان`,
      capital: `Fayzabad`,
    },
    Badghis: {
      dari: `بادغیس`,
      capital: `Qala-e Naw`,
    },
    Baghlan: {
      dari: `بغلان`,
      capital: `Pul-e Khumri`,
    },
    Balkh: {
      dari: `بلخ`,
      capital: `Mazar-e Sharif`,
    },
    Bamyan: {
      dari: `بامیان`,
      capital: `Bamyan`,
    },
    Daykundi: {
      dari: `دایکندی`,
      capital: `Nili`,
    },
    Farah: {
      dari: `فراه`,
      capital: `Farah`,
    },
    Faryab: {
      dari: `فاریاب`,
      capital: `Maymana`,
    },
    Ghanzi: {
      label: `Ghazni`,
      dari: `غزنی`,
      capital: `Ghazni`,
    },
    Ghor: {
      dari: `غور`,
      capital: `Chaghcharan`,
    },
    Helmand: {
      dari: `هلمند`,
      capital: `Lashkar Gah`,
    },
    Herat: {
      dari: `هرات`,
      capital: `Herat`,
    },
    Jowzjan: {
      dari: `جوزجان`,
      capital: `Sheberghan`,
    },
    Kabul: {
      dari: `کابل`,
      capital: `Kabul`,
    },
    Kandahar: {
      dari: `کندهار`,
      capital: `Kandahar`,
    },
    Kapisa: {
      dari: `کاپیسا`,
      capital: `Mahmud-e Raqi`,
    },
    Khost: {
      dari: `خوست`,
      capital: `Khost`,
    },
    Kunar: {
      dari: `کنر`,
      capital: `Asadabad`,
    },
    Kunduz: {
      dari: `کندز`,
      capital: `Kunduz`,
    },
    Laghman: {
      dari: `لغمان`,
      capital: `Mehtar Lam`,
    },
    Logar: {
      dari: `لوگر`,
      capital: `Pul-e Alam`,
    },
    Nangarhar: {
      dari: `ننگرهار`,
      capital: `Jalalabad`,
    },
    Nimruz: {
      dari: `نیمروز`,
      capital: `Zaranj`,
    },
    Nuristan: {
      dari: `نورستان`,
      capital: `Parun`,
    },
    Paktia: {
      dari: `پکتیا`,
      capital: `Gardez`,
    },
    Paktika: {
      dari: `پکتیکا`,
      capital: `Sharana`,
    },
    Panjshir: {
      dari: `پنجشیر`,
      capital: `Bazarak`,
    },
    Parwan: {
      dari: `پروان`,
      capital: `Charikar`,
    },
    Samangan: {
      dari: `سمنگان`,
      capital: `Aybak`,
    },
    "Sar-e Pol": {
      dari: `سرپل`,
      capital: `Sar-e Pol`,
    },
    Takhar: {
      dari: `تخار`,
      capital: `Taloqan`,
    },
    Uruzgan: {
      dari: `ارزگان`,
      capital: `Tarinkot`,
    },
    Wardak: {
      dari: `وردک`,
      capital: `Maidan Shahr`,
    },
    Zabul: {
      dari: `زابل`,
      capital: `Qalat`,
    },
  },
  kr = (e) => Or[e]?.label ?? e,
  Ar = {
    Kabul: {
      role: `Main office`,
      main: !0,
      lx: 16,
      ly: 2,
    },
    Badakhshan: {
      role: `Sub-office`,
      main: !1,
      lx: 16,
      ly: 22,
    },
  },
  jr = 24,
  Mr = Er.width + 48 + 70,
  Nr = Er.height + 48,
  Pr = (e, t) => `${((e + jr) / t) * 100}%`,
  Fr = Object.fromEntries(Dr.map((e) => [e.name, e])),
  Ir = [...Dr].sort((e, t) => kr(e.name).localeCompare(kr(t.name)));
function Lr({ name: e, onClose: t }) {
  let n = Or[e] ?? {},
    r = kr(e),
    i = Ar[e],
    a = nr.filter((e) => e.location === r);
  return (0, M.jsxs)(`div`, {
    className: `map-info-detail ${i ? (i.main ? `is-main` : `is-sub`) : ``}`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `map-info-head`,
        children: [
          (0, M.jsx)(`strong`, {
            children: r,
          }),
          n.dari &&
            (0, M.jsx)(`span`, {
              lang: `fa`,
              children: n.dari,
            }),
          (0, M.jsx)(`button`, {
            className: `map-info-close`,
            onClick: t,
            "aria-label": `Close province details`,
            children: (0, M.jsx)(N, {
              name: `close`,
              size: 16,
              strokeWidth: 2,
            }),
          }),
        ],
      }),
      (0, M.jsxs)(`p`, {
        className: `map-info-meta`,
        children: [
          i &&
            (0, M.jsxs)(`b`, {
              children: [`PWSO `, i.role.toLowerCase()],
            }),
          n.capital &&
            (0, M.jsxs)(`span`, {
              children: [`Provincial capital: `, n.capital],
            }),
        ],
      }),
      a.length > 0
        ? (0, M.jsx)(`ul`, {
            className: `map-info-projects`,
            children: a.map((e) =>
              (0, M.jsxs)(
                `li`,
                {
                  children: [
                    e.year &&
                      (0, M.jsx)(`span`, {
                        children: e.year,
                      }),
                    e.title,
                    `: `,
                    e.reach || `with ${e.funder}`,
                  ],
                },
                e.id,
              ),
            ),
          })
        : (0, M.jsx)(`p`, {
            className: `map-info-note`,
            children: i
              ? `Our team here works with local women and communities.`
              : `PWSO has no office in this province. Our teams work from Kabul and Badakhshan.`,
          }),
    ],
  });
}
function Rr({
  caption: e = `PWSO offices in Kabul and Badakhshan`,
  dark: t = !1,
}) {
  let [n, r] = (0, x.useState)(null),
    [i, a] = (0, x.useState)(null),
    o = Dr.filter((e) => Ar[e.name]),
    s = (e) => r((t) => (t === e ? null : e)),
    c = i && Fr[i],
    l = n && Fr[n];
  return (0, M.jsxs)(`figure`, {
    className: `map ${t ? `map-dark` : ``} ${n ? `has-selection` : ``}`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `map-canvas`,
        children: [
          (0, M.jsxs)(`svg`, {
            viewBox: `-24 -24 ${Mr} ${Nr}`,
            role: `img`,
            "aria-label": `Map of Afghanistan showing PWSO's main office in Kabul and sub-office in Badakhshan. Select a province below the map for details.`,
            children: [
              (0, M.jsx)(`g`, {
                children: Dr.map((e) => {
                  let t = Ar[e.name],
                    r = [
                      `province`,
                      t && `is-office`,
                      t && !t.main && `is-sub`,
                      e.name === n && `is-selected`,
                      e.name === i && `is-hover`,
                    ];
                  return (0, M.jsx)(
                    `path`,
                    {
                      d: e.d,
                      className: r.filter(Boolean).join(` `),
                      onClick: () => s(e.name),
                      onPointerEnter: (t) => {
                        t.pointerType === `mouse` && a(e.name);
                      },
                      onPointerLeave: () => a(null),
                    },
                    e.name,
                  );
                }),
              }),
              l &&
                (0, M.jsx)(`path`, {
                  className: `province-outline`,
                  d: l.d,
                }),
              o.map((e) =>
                (0, M.jsxs)(
                  `g`,
                  {
                    className: `map-marker ${Ar[e.name].main ? `is-main` : `is-sub`}`,
                    transform: `translate(${e.c[0]} ${e.c[1]})`,
                    children: [
                      (0, M.jsx)(`circle`, {
                        className: `map-pulse`,
                        r: `10`,
                      }),
                      (0, M.jsx)(`circle`, {
                        className: `map-dot`,
                        r: `6`,
                      }),
                    ],
                  },
                  e.name,
                ),
              ),
            ],
          }),
          o.map((e) => {
            let t = Ar[e.name];
            return (0, M.jsxs)(
              `span`,
              {
                className: `map-label ${t.main ? `` : `is-sub`}`,
                "aria-hidden": `true`,
                style: {
                  left: Pr(e.c[0] + t.lx, Mr),
                  top: Pr(e.c[1] + t.ly, Nr),
                },
                children: [
                  (0, M.jsx)(`strong`, {
                    children: e.name,
                  }),
                  (0, M.jsx)(`small`, {
                    children: t.role,
                  }),
                ],
              },
              e.name,
            );
          }),
          c &&
            !Ar[c.name] &&
            (0, M.jsxs)(`span`, {
              className: `map-tip`,
              "aria-hidden": `true`,
              style: {
                left: Pr(c.c[0], Mr),
                top: Pr(c.c[1], Nr),
              },
              children: [
                kr(c.name),
                ` `,
                (0, M.jsx)(`span`, {
                  lang: `fa`,
                  children: Or[c.name]?.dari,
                }),
              ],
            }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `map-info`,
        children: [
          (0, M.jsx)(`div`, {
            "aria-live": `polite`,
            children: n
              ? (0, M.jsx)(Lr, {
                  name: n,
                  onClose: () => r(null),
                })
              : (0, M.jsxs)(`div`, {
                  className: `map-info-idle`,
                  children: [
                    (0, M.jsx)(`p`, {
                      children: `Select a province on the map to see what PWSO does there.`,
                    }),
                    (0, M.jsx)(`div`, {
                      className: `map-info-actions`,
                      children: o.map((e) =>
                        (0, M.jsxs)(
                          `button`,
                          {
                            className: `map-chip ${Ar[e.name].main ? `` : `is-sub`}`,
                            onClick: () => r(e.name),
                            children: [
                              (0, M.jsx)(`strong`, {
                                children: e.name,
                              }),
                              ` `,
                              Ar[e.name].role,
                            ],
                          },
                          e.name,
                        ),
                      ),
                    }),
                  ],
                }),
          }),
          (0, M.jsxs)(`label`, {
            className: `map-find`,
            children: [
              (0, M.jsx)(N, {
                name: `search`,
                size: 15,
                strokeWidth: 2,
              }),
              (0, M.jsx)(`span`, {
                className: `sr-only`,
                children: `Find a province`,
              }),
              (0, M.jsxs)(`select`, {
                value: n ?? ``,
                onChange: (e) => r(e.target.value || null),
                children: [
                  (0, M.jsx)(`option`, {
                    value: ``,
                    children: `Find a province…`,
                  }),
                  Ir.map((e) =>
                    (0, M.jsx)(
                      `option`,
                      {
                        value: e.name,
                        children: kr(e.name),
                      },
                      e.name,
                    ),
                  ),
                ],
              }),
            ],
          }),
        ],
      }),
      (0, M.jsxs)(`figcaption`, {
        children: [
          (0, M.jsxs)(`div`, {
            className: `map-legend`,
            children: [
              (0, M.jsxs)(`span`, {
                children: [
                  (0, M.jsx)(`i`, {
                    className: `dot-main`,
                  }),
                  ` Main office`,
                ],
              }),
              (0, M.jsxs)(`span`, {
                children: [
                  (0, M.jsx)(`i`, {
                    className: `dot-sub`,
                  }),
                  ` Sub-office`,
                ],
              }),
            ],
          }),
          (0, M.jsx)(`p`, {
            className: `map-caption`,
            children: e,
          }),
        ],
      }),
    ],
  });
}
function zr({ children: e, light: t = !1 }) {
  return (0, M.jsx)(`p`, {
    className: `eyebrow ${t ? `eyebrow-light` : ``}`,
    children: e,
  });
}
function Br({
  crumb: e,
  parent: t,
  title: n,
  sub: r,
  lead: i,
  img: a,
  imgAlt: o = ``,
  children: s,
}) {
  return (0, M.jsx)(`section`, {
    className: `page-hero`,
    children: (0, M.jsxs)(`div`, {
      className: `container page-hero-grid`,
      children: [
        (0, M.jsxs)(`div`, {
          className: `page-hero-text`,
          children: [
            (0, M.jsxs)(`nav`, {
              className: `crumbs`,
              "aria-label": `Breadcrumb`,
              children: [
                (0, M.jsx)(j, {
                  to: `/`,
                  children: `Home`,
                }),
                t &&
                  (0, M.jsxs)(M.Fragment, {
                    children: [
                      (0, M.jsx)(N, {
                        name: `chevronRight`,
                        size: 14,
                        strokeWidth: 2,
                      }),
                      (0, M.jsx)(j, {
                        to: t.to,
                        children: t.label,
                      }),
                    ],
                  }),
                (0, M.jsx)(N, {
                  name: `chevronRight`,
                  size: 14,
                  strokeWidth: 2,
                }),
                (0, M.jsx)(`span`, {
                  "aria-current": `page`,
                  children: e,
                }),
              ],
            }),
            (0, M.jsx)(`h1`, {
              children: n,
            }),
            r &&
              (0, M.jsx)(`p`, {
                className: `subhead`,
                children: r,
              }),
            i &&
              (0, M.jsx)(`p`, {
                className: `lead`,
                children: i,
              }),
            s,
          ],
        }),
        (0, M.jsxs)(`div`, {
          className: `page-hero-media`,
          children: [
            (0, M.jsx)(`img`, {
              src: a,
              alt: o,
            }),
            (0, M.jsx)(Vr, {
              className: `page-hero-stamp`,
            }),
          ],
        }),
      ],
    }),
  });
}
function Vr({ className: e = `` }) {
  return (0, M.jsx)(`div`, {
    className: `pwso-tiles ${e}`,
    "aria-hidden": `true`,
    children: [`P`, `W`, `S`, `O`].map((e) =>
      (0, M.jsx)(
        `span`,
        {
          className: `ltile`,
          children: (0, M.jsx)(`span`, {
            className: `ltile-letter`,
            children: e,
          }),
        },
        e,
      ),
    ),
  });
}
function Hr({
  eyebrow: e,
  title: t,
  text: n,
  action: r,
  center: i = !1,
  light: a = !1,
}) {
  return (0, M.jsxs)(`div`, {
    className: `section-head ${i ? `is-center` : ``}`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `section-head-main`,
        children: [
          e &&
            (0, M.jsx)(zr, {
              light: a,
              children: e,
            }),
          (0, M.jsx)(`h2`, {
            children: t,
          }),
          n &&
            (0, M.jsx)(`p`, {
              className: `section-text`,
              children: n,
            }),
        ],
      }),
      r &&
        (0, M.jsx)(`div`, {
          className: `section-action`,
          children: r,
        }),
    ],
  });
}
function Ur({ id: e, num: t, title: n, sub: r, aside: i, children: a }) {
  return (0, M.jsxs)(`article`, {
    className: `panel rv`,
    id: e,
    children: [
      (0, M.jsxs)(`div`, {
        className: `panel-head`,
        children: [
          t &&
            (0, M.jsx)(`span`, {
              className: `panel-num`,
              children: t,
            }),
          (0, M.jsx)(`h2`, {
            children: n,
          }),
          r &&
            (0, M.jsx)(`p`, {
              children: r,
            }),
          i,
        ],
      }),
      (0, M.jsx)(`div`, {
        className: `panel-body`,
        children: a,
      }),
    ],
  });
}
function Wr({ to: e, href: t, children: n, className: r = ``, ...i }) {
  let a = (0, M.jsxs)(M.Fragment, {
    children: [
      (0, M.jsx)(`span`, {
        children: n,
      }),
      (0, M.jsx)(N, {
        name: `arrow`,
        size: 18,
        strokeWidth: 2,
      }),
    ],
  });
  return t
    ? (0, M.jsx)(`a`, {
        href: t,
        className: `link-arrow ${r}`,
        ...i,
        children: a,
      })
    : (0, M.jsx)(j, {
        to: e,
        className: `link-arrow ${r}`,
        ...i,
        children: a,
      });
}
function Gr({ name: e, size: t = `md`, tone: n = `brand` }) {
  return (0, M.jsx)(`span`, {
    className: `icon-tile icon-tile-${t} icon-tile-${n}`,
    children: (0, M.jsx)(N, {
      name: e,
      size: t === `lg` ? 26 : t === `sm` ? 20 : 22,
      strokeWidth: 1.9,
    }),
  });
}
function Kr({ items: e }) {
  return (0, M.jsx)(`ul`, {
    className: `checks`,
    children: e.map((e) =>
      (0, M.jsx)(
        `li`,
        {
          children: e,
        },
        e,
      ),
    ),
  });
}
function qr({
  variant: e = `primary`,
  label: t = `Download profile`,
  className: n = ``,
}) {
  return (0, M.jsxs)(`a`, {
    href: P.profileUrl,
    className: `btn btn-${e} ${n}`,
    download: !0,
    children: [
      (0, M.jsx)(N, {
        name: `download`,
        size: 18,
        strokeWidth: 2,
      }),
      ` `,
      t,
    ],
  });
}
function Jr({ eyebrow: e, title: t, text: n, primary: r, secondary: i }) {
  return (0, M.jsxs)(`section`, {
    className: `cta-wrap`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `cta-tiles`,
        "aria-hidden": `true`,
        children: [
          (0, M.jsx)(`span`, {
            children: `P`,
          }),
          (0, M.jsx)(`span`, {
            children: `W`,
          }),
          (0, M.jsx)(`span`, {
            children: `S`,
          }),
          (0, M.jsx)(`span`, {
            children: `O`,
          }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `container cta`,
        children: [
          (0, M.jsxs)(`div`, {
            className: `cta-text`,
            children: [
              e &&
                (0, M.jsx)(zr, {
                  children: e,
                }),
              (0, M.jsx)(`h2`, {
                children: t,
              }),
              n &&
                (0, M.jsx)(`p`, {
                  children: n,
                }),
            ],
          }),
          (0, M.jsxs)(`div`, {
            className: `cta-actions`,
            children: [
              r &&
                (0, M.jsxs)(j, {
                  to: r.to,
                  className: `btn btn-ink`,
                  children: [
                    r.label,
                    ` `,
                    (0, M.jsx)(N, {
                      name: `arrow`,
                      size: 18,
                      strokeWidth: 2,
                    }),
                  ],
                }),
              i?.download
                ? (0, M.jsx)(qr, {
                    variant: `outline-ink`,
                    label: i.label,
                  })
                : i
                  ? (0, M.jsx)(j, {
                      to: i.to,
                      className: `btn btn-outline-ink`,
                      children: i.label,
                    })
                  : null,
            ],
          }),
        ],
      }),
    ],
  });
}
function Yr({
  title: e = `Organization Profile 2026`,
  text: t,
  compact: n = !1,
}) {
  return (0, M.jsxs)(`div`, {
    className: `profile-card ${n ? `is-compact` : ``}`,
    children: [
      (0, M.jsxs)(`span`, {
        className: `doc-thumb`,
        "aria-hidden": `true`,
        children: [
          (0, M.jsxs)(`span`, {
            className: `doc-thumb-lines`,
            children: [
              (0, M.jsx)(`i`, {}),
              (0, M.jsx)(`i`, {}),
              (0, M.jsx)(`i`, {}),
              (0, M.jsx)(`i`, {}),
            ],
          }),
          (0, M.jsx)(`b`, {
            children: `PDF`,
          }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `profile-card-body`,
        children: [
          (0, M.jsx)(`p`, {
            className: `profile-card-kicker`,
            children: `Official document`,
          }),
          (0, M.jsx)(`h3`, {
            children: e,
          }),
          t &&
            (0, M.jsx)(`p`, {
              children: t,
            }),
        ],
      }),
      (0, M.jsx)(qr, {
        label: `Download`,
      }),
    ],
  });
}
function Xr() {
  return (0, M.jsxs)(`div`, {
    className: `voice rv`,
    children: [
      (0, M.jsx)(`img`, {
        className: `voice-art`,
        src: `./assets/img/il/feedback.svg`,
        alt: ``,
        "aria-hidden": `true`,
        loading: `lazy`,
        width: `150`,
        height: `113`,
      }),
      (0, M.jsxs)(`div`, {
        className: `voice-main`,
        children: [
          (0, M.jsx)(zr, {
            children: `Feedback & safeguarding`,
          }),
          (0, M.jsxs)(`h2`, {
            children: [
              `Speak up. `,
              (0, M.jsx)(`em`, {
                children: `We listen.`,
              }),
            ],
          }),
          (0, M.jsx)(`p`, {
            children: `Community members, partners and anyone affected by our work can share feedback, ask a question or raise a concern. Every message is read by our team.`,
          }),
          (0, M.jsxs)(`div`, {
            className: `btn-row`,
            children: [
              (0, M.jsxs)(j, {
                to: `/contact?category=Feedback`,
                className: `btn btn-primary`,
                children: [
                  `Share feedback `,
                  (0, M.jsx)(N, {
                    name: `arrow`,
                    size: 18,
                    strokeWidth: 2,
                  }),
                ],
              }),
              (0, M.jsxs)(j, {
                to: `/resources#feedback`,
                className: `link-arrow`,
                children: [
                  (0, M.jsx)(`span`, {
                    children: `How we handle feedback`,
                  }),
                  (0, M.jsx)(N, {
                    name: `arrow`,
                    size: 18,
                    strokeWidth: 2,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      (0, M.jsxs)(`ul`, {
        className: `voice-channels`,
        children: [
          (0, M.jsx)(`li`, {
            children: (0, M.jsxs)(`a`, {
              href: `mailto:${P.email}`,
              children: [
                (0, M.jsx)(`span`, {
                  className: `icon-circle`,
                  children: (0, M.jsx)(N, {
                    name: `mail`,
                    size: 20,
                  }),
                }),
                (0, M.jsxs)(`span`, {
                  className: `voice-ch-text`,
                  children: [
                    (0, M.jsx)(`strong`, {
                      children: `Email`,
                    }),
                    (0, M.jsx)(`span`, {
                      children: P.email,
                    }),
                  ],
                }),
                (0, M.jsx)(N, {
                  name: `arrowUpRight`,
                  size: 18,
                }),
              ],
            }),
          }),
          (0, M.jsx)(`li`, {
            children: (0, M.jsxs)(`a`, {
              href: `tel:${P.phone.replace(/\s/g, ``)}`,
              children: [
                (0, M.jsx)(`span`, {
                  className: `icon-circle`,
                  children: (0, M.jsx)(N, {
                    name: `phone`,
                    size: 20,
                  }),
                }),
                (0, M.jsxs)(`span`, {
                  className: `voice-ch-text`,
                  children: [
                    (0, M.jsx)(`strong`, {
                      children: `Phone`,
                    }),
                    (0, M.jsx)(`span`, {
                      children: P.phone,
                    }),
                  ],
                }),
                (0, M.jsx)(N, {
                  name: `arrowUpRight`,
                  size: 18,
                }),
              ],
            }),
          }),
          (0, M.jsx)(`li`, {
            children: (0, M.jsxs)(j, {
              to: `/contact`,
              children: [
                (0, M.jsx)(`span`, {
                  className: `icon-circle`,
                  children: (0, M.jsx)(N, {
                    name: `pin`,
                    size: 20,
                  }),
                }),
                (0, M.jsxs)(`span`, {
                  className: `voice-ch-text`,
                  children: [
                    (0, M.jsx)(`strong`, {
                      children: `In person`,
                    }),
                    (0, M.jsx)(`span`, {
                      children: `Our offices in Kabul and Badakhshan`,
                    }),
                  ],
                }),
                (0, M.jsx)(N, {
                  name: `arrow`,
                  size: 18,
                }),
              ],
            }),
          }),
        ],
      }),
    ],
  });
}
function Zr() {
  return (0, M.jsx)(`div`, {
    className: `office-cards`,
    children: Qn.map((e) =>
      (0, M.jsxs)(
        `article`,
        {
          className: `office-card`,
          children: [
            (0, M.jsx)(`div`, {
              className: `office-card-media`,
              children: (0, M.jsx)(`img`, {
                src: e.img,
                alt: `${e.city}, Afghanistan`,
                loading: `lazy`,
              }),
            }),
            (0, M.jsx)(`div`, {
              className: `office-card-body`,
              children: (0, M.jsxs)(`div`, {
                children: [
                  (0, M.jsx)(`p`, {
                    className: `office-role`,
                    children: e.role,
                  }),
                  (0, M.jsxs)(`h3`, {
                    children: [
                      e.city,
                      ` `,
                      (0, M.jsx)(`span`, {
                        lang: `fa`,
                        children: e.dari,
                      }),
                    ],
                  }),
                  (0, M.jsx)(`p`, {
                    children: e.text,
                  }),
                ],
              }),
            }),
          ],
        },
        e.city,
      ),
    ),
  });
}
function Qr({ items: e, value: t, onChange: n, label: r }) {
  return (0, M.jsx)(`div`, {
    className: `segmented`,
    role: `tablist`,
    "aria-label": r,
    children: e.map((e) => {
      let r = typeof e == `string` ? e : e.key;
      return (0, M.jsx)(
        `button`,
        {
          role: `tab`,
          "aria-selected": t === r,
          onClick: () => n(r),
          children: typeof e == `string` ? e : e.label,
        },
        r,
      );
    }),
  });
}
function $r({ value: e, onChange: t, placeholder: n, label: r }) {
  return (0, M.jsxs)(`label`, {
    className: `search`,
    children: [
      (0, M.jsx)(N, {
        name: `search`,
        size: 18,
        strokeWidth: 2,
      }),
      (0, M.jsx)(`input`, {
        type: `search`,
        placeholder: n,
        "aria-label": r,
        value: e,
        onChange: (e) => t(e.target.value),
      }),
    ],
  });
}
function ei({ icon: e = `inbox`, art: t, title: n, text: r, children: i }) {
  return (0, M.jsxs)(`div`, {
    className: `empty-state`,
    children: [
      t
        ? (0, M.jsx)(`img`, {
            className: `empty-art`,
            src: `./assets/img/il/${t}.svg`,
            alt: ``,
            "aria-hidden": `true`,
            loading: `lazy`,
            width: `160`,
            height: `120`,
          })
        : (0, M.jsx)(Gr, {
            name: e,
            size: `lg`,
            tone: `neutral`,
          }),
      (0, M.jsx)(`h3`, {
        children: n,
      }),
      r &&
        (0, M.jsx)(`p`, {
          children: r,
        }),
      i,
    ],
  });
}
function ti({ items: e }) {
  return (0, M.jsx)(`ol`, {
    className: `steps`,
    children: e.map((e, t) =>
      (0, M.jsxs)(
        `li`,
        {
          className: `step`,
          children: [
            (0, M.jsx)(`span`, {
              className: `step-num`,
              children: String(t + 1).padStart(2, `0`),
            }),
            (0, M.jsx)(`h3`, {
              children: e.title,
            }),
            (0, M.jsx)(`p`, {
              children: e.text,
            }),
          ],
        },
        e.title,
      ),
    ),
  });
}
function ni({ items: e, defaultOpen: t = 0 }) {
  let [n, r] = (0, x.useState)(t);
  return (0, M.jsx)(`div`, {
    className: `accordion`,
    children: e.map((e, t) => {
      let i = n === t,
        a = `acc-${t}`;
      return (0, M.jsxs)(
        `div`,
        {
          className: `acc-item ${i ? `is-open` : ``}`,
          children: [
            (0, M.jsx)(`h3`, {
              children: (0, M.jsxs)(`button`, {
                "aria-expanded": i,
                "aria-controls": a,
                onClick: () => r(i ? -1 : t),
                children: [
                  (0, M.jsx)(`span`, {
                    children: e.q,
                  }),
                  (0, M.jsx)(`span`, {
                    className: `acc-icon`,
                    "aria-hidden": `true`,
                    children: (0, M.jsx)(N, {
                      name: `plus`,
                      size: 18,
                      strokeWidth: 2,
                    }),
                  }),
                ],
              }),
            }),
            (0, M.jsx)(`div`, {
              className: `acc-panel`,
              id: a,
              hidden: !i,
              children: (0, M.jsx)(`p`, {
                children: e.a,
              }),
            }),
          ],
        },
        e.q,
      );
    }),
  });
}
var ri = `https://${P.website}`;
function ii({
  title: e,
  description: t,
  path: n = `/`,
  image: r = `/og-image.png`,
}) {
  let i = e ? `${e} · ${P.short}` : `${P.short} — ${P.name}`,
    a = ri + n;
  return (0, M.jsxs)(M.Fragment, {
    children: [
      (0, M.jsx)(`title`, {
        children: i,
      }),
      (0, M.jsx)(`meta`, {
        name: `description`,
        content: t,
      }),
      (0, M.jsx)(`link`, {
        rel: `canonical`,
        href: a,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:type`,
        content: `website`,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:site_name`,
        content: P.name,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:title`,
        content: i,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:description`,
        content: t,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:url`,
        content: a,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:image`,
        content: ri + r,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:image:width`,
        content: `1200`,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:image:height`,
        content: `630`,
      }),
      (0, M.jsx)(`meta`, {
        property: `og:locale`,
        content: `en_US`,
      }),
      (0, M.jsx)(`meta`, {
        name: `twitter:card`,
        content: `summary_large_image`,
      }),
      (0, M.jsx)(`meta`, {
        name: `twitter:title`,
        content: i,
      }),
      (0, M.jsx)(`meta`, {
        name: `twitter:description`,
        content: t,
      }),
      (0, M.jsx)(`meta`, {
        name: `twitter:image`,
        content: ri + r,
      }),
    ],
  });
}
var ai = 8e3,
  oi = Object.fromEntries($n.map((e) => [e.id, e])),
  si = ar[0].stats.find((e) => e.value === `Afghan-led`),
  ci = nr.find((e) => e.id === `food-processing`),
  li = [
    {
      key: `mission`,
      label: `Our mission`,
      kicker: `Afghan-led since ${P.established}`,
      color: `var(--brand)`,
      x: 0.34,
      y: 0.66,
      title: (0, M.jsxs)(M.Fragment, {
        children: [
          `Empowering women, `,
          (0, M.jsx)(`em`, {
            children: `strengthening communities.`,
          }),
        ],
      }),
      text: `We support Afghan women and vulnerable communities through education, health and sustainable livelihoods, with practical programs shaped by the people they serve.`,
      img: `./assets/img/hero-sewing.jpg`,
      alt: `Women learning tailoring in a vocational training class`,
      fact: {
        value: si.value,
        text: `${si.label}, for women and communities`,
      },
      primary: {
        to: `/programs`,
        label: `Explore our work`,
      },
    },
    {
      key: `education`,
      label: `Education`,
      kicker: `Education`,
      color: oi.education.color,
      x: 0.44,
      y: 0.7,
      title: (0, M.jsxs)(M.Fragment, {
        children: [
          `Learning for `,
          (0, M.jsx)(`em`, {
            children: `brighter futures.`,
          }),
        ],
      }),
      text: oi.education.text,
      img: oi.education.img,
      alt: `Women reading and writing in a community learning session`,
      fact: {
        value: `Literacy`,
        text: `and life skills for women and girls`,
      },
      primary: {
        to: `/programs#education`,
        label: `Our education work`,
      },
      secondary: {
        to: `/programs`,
        label: `All programs`,
      },
    },
    {
      key: `health`,
      label: `Health`,
      kicker: `Health`,
      color: oi.health.color,
      x: 0.67,
      y: 0.7,
      title: (0, M.jsxs)(M.Fragment, {
        children: [
          `Healthier women, `,
          (0, M.jsx)(`em`, {
            children: `families and communities.`,
          }),
        ],
      }),
      text: oi.health.text,
      img: oi.health.img,
      alt: `A health worker talking with women in a classroom`,
      fact: {
        value: `Health awareness`,
        text: `and health education sessions in communities`,
      },
      primary: {
        to: `/programs#health`,
        label: `Our health work`,
      },
      secondary: {
        to: `/programs`,
        label: `All programs`,
      },
    },
    {
      key: `livelihoods`,
      label: `Livelihoods`,
      kicker: `Economic empowerment`,
      color: oi.economic.color,
      x: 0.34,
      y: 0.68,
      title: (0, M.jsxs)(M.Fragment, {
        children: [
          `Skills, enterprise and `,
          (0, M.jsx)(`em`, {
            children: `sustainable livelihoods.`,
          }),
        ],
      }),
      text: oi.economic.text,
      img: oi.economic.img,
      alt: `A woman embroidering colourful fabric in a training workshop`,
      fact: {
        value: ci.reach,
        text: `trained in food processing and marketing, ${ci.location} ${ci.year}`,
      },
      primary: {
        to: `/programs#economic`,
        label: `Our livelihoods work`,
      },
      secondary: {
        to: `/projects`,
        label: `See our projects`,
      },
    },
  ],
  ui = (e) => String(e).padStart(2, `0`);
function di() {
  let [{ i: e, prev: t }, n] = (0, x.useState)({
      i: 0,
      prev: -1,
    }),
    [r, i] = (0, x.useState)(
      () => window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,
    ),
    [a, o] = (0, x.useState)(null),
    s = li.length,
    c = (e) =>
      n((t) =>
        e === t.i
          ? t
          : {
              i: e,
              prev: t.i,
            },
      ),
    l = (e) =>
      n((t) => ({
        i: (t.i + e + s) % s,
        prev: t.i,
      })),
    u = li[e];
  return (0, M.jsxs)(`section`, {
    className: `hero ${r ? `is-paused` : ``}`,
    "aria-roledescription": `carousel`,
    "aria-label": `PWSO highlights`,
    style: {
      "--hs-c": u.color,
      "--hs-x": u.x,
      "--hs-y": u.y,
      "--dur": `${ai}ms`,
    },
    children: [
      (0, M.jsx)(`h1`, {
        className: `sr-only`,
        children: P.name,
      }),
      (0, M.jsx)(`div`, {
        className: `hs-panel`,
        "aria-hidden": `true`,
      }),
      (0, M.jsxs)(`div`, {
        className: `container hero-grid`,
        children: [
          (0, M.jsxs)(`div`, {
            className: `hs-copy`,
            children: [
              (0, M.jsx)(`div`, {
                className: `hs-slides`,
                "aria-live": r ? `polite` : `off`,
                children: li.map((t, n) =>
                  (0, M.jsxs)(
                    `div`,
                    {
                      className: `hs-slide ${n === e ? `is-active` : ``}`,
                      role: `group`,
                      "aria-roledescription": `slide`,
                      "aria-label": `${n + 1} of ${s}: ${t.label}`,
                      "aria-hidden": n !== e,
                      inert: n !== e,
                      children: [
                        (0, M.jsx)(zr, {
                          children: t.kicker,
                        }),
                        (0, M.jsx)(`h2`, {
                          className: `hs-title`,
                          children: t.title,
                        }),
                        (0, M.jsx)(`p`, {
                          className: `lead`,
                          children: t.text,
                        }),
                        (0, M.jsxs)(`div`, {
                          className: `btn-row`,
                          children: [
                            (0, M.jsxs)(j, {
                              to: t.primary.to,
                              className: `btn btn-primary`,
                              children: [
                                t.primary.label,
                                ` `,
                                (0, M.jsx)(N, {
                                  name: `arrow`,
                                  size: 16,
                                  strokeWidth: 2,
                                }),
                              ],
                            }),
                            t.secondary
                              ? (0, M.jsx)(j, {
                                  to: t.secondary.to,
                                  className: `btn btn-secondary`,
                                  children: t.secondary.label,
                                })
                              : (0, M.jsx)(qr, {
                                  variant: `secondary`,
                                  label: `Organization profile`,
                                }),
                          ],
                        }),
                      ],
                    },
                    t.key,
                  ),
                ),
              }),
              (0, M.jsx)(`div`, {
                className: `hs-tabs`,
                role: `group`,
                "aria-label": `Choose a slide`,
                onKeyDown: (t) => {
                  let n = {
                    ArrowRight: 1,
                    ArrowLeft: -1,
                  }[t.key];
                  if (!n) return;
                  t.preventDefault();
                  let r = (e + n + s) % s;
                  (c(r),
                    document.getElementById(`hs-tab-${li[r].key}`)?.focus());
                },
                children: li.map((t, n) =>
                  (0, M.jsxs)(
                    `button`,
                    {
                      id: `hs-tab-${t.key}`,
                      className: `hs-tab ${n === e ? `is-active` : ``}`,
                      "aria-current": n === e,
                      "aria-label": `Slide ${n + 1}: ${t.label}`,
                      tabIndex: n === e ? 0 : -1,
                      onClick: () => c(n),
                      style: {
                        "--tc": t.color,
                      },
                      children: [
                        (0, M.jsx)(`span`, {
                          className: `hs-thumb`,
                          children: (0, M.jsx)(`img`, {
                            src: t.img,
                            alt: ``,
                          }),
                        }),
                        (0, M.jsxs)(`span`, {
                          className: `hs-tab-label`,
                          children: [
                            (0, M.jsx)(`span`, {
                              className: `hs-tab-num`,
                              children: ui(n + 1),
                            }),
                            (0, M.jsx)(`span`, {
                              className: `hs-tab-text`,
                              children: t.label,
                            }),
                          ],
                        }),
                        (0, M.jsx)(`span`, {
                          className: `hs-track`,
                          children: (0, M.jsx)(`span`, {
                            className: `hs-fill`,
                            onAnimationEnd: (t) => {
                              n === e && t.animationName === `hs-fill` && l(1);
                            },
                          }),
                        }),
                      ],
                    },
                    t.key,
                  ),
                ),
              }),
            ],
          }),
          (0, M.jsxs)(`div`, {
            className: `hs-stage-wrap`,
            onPointerDown: (e) => {
              e.pointerType !== `mouse` && o(e.clientX);
            },
            onPointerUp: (e) => {
              if (a === null) return;
              let t = e.clientX - a;
              (o(null), Math.abs(t) > 40 && l(t < 0 ? 1 : -1));
            },
            onPointerCancel: () => o(null),
            children: [
              (0, M.jsx)(`span`, {
                className: `wheel wheel-spin hs-wheel`,
                "aria-hidden": `true`,
              }),
              (0, M.jsx)(`div`, {
                className: `hs-mosaic`,
                role: `img`,
                "aria-label": u.alt,
                children: [0, 1, 2, 3].map((n) =>
                  (0, M.jsx)(
                    `div`,
                    {
                      className: `hs-tile`,
                      children: li.map((r, i) =>
                        (0, M.jsx)(
                          `img`,
                          {
                            src: r.img,
                            alt: ``,
                            fetchPriority: n === 0 && i === 0 ? `high` : void 0,
                            className:
                              i === e
                                ? `is-active`
                                : i === t
                                  ? `is-prev`
                                  : void 0,
                          },
                          r.key,
                        ),
                      ),
                    },
                    n,
                  ),
                ),
              }),
              (0, M.jsxs)(`div`, {
                className: `hs-controls`,
                children: [
                  (0, M.jsx)(`button`, {
                    onClick: () => l(-1),
                    "aria-label": `Previous slide`,
                    children: (0, M.jsx)(N, {
                      name: `chevronLeft`,
                      size: 16,
                      strokeWidth: 2,
                    }),
                  }),
                  (0, M.jsx)(`button`, {
                    className: `hs-play`,
                    onClick: () => i(!r),
                    "aria-label": r ? `Play slideshow` : `Pause slideshow`,
                    children: (0, M.jsx)(N, {
                      name: r ? `play` : `pause`,
                      size: 13,
                      strokeWidth: 2,
                    }),
                  }),
                  (0, M.jsx)(`button`, {
                    onClick: () => l(1),
                    "aria-label": `Next slide`,
                    children: (0, M.jsx)(N, {
                      name: `chevronRight`,
                      size: 16,
                      strokeWidth: 2,
                    }),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
var fi = [
  {
    letter: `P`,
    value: `${$n.length} programs`,
    text: `Health, education, livelihoods, research and agriculture`,
  },
  {
    letter: `W`,
    value: `Women first`,
    text: `Supporting women and vulnerable communities`,
  },
  {
    letter: `S`,
    value: `Since ${P.established}`,
    text: `Registered with the ${P.registrar}, No. ${P.registration}`,
  },
  {
    letter: `O`,
    value: `${Qn.length} offices`,
    text: `Main office in Kabul, sub-office in Badakhshan`,
  },
];
function pi() {
  let [e, t] = (0, x.useState)(0);
  return (0, M.jsx)(`div`, {
    className: `prog-row`,
    children: $n.map((n, r) =>
      (0, M.jsxs)(
        `article`,
        {
          className: `prog-card ${r === e ? `is-active` : ``}`,
          style: {
            "--c": n.color,
          },
          onMouseEnter: () => t(r),
          onFocus: () => t(r),
          onClick: () => t(r),
          children: [
            (0, M.jsxs)(`div`, {
              className: `prog-card-media`,
              children: [
                (0, M.jsx)(`img`, {
                  src: n.img,
                  alt: ``,
                  loading: `lazy`,
                }),
                (0, M.jsx)(`span`, {
                  className: `prog-card-num`,
                  children: ui(r + 1),
                }),
              ],
            }),
            (0, M.jsx)(`h3`, {
              children: n.title,
            }),
            (0, M.jsx)(`p`, {
              className: `prog-card-tag`,
              children: n.tagline,
            }),
            (0, M.jsx)(`p`, {
              className: `prog-card-more`,
              children: n.text,
            }),
            (0, M.jsxs)(j, {
              to: `/programs#${n.id}`,
              className: `prog-card-link`,
              "aria-label": `About the ${n.title} program`,
              children: [
                `About this program `,
                (0, M.jsx)(N, {
                  name: `arrow`,
                  size: 15,
                  strokeWidth: 2,
                }),
              ],
            }),
          ],
        },
        n.id,
      ),
    ),
  });
}
function mi() {
  let [e, t] = (0, x.useState)(0),
    n = ar[e],
    r = ar.length - 1,
    i = (e) => t(Math.max(0, Math.min(r, e)));
  return (0, M.jsxs)(`div`, {
    className: `journey on-dark`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `journey-head`,
        children: [
          (0, M.jsxs)(`div`, {
            children: [
              (0, M.jsx)(zr, {
                children: `Our journey`,
              }),
              (0, M.jsxs)(`h2`, {
                children: [
                  `Rooted locally, `,
                  (0, M.jsx)(`em`, {
                    children: `growing with purpose.`,
                  }),
                ],
              }),
            ],
          }),
          (0, M.jsxs)(`div`, {
            className: `journey-intro`,
            children: [
              (0, M.jsxs)(`p`, {
                children: [
                  `From our founding in `,
                  P.established,
                  ` to our work today, these are the milestones that have shaped PWSO, as recorded in our organization profile.`,
                ],
              }),
              (0, M.jsx)(Wr, {
                to: `/about`,
                children: `Read our full story`,
              }),
            ],
          }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `tl`,
        role: `tablist`,
        "aria-label": `Milestones`,
        onKeyDown: (n) => {
          let i = {
            ArrowRight: 1,
            ArrowLeft: -1,
          }[n.key];
          if (!i) return;
          n.preventDefault();
          let a = Math.max(0, Math.min(r, e + i));
          (t(a), document.getElementById(`tl-tab-${ar[a].key}`)?.focus());
        },
        style: {
          "--progress": e / ar.length,
        },
        children: [
          (0, M.jsx)(`div`, {
            className: `tl-track`,
            "aria-hidden": `true`,
            children: (0, M.jsx)(`span`, {
              className: `tl-fill`,
            }),
          }),
          ar.map((n, r) =>
            (0, M.jsxs)(
              `button`,
              {
                role: `tab`,
                id: `tl-tab-${n.key}`,
                "aria-selected": r === e,
                "aria-controls": `tl-panel`,
                tabIndex: r === e ? 0 : -1,
                className: `tl-stop ${r < e ? `is-past` : ``}`,
                onClick: () => t(r),
                children: [
                  (0, M.jsx)(`span`, {
                    className: `tl-node`,
                    "aria-hidden": `true`,
                  }),
                  (0, M.jsx)(`span`, {
                    className: `tl-year`,
                    children: n.year,
                  }),
                  (0, M.jsx)(`span`, {
                    className: `tl-label`,
                    children: n.label,
                  }),
                ],
              },
              n.key,
            ),
          ),
        ],
      }),
      (0, M.jsxs)(
        `article`,
        {
          className: `tl-panel`,
          id: `tl-panel`,
          role: `tabpanel`,
          "aria-labelledby": `tl-tab-${n.key}`,
          children: [
            (0, M.jsxs)(`div`, {
              className: `tl-media`,
              children: [
                (0, M.jsx)(`img`, {
                  src: n.img,
                  alt: ``,
                }),
                (0, M.jsxs)(`span`, {
                  className: `tl-place`,
                  children: [
                    (0, M.jsx)(N, {
                      name: `pin`,
                      size: 14,
                    }),
                    ` `,
                    n.place,
                  ],
                }),
              ],
            }),
            (0, M.jsxs)(`div`, {
              className: `tl-body`,
              children: [
                (0, M.jsxs)(`p`, {
                  className: `tl-kicker`,
                  children: [
                    (0, M.jsxs)(`span`, {
                      children: [
                        `Milestone `,
                        ui(e + 1),
                        ` of `,
                        ui(ar.length),
                      ],
                    }),
                    n.kicker,
                  ],
                }),
                (0, M.jsx)(`h3`, {
                  children: n.title,
                }),
                n.text.map((e) =>
                  (0, M.jsx)(
                    `p`,
                    {
                      children: e,
                    },
                    e,
                  ),
                ),
                (0, M.jsx)(`dl`, {
                  className: `tl-stats`,
                  children: n.stats.map((e) =>
                    (0, M.jsxs)(
                      `div`,
                      {
                        children: [
                          (0, M.jsx)(`dt`, {
                            children: e.label,
                          }),
                          (0, M.jsx)(`dd`, {
                            children: e.value,
                          }),
                        ],
                      },
                      e.label,
                    ),
                  ),
                }),
                (0, M.jsxs)(`div`, {
                  className: `tl-nav`,
                  children: [
                    (0, M.jsx)(`button`, {
                      className: `round-btn`,
                      onClick: () => i(e - 1),
                      disabled: e === 0,
                      "aria-label": `Previous milestone`,
                      children: (0, M.jsx)(N, {
                        name: `chevronLeft`,
                        size: 16,
                        strokeWidth: 2,
                      }),
                    }),
                    (0, M.jsx)(`button`, {
                      className: `round-btn is-solid`,
                      onClick: () => i(e + 1),
                      disabled: e === r,
                      "aria-label": `Next milestone`,
                      children: (0, M.jsx)(N, {
                        name: `chevronRight`,
                        size: 16,
                        strokeWidth: 2,
                      }),
                    }),
                    (0, M.jsx)(`span`, {
                      children:
                        e < r
                          ? `Next: ${ar[e + 1].year}, ${ar[e + 1].label.toLowerCase()}`
                          : `And the journey continues.`,
                    }),
                  ],
                }),
              ],
            }),
          ],
        },
        n.key,
      ),
    ],
  });
}
var hi = [
    {
      icon: `users`,
      color: `var(--prio-empower)`,
      title: `Women's empowerment`,
      text: `Building skills, expanding opportunity and supporting women's participation in community life.`,
    },
    {
      icon: `book`,
      color: `var(--prio-learning)`,
      title: `Learning & wellbeing`,
      text: `Increasing access to education and essential health services for women and communities.`,
    },
    {
      icon: `sprout`,
      color: `var(--prio-livelihoods)`,
      title: `Sustainable livelihoods`,
      text: `Creating economic opportunities and supporting agricultural resilience for self-reliance.`,
    },
    {
      icon: `scale`,
      color: `var(--prio-accountability)`,
      title: `Accountability`,
      text: `Listening to communities and using evidence and learning to stay relevant and responsive.`,
    },
  ],
  gi = nr.reduce((e, t) => e + (parseInt(t.reach, 10) || 0), 0);
var vi = [
    `PWSO was established in ${P.established} as an Afghan non-profit organization and is registered with the ${P.registrar} under registration number ${P.registration}.`,
    `We began with a clear focus: supporting Afghan women and vulnerable communities through education, health and sustainable livelihoods.`,
    `In 2018 we trained 100 women in Badakhshan in food processing and marketing; in 2019, with AKF, we reached 150 men and women through awareness of harmful traditional practices.`,
    `With medica mondiale, we strengthened our organizational capacity through policy, systems and strategy development.`,
    `Today we work across five program areas from our main office in Kabul and our sub-office in Badakhshan.`,
  ],
  yi = [
    {
      icon: `users`,
      title: `Community-led`,
      text: `We work in partnership with communities and value local knowledge and solutions.`,
    },
    {
      icon: `shield`,
      title: `Integrity`,
      text: `We are committed to honesty, respect and ethical conduct in everything we do.`,
    },
    {
      icon: `handshake`,
      title: `Inclusion`,
      text: `We strive for equal opportunities and meaningful participation for all.`,
    },
    {
      icon: `scale`,
      title: `Accountability`,
      text: `We are transparent, responsible and committed to learning and continuous improvement.`,
    },
  ],
  bi = [
    {
      icon: `users`,
      level: `Oversight`,
      title: `Board of Directors`,
      text: `Provides strategic direction and oversight of the organization.`,
    },
    {
      icon: `user`,
      level: `Management`,
      title: `Executive Leadership`,
      text: `Leads organizational management, strategy and partnerships.`,
    },
    {
      icon: `layers`,
      level: `Delivery`,
      title: `Program and Support Teams`,
      text: `Implement programs and provide the support needed to achieve our mission.`,
    },
  ];
function Si(e) {
  let [t, n] = (0, x.useState)(e[0]);
  return (
    (0, x.useEffect)(() => {
      let t = 0,
        r = () => {
          t = 0;
          let r = window.innerHeight * 0.4,
            i = e[0];
          for (let t of e) {
            let e = document.getElementById(t);
            e && e.getBoundingClientRect().top <= r && (i = t);
          }
          n(i);
        },
        i = () => {
          t ||= requestAnimationFrame(r);
        };
      return (
        r(),
        window.addEventListener(`scroll`, i, {
          passive: !0,
        }),
        () => {
          (window.removeEventListener(`scroll`, i), cancelAnimationFrame(t));
        }
      );
    }, [e]),
    t
  );
}
var Ci = $n.map((e) => e.id);
var Ti = [
    {
      icon: `users`,
      color: `var(--prio-empower)`,
      img: `./assets/img/priorities-empower.jpg`,
      title: `Women's empowerment`,
      text: `Building skills, expanding opportunity and supporting women's participation in community life.`,
    },
    {
      icon: `book`,
      color: `var(--prio-learning)`,
      img: `./assets/img/priorities-learning.jpg`,
      title: `Learning and wellbeing`,
      text: `Increasing access to education and essential health services for women and communities.`,
    },
    {
      icon: `sprout`,
      color: `var(--prio-livelihoods)`,
      img: `./assets/img/priorities-livelihoods.jpg`,
      title: `Sustainable livelihoods`,
      text: `Creating economic opportunities and supporting agricultural resilience for more self-reliant communities.`,
    },
    {
      icon: `scale`,
      color: `var(--prio-accountability)`,
      img: `./assets/img/priorities-accountability.jpg`,
      title: `Accountability to communities`,
      text: `Listening to communities and using evidence and learning so our work stays relevant and responsive.`,
    },
  ],
  Ei = [
    {
      icon: `users`,
      title: `Community-led`,
      text: `We work with communities to understand priorities and find practical solutions.`,
    },
    {
      icon: `handshake`,
      title: `Inclusive`,
      text: `We support the meaningful participation of women and vulnerable groups.`,
    },
    {
      icon: `mountain`,
      title: `Culturally informed`,
      text: `We respect local context, values and traditions.`,
    },
    {
      icon: `fileSearch`,
      title: `Evidence-informed`,
      text: `We use evidence and learning to improve our programs and adapt to changing needs.`,
    },
  ];
var Oi = `All projects`,
  ki = [Oi, ...new Set(nr.map((e) => e.category))];
function Ai({ p: e }) {
  let t = [
    e.reach && {
      label: `Reach`,
      value: e.reach,
    },
    e.scope && {
      label: `Scope`,
      value: e.scope,
    },
    e.duration && {
      label: `Duration`,
      value: e.duration,
    },
    {
      label: `Supported by`,
      value: e.funder,
    },
  ].filter(Boolean);
  return (0, M.jsxs)(`article`, {
    className: `project-card`,
    children: [
      (0, M.jsxs)(`div`, {
        className: `media`,
        children: [
          (0, M.jsx)(`img`, {
            src: e.img,
            alt: ``,
            loading: `lazy`,
          }),
          (0, M.jsx)(`span`, {
            className: `badge badge-light project-card-tag`,
            children: e.category,
          }),
        ],
      }),
      (0, M.jsxs)(`div`, {
        className: `project-card-body`,
        children: [
          (0, M.jsxs)(`ul`, {
            className: `meta`,
            children: [
              (0, M.jsxs)(`li`, {
                children: [
                  (0, M.jsx)(N, {
                    name: `pin`,
                    size: 14,
                  }),
                  e.location,
                  `, Afghanistan`,
                ],
              }),
              e.year &&
                (0, M.jsxs)(`li`, {
                  children: [
                    (0, M.jsx)(N, {
                      name: `calendar`,
                      size: 14,
                    }),
                    e.year,
                  ],
                }),
            ],
          }),
          (0, M.jsx)(`h3`, {
            children: e.title,
          }),
          (0, M.jsx)(`dl`, {
            className: `project-facts`,
            children: t.map((e) =>
              (0, M.jsxs)(
                `div`,
                {
                  children: [
                    (0, M.jsx)(`dt`, {
                      children: e.label,
                    }),
                    (0, M.jsx)(`dd`, {
                      children: e.value,
                    }),
                  ],
                },
                e.label,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
var Mi = [
    {
      icon: `file`,
      kind: `Reports`,
      title: `Annual reports`,
      text: `An overview of our work, activities and learning each year.`,
    },
    {
      icon: `chart`,
      kind: `Reports`,
      title: `Financial & audit reports`,
      text: `Our financial information and audit reports.`,
    },
    {
      icon: `shield`,
      kind: `Policies`,
      title: `Policies & procedures`,
      text: `The organizational policies and procedures that guide our work.`,
    },
  ],
  Ni = [`All`, `Reports`, `Policies`],
  Pi = [
    {
      icon: `scale`,
      title: `Responsible stewardship`,
      text: `We aim to use resources responsibly and act with integrity in all our activities.`,
    },
    {
      icon: `message`,
      title: `Community feedback`,
      text: `We value the perspectives of the communities we work with and actively seek their input.`,
    },
    {
      icon: `refresh`,
      title: `Learning and improvement`,
      text: `We reflect on our work and look for ways to improve our programs and processes.`,
    },
  ];
var Ii = [
    {
      src: `./assets/img/news-gal-1.jpg`,
      alt: `Women studying together in a classroom`,
    },
    {
      src: `./assets/img/news-gal-2.jpg`,
      alt: `A facilitator writing on a whiteboard during a session`,
    },
    {
      src: `./assets/img/news-gal-3.jpg`,
      alt: `A mountain village beside a river`,
    },
    {
      src: `./assets/img/news-gal-4.jpg`,
      alt: `Women tending crops in a field`,
    },
    {
      src: `./assets/img/news-gal-5.jpg`,
      alt: `A group of women in a learning circle`,
    },
    {
      src: `./assets/img/news-gal-6.jpg`,
      alt: `Snow-capped mountains above a pine valley`,
    },
  ],
  Li = [`All`, `Stories`, `Gallery`];
function Ri({ index: e, onClose: t, onStep: n }) {
  (0, x.useEffect)(() => {
    let e = (e) => {
      (e.key === `Escape` && t(),
        e.key === `ArrowRight` && n(1),
        e.key === `ArrowLeft` && n(-1));
    };
    return (
      window.addEventListener(`keydown`, e),
      document.body.classList.add(`no-scroll`),
      () => {
        (window.removeEventListener(`keydown`, e),
          document.body.classList.remove(`no-scroll`));
      }
    );
  }, [t, n]);
  let r = Ii[e];
  return (0, M.jsxs)(`div`, {
    className: `lightbox`,
    onClick: t,
    role: `dialog`,
    "aria-modal": `true`,
    "aria-label": `Photo viewer`,
    children: [
      (0, M.jsxs)(`figure`, {
        onClick: (e) => e.stopPropagation(),
        children: [
          (0, M.jsx)(`img`, {
            src: r.src,
            alt: r.alt,
          }),
          (0, M.jsxs)(`figcaption`, {
            children: [
              (0, M.jsx)(`span`, {
                children: r.alt,
              }),
              (0, M.jsxs)(`span`, {
                className: `lb-count`,
                children: [e + 1, ` / `, Ii.length],
              }),
            ],
          }),
        ],
      }),
      (0, M.jsx)(`button`, {
        className: `lb-btn lb-prev`,
        "aria-label": `Previous photo`,
        onClick: (e) => {
          (e.stopPropagation(), n(-1));
        },
        children: (0, M.jsx)(N, {
          name: `chevronLeft`,
          size: 22,
          strokeWidth: 2,
        }),
      }),
      (0, M.jsx)(`button`, {
        className: `lb-btn lb-next`,
        "aria-label": `Next photo`,
        onClick: (e) => {
          (e.stopPropagation(), n(1));
        },
        children: (0, M.jsx)(N, {
          name: `chevronRight`,
          size: 22,
          strokeWidth: 2,
        }),
      }),
      (0, M.jsx)(`button`, {
        className: `lb-btn lb-close`,
        "aria-label": `Close`,
        autoFocus: !0,
        onClick: t,
        children: (0, M.jsx)(N, {
          name: `close`,
          size: 22,
          strokeWidth: 2,
        }),
      }),
    ],
  });
}
var Bi = [
    {
      key: `careers`,
      label: `Careers`,
    },
    {
      key: `procurement`,
      label: `Procurement`,
    },
  ],
  Vi = {
    careers: {
      empty: {
        icon: `briefcase`,
        art: `careers`,
        title: `No open vacancies right now`,
        text: `When positions open, they are published here with the full role description, requirements and closing date.`,
        subject: `Career enquiry`,
      },
      head: {
        eyebrow: `How to apply`,
        title: `When a vacancy is published`,
        text: `Every vacancy notice explains exactly what to submit and how.`,
      },
      steps: [
        {
          title: `Read the vacancy`,
          text: `Review the role description, requirements, location and closing date in the published vacancy.`,
        },
        {
          title: `Prepare your application`,
          text: `Prepare the documents requested in the vacancy, such as a CV and cover letter.`,
        },
        {
          title: `Apply as instructed`,
          text: `Submit your application using the method stated in the vacancy, before the closing date.`,
        },
      ],
    },
    procurement: {
      empty: {
        icon: `file`,
        art: `resources`,
        title: `No active tender notices`,
        text: `Procurement opportunities are published here with the full notice, required documents and submission deadline.`,
        subject: `Procurement enquiry`,
      },
      head: {
        eyebrow: `Procurement guidance`,
        title: `When a tender is published`,
        text: `Follow these general steps for any PWSO tender notice.`,
      },
      steps: [
        {
          title: `Read the notice`,
          text: `Review the tender notice carefully, including all requirements and instructions.`,
        },
        {
          title: `Prepare required documents`,
          text: `Prepare and complete the required documents as outlined in the notice.`,
        },
        {
          title: `Submit as instructed`,
          text: `Submit your proposal following the method and deadline specified in the notice.`,
        },
      ],
    },
  };
var Ui = [
    {
      title: `Afghan-led approach`,
      text: `A local organization with a deep understanding of the context, communities and priorities.`,
    },
    {
      title: `Community knowledge`,
      text: `Close relationships with women and communities across our areas of work.`,
    },
    {
      title: `Learning and accountability`,
      text: `A commitment to evidence, transparency and continuous learning.`,
    },
  ],
  Wi = [
    {
      icon: `layers`,
      title: `Program support`,
      text: `Support for community-based initiatives aligned with our mission and focus areas.`,
    },
    {
      icon: `users`,
      title: `Technical assistance`,
      text: `Exchange of expertise, knowledge and practical support.`,
    },
    {
      icon: `fileSearch`,
      title: `Research & learning`,
      text: `Collaborative research, documentation and knowledge sharing.`,
    },
    {
      icon: `sprout`,
      title: `Capacity strengthening`,
      text: `Support to enhance organizational and community capacities.`,
    },
  ],
  Gi = {
    organization: ``,
    name: ``,
    email: ``,
    area: ``,
    message: ``,
  };
var qi = [
    {
      key: `General`,
      icon: `message`,
    },
    {
      key: `Programs`,
      icon: `book`,
    },
    {
      key: `Partnerships`,
      icon: `handshake`,
    },
    {
      key: `Careers`,
      icon: `briefcase`,
    },
    {
      key: `Procurement`,
      icon: `file`,
    },
    {
      key: `Feedback`,
      icon: `shield`,
    },
  ],
  Ji = [
    {
      q: `How can we partner with PWSO?`,
      a: `We welcome partnership enquiries from organizations and individuals who share our commitment to Afghan women and communities. Use the form on this page with the "Partnerships" topic, or visit our Partnerships page.`,
    },
    {
      q: `Where does PWSO have offices?`,
      a: `PWSO has its main office in Kabul and a sub-office in Badakhshan.`,
    },
    {
      q: `Where can I find the organization profile?`,
      a: `You can download our organization profile from the Resources page, or using the download link on this page.`,
    },
    {
      q: `How do I share feedback or raise a concern?`,
      a: `Choose the "Feedback" topic in the form above, or email us directly. We welcome feedback from community members, partners and other stakeholders.`,
    },
  ];
